"""Shared UI state for nthexternal.

Ported from the original rbx_esp.py AppState; the only additions are the
on-screen-HUD flag, an explicit mode setter and the panel visibility flag.
All original fields and semantics are unchanged.
"""

from __future__ import annotations

import threading


class AppState:
    def __init__(self) -> None:
        self.draw_boxes = True
        self.draw_names = True
        # The current Roblox view matrix is row-major, with the perspective
        # divisor in the fourth row (the layout implemented by mode 3).
        # Starting in that layout keeps boxes on-screen without requiring a
        # manual F7 calibration every launch.
        self.w2s_mode = 3
        self.show_hud = True        # added: hide/show the overlay HUD text
        self.panel_visible = True   # added: F9 toggles the control panel
        self.paused = False         # added: Start/Stop quick action pauses the overlay
        self.reload_requested = False
        self.quit = False
        self.lock = threading.Lock()

    def set_paused(self, on: bool) -> None:
        with self.lock:
            self.paused = bool(on)

    def is_paused(self) -> bool:
        with self.lock:
            return self.paused

    def toggle_boxes(self) -> None:
        with self.lock:
            self.draw_boxes = not self.draw_boxes

    def toggle_names(self) -> None:
        with self.lock:
            self.draw_names = not self.draw_names

    def toggle_hud(self) -> None:
        with self.lock:
            self.show_hud = not self.show_hud

    def cycle_mode(self) -> None:
        with self.lock:
            self.w2s_mode = (self.w2s_mode + 1) % 4

    def set_mode(self, mode: int) -> None:
        with self.lock:
            self.w2s_mode = mode % 4

    def set_boxes(self, on: bool) -> None:
        with self.lock:
            self.draw_boxes = bool(on)

    def set_names(self, on: bool) -> None:
        with self.lock:
            self.draw_names = bool(on)

    def set_hud(self, on: bool) -> None:
        with self.lock:
            self.show_hud = bool(on)

    def snapshot_flags(self) -> tuple[bool, bool, bool, int]:
        with self.lock:
            return self.draw_boxes, self.draw_names, self.show_hud, self.w2s_mode

    def request_reload(self) -> None:
        with self.lock:
            self.reload_requested = True
