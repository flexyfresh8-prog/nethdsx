"""Probe 3: confirm the candidate is the DataModel and pin down the children layout."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import Memory, Offsets, list_processes_by_name, main_module_base  # noqa: E402

off = Offsets()
off.merge_file(os.path.expanduser("~") + r"\Documents\mcro\New Text Document.json")

pid = list_processes_by_name(["robloxplayerbeta"])[0][0]
mem = Memory(pid)
mem.open()
base = main_module_base(pid)

fake = mem.r64(base + off.require("FakeDataModel", "Pointer"))
cand = mem.r64(fake + off.require("FakeDataModel", "RealDataModel"))
print(f"fake=0x{fake:x}  cand=0x{cand:x}")


def hexdump(label: str, addr: int, size: int) -> None:
    print(f"\n-- {label} @ 0x{addr:x}")
    data = mem.read(addr, size)
    if not data:
        print("   <unreadable>")
        return
    for row in range(0, len(data), 16):
        chunk = data[row:row + 16]
        hx = " ".join(f"{b:02x}" for b in chunk)
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print(f"   {addr + row:012x}  {hx:<47}  |{asc}|")


def cstr(addr: int, maxn: int = 64) -> str:
    d = mem.read(addr, maxn)
    if not d:
        return ""
    out = []
    for b in d:
        if b == 0:
            break
        out.append(chr(b) if 32 <= b < 127 else "?")
    return "".join(out)


# 1) is cd_qword0 a static class-name C string?
cd = mem.r64(cand + 0x18)
cdq0 = mem.r64(cd)
print(f"\ncd=0x{cd:x}  cd[0]=0x{cdq0:x}")
print(f"C-string at cd[0]: {cstr(cdq0)!r}")
hexdump("cd[0] region", cdq0, 0x30)

# 2) DataModel identity fields from the dump
pid32 = mem.r32(cand + off.require("DataModel", "PlaceId"))
gid = mem.r32(cand + off.require("DataModel", "GameId"))
loaded = mem.r_u8(cand + off.require("DataModel", "GameLoaded"))
jobid = mem.r_string(cand + off.require("DataModel", "JobId"))
primcount = mem.r32(cand + off.require("DataModel", "PrimitiveCount"))
print(f"\nPlaceId(u32)= {pid32}")
print(f"GameId(u32) = {gid}")
print(f"GameLoaded  = {loaded}")
print(f"JobId str   = {jobid!r}")
print(f"PrimitiveCount = {primcount}")

# 3) workspace pointer via dump offset
ws = mem.r64(cand + off.require("DataModel", "Workspace"))
print(f"workspace ptr = 0x{ws:x}")


def name_of(inst: int) -> str:
    nc = mem.r64(inst + off.require("Instance", "NameContainer"))
    return mem.r_string(nc + off.require("Instance", "Name")) if nc else ""


def cls_of(inst: int) -> str:
    d = mem.r64(inst + off.require("Instance", "ClassDescriptor"))
    if not d:
        return "<no cd>"
    s = cstr(mem.r64(d))
    if s:
        return s
    return mem.r_string(d + off.require("Instance", "ClassName"))


if ws:
    print(f"workspace name={name_of(ws)!r}  class={cls_of(ws)!r}")
    hexdump("workspace inst (first 0x80)", ws, 0x80)
    wcd = mem.r64(ws + 0x18)
    print(f"ws cd[0] C-string: {cstr(mem.r64(wcd))!r}")

# 4) children region of candidate, raw
hexdump("cand + 0x60..0xC0", cand + 0x60, 0x60)

P70 = mem.r64(cand + 0x70)
P78 = mem.r64(cand + 0x78)
print(f"\nP70=0x{P70:x} P78=0x{P78:x}  (P70-P78={P70 - P78})")
hexdump("P78 region (0x40)", P78, 0x40)

# interpretation A: begin=P70->, the qwords AT P70 are elements? count via P78 region
# interpretation B: vector object at P78 with begin/end inside
b2 = mem.r64(P78 + 0x18) if P78 else 0
e2 = mem.r64(P78 + 0x20) if P78 else 0
print(f"alt B: *(P78+0x18)=0x{b2:x}  *(P78+0x20)=0x{e2:x}  n={(e2 - b2) // 8 if e2 >= b2 and e2 - b2 < 0x100000 else '?'}")

# 5) enumerate first entries of the 298-entry vector and name them
if e2 > b2 and (e2 - b2) // 8 <= 2048:
    n = (e2 - b2) // 8
    buf = mem.read(b2, min(n, 16) * 8)
    print(f"\nfirst children of the {n}-entry vector:")
    for i in range(min(n, 16)):
        c = struct.unpack_from("<Q", buf, i * 8)[0]
        if not c:
            print(f"  [{i}] NULL")
            continue
        print(f"  [{i}] 0x{c:x} name={name_of(c)!r} class={cls_of(c)!r}")

# 6) also try: treat *(cand+0x70) as begin-of-elements directly (i.e. elements ARE at P70)
n3 = (P70 - P78) // 8 if P70 > P78 else 0
if 0 < n3 <= 8:
    buf = mem.read(P78, n3 * 8)
    print(f"\nsmall-vector interpretation ({n3} entries between P78..P70):")
    for i in range(n3):
        c = struct.unpack_from("<Q", buf, i * 8)[0]
        print(f"  [{i}] 0x{c:x} name={name_of(c) if c else '-'}")

mem.close()
