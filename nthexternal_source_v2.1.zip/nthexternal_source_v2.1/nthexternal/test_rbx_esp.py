"""Offline tests for rbx_hitbox_esp: parser, math, required offsets."""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import Offsets, find_offset_files, world_to_screen, project_box, box_edges  # noqa: E402

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ok  {name}")
    else:
        FAIL += 1
        print(f" FAIL {name} {extra}")


print("== offsets parser ==")
files = find_offset_files(None)
print("resolved files:", [os.path.basename(f) for f in files])
check("offset files resolved", len(files) > 0)
off = Offsets()
total = 0
for f in files:
    total += off.merge_file(f)
print(f"merged entries: {total}")
check("parser read entries", total > 300)

# spot-check against the user's dump
expect = {
    ("TaskScheduler", "Pointer"): 0x8F1E408,
    ("VisualEngine", "Pointer"): 0x8A11808,
    ("FakeDataModel", "RealDataModel"): 0x1F8,
    ("VisualEngine", "ViewMatrix"): 0x1B0,
    ("VisualEngine", "Dimensions"): 0xB10,
    ("RenderJob", "FakeDataModel"): 0x38,
    ("RenderJob", "RealDataModel"): 0x1F0,
    ("DataModel", "Workspace"): 0x168,
    ("DataModel", "GameLoaded"): 0x5B8,
    ("Instance", "ChildrenStart"): 0x70,
    ("Instance", "ChildrenEnd"): 0x8,
    ("Instance", "ClassDescriptor"): 0x18,
    ("Instance", "ClassName"): 0x8,
    ("Instance", "NameContainer"): 0x68,
    ("Player", "LocalPlayer"): 0x118,
    ("Player", "ModelInstance"): 0x2A0,
    ("Player", "DisplayName"): 0x120,
    ("Player", "UserId"): 0xB8,
    ("Humanoid", "Health"): 0x184,
    ("Humanoid", "MaxHealth"): 0x1A0,
    ("BasePart", "Primitive"): 0x178,
    ("Primitive", "Position"): 0xD4,
    ("Primitive", "Rotation"): 0xB0,
    ("Primitive", "Size"): 0x1C4,
    ("Workspace", "CurrentCamera"): 0x4A0,
    ("Camera", "Position"): 0xE4,
    ("Misc", "StringLength"): 0x10,
}
for (ns, f), v in expect.items():
    got = off.get(ns, f)
    check(f"{ns}::{f} == 0x{v:x}", got == v, f"(got {got})")

print("== projection math (mode 0, synthetic lookdown-Z matrix) ==")
m = [1.0, 0.0, 0.0, 0.0,
     0.0, 1.0, 0.0, 0.0,
     0.0, 0.0, -1.0, 0.0,
     0.0, 0.0, 0.0, 1.0]
sx, sy, vis = world_to_screen(m, 0.0, 0.0, -10.0, 1920, 1080, 0)
check("center point projects to viewport center", vis and abs(sx - 960) < 1e-6 and abs(sy - 540) < 1e-6,
      f"(got {sx},{sy})")
sx, sy, vis = world_to_screen(m, 10.0, 0.0, -10.0, 1920, 1080, 0)
check("offset x -> right half", vis and sx > 960, f"(got {sx})")
sx, sy, vis = world_to_screen(m, 0.0, 5.0, -10.0, 1920, 1080, 0)
check("up -> upper half", vis and sy < 540, f"(got {sy})")
_, _, vis = world_to_screen(m, 0.0, 0.0, +10.0, 1920, 1080, 0)
check("point behind camera clipped", not vis)

print("== projection math (mode 3, row-major clip matrix) ==")
m3 = [1.0, 0.0, 0.0, 0.0,
      0.0, 1.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, -1.0, 0.0]
sx, sy, vis = world_to_screen(m3, 0.0, 0.0, -10.0, 1920, 1080, 3)
check("mode 3 center point projects to viewport center",
      vis and abs(sx - 960) < 1e-6 and abs(sy - 540) < 1e-6,
      f"(got {sx},{sy})")
sx, sy, vis = world_to_screen(m3, 10.0, 0.0, -10.0, 1920, 1080, 3)
check("mode 3 offset x -> right half", vis and sx > 960, f"(got {sx})")
_, _, vis = world_to_screen(m3, 0.0, 0.0, +10.0, 1920, 1080, 3)
check("mode 3 point behind camera clipped", not vis)

print("== box projection ==")
ident = (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
corners = project_box(m, (0.0, 0.0, -10.0), (2.0, 4.0, 2.0), ident, 1920, 1080, 0)
check("box projects 8 corners", corners is not None and len(corners) == 8)
xs = [c[0] for c in corners]
ys = [c[1] for c in corners]
# Perspective is z-dependent: with m10=-1 the near face (w = d - hz) dominates.
# expected width  = 2 * (vw/2) * hx / (d - hz)
exp_w = 1920.0 * 1.0 / 9.0
exp_h = 1080.0 * 2.0 / 9.0
check("box width matches analytic perspective projection",
      abs((max(xs) - min(xs)) - exp_w) < 0.01, f"(got {max(xs)-min(xs)}, want {exp_w})")
check("box height matches analytic perspective projection",
      abs((max(ys) - min(ys)) - exp_h) < 0.01, f"(got {max(ys)-min(ys)}, want {exp_h})")
check("box horizontally centered on view axis",
      abs((max(xs) + min(xs)) / 2 - 960.0) < 0.01)
# rotated box (90 deg about Y): world x extent comes from size.z (hz=3)
rot90 = (0.0, 0.0, -1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0)
corners = project_box(m, (0.0, 0.0, -10.0), (2.0, 4.0, 6.0), rot90, 1920, 1080, 0)
xs = [c[0] for c in corners]
exp_wr = 1920.0 * 3.0 / 9.0
check("rotated box width uses rotated extent",
      abs((max(xs) - min(xs)) - exp_wr) < 0.01, f"(got {max(xs)-min(xs)}, want {exp_wr})")
check("box_edges has 12 edges", len(box_edges()) == 12)

print(f"\n{PASS} passed, {FAIL} failed")
sys.exit(1 if FAIL else 0)
