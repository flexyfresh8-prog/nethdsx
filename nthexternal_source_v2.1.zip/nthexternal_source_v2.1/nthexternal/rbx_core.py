"""
rbx_core.py - Roblox external world-state reader (user-mode ReadProcessMemory).

Reads the running Roblox client's world state via Win32 RPM using the offsets
dumped by the user (format: "Namespace::Field = 0xHEX", file extension
irrelevant: .json / .txt / anything).

Exposes:
    Offsets         - loader/merger for the dumper text format (and plain JSON dicts)
    Memory          - process handle + typed read helpers
    Game            - attach/init + read_players() snapshot
    world_to_screen - projection with selectable layout mode (F7 cycles)
"""

from __future__ import annotations

import ctypes
import json
import math
import os
import re
import struct
import sys
import time
from ctypes import wintypes

# ----------------------------------------------------------------------------
# Win32 bindings
# ----------------------------------------------------------------------------

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
u32 = ctypes.WinDLL("user32", use_last_error=True)

PROCESS_VM_READ = 0x0010
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TH32CS_SNAPPROCESS = 0x2
TH32CS_SNAPMODULE = 0x8
MAX_PATH = 260


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeap", ctypes.c_size_t),  # ULONG_PTR - omitting it breaks Process32FirstW (err 24)
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", ctypes.c_wchar * MAX_PATH),
    ]


class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("th32ModuleID", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("GlblcntUsage", wintypes.DWORD),
        ("ProccntUsage", wintypes.DWORD),
        ("modBaseAddr", ctypes.POINTER(ctypes.c_byte)),
        ("modBaseSize", wintypes.DWORD),
        ("hModule", wintypes.HMODULE),
        ("szModule", ctypes.c_wchar * 256),
        ("szExePath", ctypes.c_wchar * MAX_PATH),
    ]


k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
k32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
k32.Process32FirstW.restype = wintypes.BOOL
k32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
k32.Process32NextW.restype = wintypes.BOOL
k32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
k32.Module32FirstW.restype = wintypes.BOOL
k32.Module32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MODULEENTRY32W)]
k32.Module32NextW.restype = wintypes.BOOL
k32.Module32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MODULEENTRY32W)]
k32.OpenProcess.restype = wintypes.HANDLE
k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
k32.CloseHandle.restype = wintypes.BOOL
k32.CloseHandle.argtypes = [wintypes.HANDLE]
k32.ReadProcessMemory.restype = wintypes.BOOL
k32.ReadProcessMemory.argtypes = [
    wintypes.HANDLE,
    ctypes.c_void_p,
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t),
]

# ----------------------------------------------------------------------------
# Offsets loader
# ----------------------------------------------------------------------------

_LINE_RE = re.compile(
    r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*::\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(0x[0-9A-Fa-f]+|\d+)\s*(?:#.*)?$"
)


class Offsets:
    """Loads and merges dumper text ("Ns::Field = 0x..") and JSON dict formats."""

    def __init__(self) -> None:
        self.map: dict[str, int] = {}
        self.sources: list[str] = []

    # -- loading ------------------------------------------------------------
    def merge_file(self, path: str) -> int:
        """Parse one file; returns number of entries added/overridden."""
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            raw = f.read()
        added = self.merge_text(raw)
        if added:
            self.sources.append(path)
        return added

    def merge_text(self, raw: str) -> int:
        added = 0
        stripped = raw.strip()
        # Try a real JSON object first (in case the user swaps in true JSON).
        if stripped.startswith("{"):
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError:
                obj = None
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        self.map[k] = int(v)
                        added += 1
                    elif isinstance(v, dict):
                        for k2, v2 in v.items():
                            if isinstance(v2, (int, float)) and not isinstance(v2, bool):
                                self.map[f"{k}::{k2}"] = int(v2)
                                added += 1
                if added:
                    return added
        # Line format: Ns::Field = 0xHEX
        for line in raw.splitlines():
            m = _LINE_RE.match(line)
            if m:
                ns, field, val = m.groups()
                self.map[f"{ns}::{field}"] = int(val, 16) if val.startswith("0x") else int(val)
                added += 1
        return added

    # -- access -------------------------------------------------------------
    def get(self, ns: str, field: str, default: int | None = None) -> int | None:
        return self.map.get(f"{ns}::{field}", default)

    def require(self, ns: str, field: str) -> int:
        v = self.map.get(f"{ns}::{field}")
        if v is None:
            raise KeyError(f"missing offset {ns}::{field}")
        return v

    def missing_required(self, required: list[tuple[str, str]]) -> list[str]:
        out = []
        for ns, field in required:
            if f"{ns}::{field}" not in self.map:
                out.append(f"{ns}::{field}")
        return out


def find_offset_files(explicit: str | None) -> list[str]:
    """Resolve which offset files to load, in order (later files override)."""
    if explicit:
        return [explicit]
    here = os.path.dirname(os.path.abspath(__file__))
    candidates: list[str] = []
    # 1) files dropped next to the script
    for name in ("offsets.json", "offsets.txt", "New Text Document.json", "New Text Document.txt"):
        p = os.path.join(here, name)
        if os.path.isfile(p):
            candidates.append(p)
    if candidates:
        return candidates
    # 2) the user's dump folder (Documents/mcro)
    home = os.path.expanduser("~")
    docs = os.path.join(home, "Documents", "mcro")
    if os.path.isdir(docs):
        found = []
        for name in os.listdir(docs):
            low = name.lower()
            if low.endswith(".json") or low.endswith(".txt"):
                full = os.path.join(docs, name)
                if os.path.getsize(full) > 0:
                    found.append(full)
        # json first, txt second (txt overrides)
        found.sort(key=lambda p: (0 if p.lower().endswith(".json") else 1, p))
        candidates.extend(found)
    return candidates


# ----------------------------------------------------------------------------
# Memory reader
# ----------------------------------------------------------------------------

RBX_STRING_MAX = 512  # safety clamp on string blob lengths


class Memory:
    def __init__(self, pid: int) -> None:
        self.pid = pid
        self.handle: wintypes.HANDLE = None
        self.base: int = 0
        self.last_error: str = ""

    # -- handle -------------------------------------------------------------
    def open(self) -> bool:
        h = k32.OpenProcess(
            PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, False, self.pid
        )
        if not h:
            self.last_error = (
                f"OpenProcess(pid={self.pid}) failed err={ctypes.get_last_error()}"
            )
            return False
        self.handle = h
        return True

    def close(self) -> None:
        if self.handle:
            k32.CloseHandle(self.handle)
            self.handle = None

    # -- primitive reads ------------------------------------------------------
    def read(self, addr: int, size: int) -> bytes | None:
        if not self.handle or not addr:
            return None
        buf = ctypes.create_string_buffer(size)
        got = ctypes.c_size_t(0)
        ok = k32.ReadProcessMemory(
            self.handle, ctypes.c_void_p(addr), buf, ctypes.c_size_t(size), ctypes.byref(got)
        )
        if not ok or got.value != size:
            return None
        return buf.raw

    def r64(self, addr: int) -> int:
        b = self.read(addr, 8)
        if b is None:
            return 0
        return struct.unpack_from("<Q", b)[0]

    def r32(self, addr: int) -> int:
        b = self.read(addr, 4)
        if b is None:
            return 0
        return struct.unpack_from("<I", b)[0]

    def r_i32(self, addr: int) -> int:
        b = self.read(addr, 4)
        if b is None:
            return 0
        return struct.unpack_from("<i", b)[0]

    def r_u8(self, addr: int) -> int:
        b = self.read(addr, 1)
        if b is None:
            return 0
        return b[0]

    def r_float(self, addr: int) -> float:
        b = self.read(addr, 4)
        if b is None:
            return 0.0
        return struct.unpack_from("<f", b)[0]

    def r_vec3(self, addr: int) -> tuple[float, float, float]:
        b = self.read(addr, 12)
        if b is None:
            return (0.0, 0.0, 0.0)
        return struct.unpack_from("<fff", b)

    def r_mat4(self, addr: int) -> list[float] | None:
        b = self.read(addr, 64)
        if b is None:
            return None
        return list(struct.unpack_from("<16f", b))

    def r_mat3(self, addr: int) -> list[float] | None:
        b = self.read(addr, 36)
        if b is None:
            return None
        return list(struct.unpack_from("<9f", b))

    # -- Roblox string blob ---------------------------------------------------
    def r_string(self, s_addr: int) -> str:
        """RBX internal string: [ptr @0x0][? ?][len @0x10]; SSO inline when len < 16."""
        if not s_addr:
            return ""
        length = self.r64(s_addr + 0x10)
        if length == 0:
            return ""
        if length >= RBX_STRING_MAX:
            return ""
        if length >= 0x10:
            ptr = self.r64(s_addr)
            if not ptr:
                return ""
            data = self.read(ptr, length)
        else:
            data = self.read(s_addr, length)
        if data is None:
            return ""
        try:
            return data.decode("utf-8", "replace")
        except Exception:
            return ""


def list_processes_by_name(substrings: list[str]) -> list[tuple[int, str]]:
    """All running processes whose exe name contains any substring (case-insens)."""
    out: list[tuple[int, str]] = []
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == wintypes.HANDLE(-1).value or not snap:
        return out
    try:
        pe = PROCESSENTRY32W()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        if k32.Process32FirstW(snap, ctypes.byref(pe)):
            while True:
                name = pe.szExeFile or ""
                low = name.lower()
                if any(s in low for s in substrings):
                    out.append((pe.th32ProcessID, name))
                if not k32.Process32NextW(snap, ctypes.byref(pe)):
                    break
    finally:
        k32.CloseHandle(snap)
    return out


def main_module_base(pid: int) -> int:
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid)
    if snap == wintypes.HANDLE(-1).value or not snap:
        return 0
    try:
        me = MODULEENTRY32W()
        me.dwSize = ctypes.sizeof(MODULEENTRY32W)
        if k32.Module32FirstW(snap, ctypes.byref(me)):
            # first module == main executable module
            return ctypes.cast(me.modBaseAddr, ctypes.c_void_p).value or 0
    finally:
        k32.CloseHandle(snap)
    return 0


# ----------------------------------------------------------------------------
# Game state reader
# ----------------------------------------------------------------------------

BASEPART_CLASSES = {
    "Part",
    "MeshPart",
    "UnionOperation",
    "NegateOperation",
    "WedgePart",
    "CornerWedgePart",
    "TrussPart",
    "SpawnLocation",
    "Seat",
    "VehicleSeat",
}

# One player-level box is enough for the overlay and avoids reading every body
# part's transform.  The root part supplies the live center/orientation; the
# dimensions cover the standard Roblox character envelope.
SIMPLE_HITBOX_SIZE = (4.0, 6.0, 2.5)
ROOT_PART_NAMES = ("HumanoidRootPart", "UpperTorso", "Torso")

PLAYER_KIND = ("robloxplayerbeta", "robloxplayer", "roblox")


class AttachError(Exception):
    pass


class PlayerSnapshot:
    __slots__ = (
        "name",
        "display",
        "uid",
        "health",
        "max_health",
        "is_local",
        "parts",
        "head_index",
    )

    def __init__(self) -> None:
        self.name = ""
        self.display = ""
        self.uid = 0
        self.health = 0.0
        self.max_health = 0.0
        self.is_local = False
        self.parts: list[tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, ...]]] = []
        self.head_index = -1


class FrameSnapshot:
    __slots__ = ("players", "matrix", "vp_w", "vp_h", "stamp", "pid", "place_id", "cam_pos")

    def __init__(self) -> None:
        self.players: list[PlayerSnapshot] = []
        self.matrix: list[float] | None = None
        self.vp_w = 0.0
        self.vp_h = 0.0
        self.stamp = 0.0
        self.pid = 0
        self.place_id = 0


class Game:
    """Attach + world read. Attach sequence:

        base  <- module base of the Roblox client process
        sched <- *(base + TaskScheduler::Pointer)
        jobs  <- [*(sched+JobStart) .. *(sched+JobEnd))
        job named *Render* -> fake_datamodel = *(job + RenderJob::FakeDataModel)
        datamodel          = *(fake + FakeDataModel::RealDataModel)
        verify             -> child named "Players" with class "Players"
    Fallback: VisualEngine::Pointer -> *(ve+FakeDataModel) -> RealDataModel.
    """

    def __init__(self, offsets: Offsets, log=print) -> None:
        self.off = offsets
        self.log = log
        self.mem: Memory | None = None
        self.pid = 0
        self.base = 0
        self.dm = 0
        self.players_inst = 0
        self.workspace = 0
        self.ve = 0
        self.place_id = 0
        self._cls_name_off: int | None = None  # calibrated ClassDescriptor name-blob offset
        # player instance -> (character instance, humanoid instance,
        # root-part primitive).  Character children are stable between
        # respawns, so avoid walking them on every render sample.
        self._character_cache: dict[int, tuple[int, int, int]] = {}

    # -- low level helpers using current offsets -----------------------------
    def _class_descriptor(self, inst: int) -> int:
        return self.mem.r64(inst + self.off.require("Instance", "ClassDescriptor"))

    def _read_blob_or_cstr(self, addr: int) -> str:
        """RBX string blob (len at +0x10, SSO inline) then plain C-string."""
        if not addr:
            return ""
        s = self.mem.r_string(addr)
        if s and all(32 <= ord(c) < 127 for c in s):
            return s
        raw = self.mem.read(addr, 48)  # fallback: raw C-string at the blob
        if raw:
            out = []
            for b in raw:
                if b == 0:
                    break
                out.append(chr(b) if 32 <= b < 127 else "")
            s2 = "".join(out)
            if 0 < len(s2) <= 48:
                return s2
        return ""

    def _calibrate_class_name(self, anchor: int, expect: str) -> int:
        """Find the ClassDescriptor offset that holds the class-name blob by
        matching `expect` on a known instance (e.g. the Players service).
        Returns the offset, or -1 if nothing matched."""
        if not self.mem or not anchor:
            return -1
        try:
            cd = self.mem.r64(anchor + self.off.require("Instance", "ClassDescriptor"))
        except KeyError:
            return -1
        if not cd:
            return -1
        for o in range(0, 0x80, 8):
            q = self.mem.r64(cd + o)
            if q and self._read_blob_or_cstr(q) == expect:
                return o
            if self._read_blob_or_cstr(cd + o) == expect:
                return o
        return -1

    def class_name(self, inst: int) -> str:
        """Class name via the ClassDescriptor. Prefers the offset calibrated at
        attach time (_calibrate_class_name), then the dump's Instance::ClassName.
        Both RBX-blob and plain C-string protocols are tried (dereferenced and
        inline), so a drifted descriptor layout still resolves."""
        d = self._class_descriptor(inst)
        if not d:
            return ""
        offsets: list[int] = []
        if self._cls_name_off is not None and self._cls_name_off >= 0:
            offsets.append(self._cls_name_off)
        dump_off = self.off.get("Instance", "ClassName")
        if dump_off is not None and dump_off not in offsets:
            offsets.append(dump_off)
        for o in offsets:
            blob = self.mem.r64(d + o)
            if blob:
                s = self._read_blob_or_cstr(blob)
                if s:
                    return s
            s = self._read_blob_or_cstr(d + o)  # inline blob at cd+off
            if s:
                return s
        return ""

    def instance_name(self, inst: int) -> str:
        nc = self.mem.r64(inst + self.off.require("Instance", "NameContainer"))
        if not nc:
            return ""
        return self.mem.r_string(nc + self.off.require("Instance", "Name"))

    def children(self, inst: int, cap: int = 4096) -> list[int]:
        """Child instance pointers. Live-verified layout: *(inst+ChildrenStart)
        is a pointer V to the vector struct; begin=*(V), end=*(V+ChildrenEnd).
        Falls back to the flat (begin at inst+cs) layout if that yields nonsense."""
        cs = self.off.require("Instance", "ChildrenStart")
        ce = self.off.require("Instance", "ChildrenEnd")
        vec = self.mem.r64(inst + cs)
        if vec:
            begin = self.mem.r64(vec)
            end = self.mem.r64(vec + ce)
            if begin and end and begin <= end:
                n = (end - begin) // 8
                if 0 < n <= cap:
                    buf = self.mem.read(begin, n * 8)
                    if buf:
                        return [struct.unpack_from("<Q", buf, i * 8)[0] for i in range(n)]
            return []
        # legacy: begin stored directly at inst+cs
        start = self.mem.r64(inst + cs)
        end = self.mem.r64(inst + cs + ce)
        if not start or not end or end < start:
            return []
        n = (end - start) // 8
        if n <= 0 or n > cap:
            return []
        buf = self.mem.read(start, n * 8)
        if not buf:
            return []
        return [struct.unpack_from("<Q", buf, i * 8)[0] for i in range(n)]

    def find_child_by_name(self, inst: int, want: str) -> int:
        for c in self.children(inst):
            if self.instance_name(c) == want:
                return c
        return 0

    # -- attach ---------------------------------------------------------------
    def attach(self) -> None:
        procs = list_processes_by_name(list(PLAYER_KIND))
        if not procs:
            raise AttachError(
                "no Roblox client process found - is your game running? "
                "(editor/studio sessions are not supported)"
            )
        # prefer the actual player client over helper processes
        procs.sort(key=lambda t: (0 if "playerbeta" in t[1].lower() else 1, t[0]))

        errors: list[str] = []
        for pid, exe in procs:
            try:
                self._attach_pid(pid, exe)
                self.log(f"[+] attached pid={pid} {exe} base=0x{self.base:x}")
                return
            except AttachError as e:
                errors.append(f"pid {pid} ({exe}): {e}")
                if self.mem:
                    self.mem.close()
                    self.mem = None
        raise AttachError("all Roblox processes failed:\n  " + "\n  ".join(errors))

    def _dm_verified(self, dm: int) -> bool:
        """A DataModel candidate is real when it has a child literally named
        'Players'. Calibrates the ClassDescriptor class-name offset on that
        child (its class is known: 'Players'); an empty class read is tolerated
        (stale ClassName offset), a wrong one is rejected."""
        if not dm or not self.mem:
            return False
        try:
            players = self.find_child_by_name(dm, "Players")
            if not players or self.instance_name(players) != "Players":
                return False
            if self._cls_name_off is None:
                self._cls_name_off = self._calibrate_class_name(players, "Players")
            cn = self.class_name(players)
            return cn in ("", "Players")
        except Exception:
            return False

    def _attach_pid(self, pid: int, exe: str) -> None:
        mem = Memory(pid)
        if not mem.open():
            raise AttachError(mem.last_error)
        self.mem = mem
        self.pid = pid
        self.base = main_module_base(pid)
        if not self.base:
            raise AttachError("could not get main module base")

        # DataModel candidates, in priority order; each is verified before use
        cands: list[tuple[str, int]] = []

        sched = mem.r64(self.base + self.off.require("TaskScheduler", "Pointer"))
        if sched:
            js = mem.r64(sched + self.off.require("TaskScheduler", "JobStart"))
            je = mem.r64(sched + self.off.require("TaskScheduler", "JobEnd"))
            if js and je and je > js:
                count = min((je - js) // 8, 512)
                buf = mem.read(js, count * 8)
                if buf:
                    for i in range(count):
                        job = struct.unpack_from("<Q", buf, i * 8)[0]
                        if not job:
                            continue
                        name = mem.r_string(job + self.off.require("TaskScheduler", "JobName"))
                        if "render" in name.lower():
                            fake = mem.r64(job + self.off.require("RenderJob", "FakeDataModel"))
                            if fake:
                                dm = mem.r64(fake + self.off.require("FakeDataModel", "RealDataModel"))
                                if dm:
                                    cands.append((f"render job {name!r}", dm))
                            self.ve_render = mem.r64(job + self.off.require("RenderJob", "RenderView"))

        ve = mem.r64(self.base + self.off.require("VisualEngine", "Pointer"))
        if ve:
            self.ve = ve
            fake = mem.r64(ve + self.off.require("VisualEngine", "FakeDataModel"))
            if fake:
                dm = mem.r64(fake + self.off.require("FakeDataModel", "RealDataModel"))
                if dm:
                    cands.append(("visual engine", dm))

        # dump global: FakeDataModel::Pointer -> fake object -> real DataModel
        fglob_off = self.off.get("FakeDataModel", "Pointer", 0) or 0
        if fglob_off:
            fglob = mem.r64(self.base + fglob_off)
            if fglob:
                dm = mem.r64(fglob + self.off.require("FakeDataModel", "RealDataModel"))
                if dm:
                    cands.append(("fake datamodel global", dm))

        dm = 0
        how = ""
        seen: set[int] = set()
        for lbl, cand in cands:
            if cand in seen:
                continue
            seen.add(cand)
            if self._dm_verified(cand):
                dm, how = cand, lbl
                break
        if not dm:
            detail = "; ".join(f"{lbl} 0x{v:x}" for lbl, v in cands)
            raise AttachError(
                "could not resolve a verifiable DataModel "
                "- offsets may need re-dumping"
                + (f" (checked: {detail})" if detail else " (no candidates)" )
            )
        self.log(f"[dm] DataModel verified via {how} @ 0x{dm:x}")

        players = self.find_child_by_name(dm, "Players")
        self.dm = dm
        self.players_inst = players
        self.workspace = mem.r64(dm + self.off.require("DataModel", "Workspace"))
        self.place_id = mem.r_i32(dm + self.off.require("DataModel", "PlaceId"))
        # cache VisualEngine if we got it from the render job path
        if not self.ve:
            self.ve = mem.r64(self.base + self.off.require("VisualEngine", "Pointer"))

    def alive(self) -> bool:
        if not self.mem or not self.mem.handle:
            return False
        # cheap probe: DataModel still readable
        return bool(self.mem.r64(self.dm + 8))

    # -- world snapshot -------------------------------------------------------
    def read_frame(self, max_players: int = 40, max_parts: int = 32) -> FrameSnapshot | None:
        if not self.alive():
            return None
        mem = self.mem
        snap = FrameSnapshot()
        snap.pid = self.pid
        snap.place_id = self.place_id
        snap.stamp = time.time()
        snap.cam_pos = None

        # camera / view matrix / viewport
        if self.ve:
            snap.matrix = mem.r_mat4(self.ve + self.off.require("VisualEngine", "ViewMatrix"))
            dw = self.off.get("VisualEngine", "Dimensions", 0) or 0
            if dw:
                dims_raw = mem.read(self.ve + dw, 8)
                if dims_raw:
                    vp = _read_viewport_pair(dims_raw)
                    if vp:
                        snap.vp_w, snap.vp_h = vp
        if snap.matrix is None:
            return snap  # matrix missing -> overlay shows "no view matrix" state

        if self.workspace:
            cam_inst = mem.r64(self.workspace + self.off.require("Workspace", "CurrentCamera"))
            if cam_inst:
                cam_pos_off = self.off.get("Camera", "Position", 0) or 0
                if cam_pos_off:
                    snap.cam_pos = mem.r_vec3(cam_inst + cam_pos_off)

        if not snap.vp_w:
            ws_cur_cam = mem.r64(self.workspace + self.off.require("Workspace", "CurrentCamera")) if self.workspace else 0
            if ws_cur_cam:
                cam_vp = self.off.get("Camera", "ViewportSize", 0) or 0
                if cam_vp:
                    raw = mem.read(ws_cur_cam + cam_vp, 8)
                    if raw:
                        vp = _read_viewport_pair(raw)
                        if vp:
                            snap.vp_w, snap.vp_h = vp

        players_inst = self.players_inst
        local = mem.r64(players_inst + self.off.require("Player", "LocalPlayer"))
        off_display = self.off.require("Player", "DisplayName")
        off_uid = self.off.require("Player", "UserId")
        off_char = self.off.require("Player", "ModelInstance")
        off_h_health = self.off.require("Humanoid", "Health")
        off_h_max = self.off.require("Humanoid", "MaxHealth")
        off_bp_prim = self.off.require("BasePart", "Primitive")
        off_p_pos = self.off.require("Primitive", "Position")
        off_p_rot = self.off.require("Primitive", "Rotation")
        off_p_size = self.off.require("Primitive", "Size")

        count = 0
        for p in self.children(players_inst):
            if count >= max_players:
                break
            if not p:
                continue
            try:
                if self.class_name(p) != "Player":
                    continue
            except Exception:
                continue

            ps = PlayerSnapshot()
            ps.uid = mem.r32(p + off_uid)
            ps.name = self.instance_name(p)
            ps.display = mem.r_string(p + off_display) or ps.name
            ps.is_local = (p == local)

            char = mem.r64(p + off_char)
            if not char:
                # character not spawned yet - still list the player
                snap.players.append(ps)
                count += 1
                continue

            cached = self._character_cache.get(p)
            if cached is None or cached[0] != char:
                humanoid = 0
                root_prim = 0
                root_priority = len(ROOT_PART_NAMES)
                for c in self.children(char, cap=256):
                    if not c:
                        continue
                    cn = self.class_name(c)
                    if not humanoid and cn == "Humanoid":
                        humanoid = c
                    if cn not in BASEPART_CLASSES or root_priority == 0:
                        continue
                    part_name = self.instance_name(c)
                    try:
                        priority = ROOT_PART_NAMES.index(part_name)
                    except ValueError:
                        continue
                    if priority >= root_priority:
                        continue
                    prim = mem.r64(c + off_bp_prim)
                    if prim:
                        root_prim = prim
                        root_priority = priority
                cached = (char, humanoid, root_prim)
                self._character_cache[p] = cached
            _, humanoid, root_prim = cached

            root_box = None
            if root_prim:
                pos = mem.r_vec3(root_prim + off_p_pos)
                rot = mem.r_mat3(root_prim + off_p_rot)
                if _plausible_pos(pos):
                    if rot is None or not _plausible_rot(rot):
                        rot = (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)
                    root_box = (pos, SIMPLE_HITBOX_SIZE, rot)
                else:
                    # The character likely respawned or its root was
                    # replaced; force a fresh child scan next frame.
                    self._character_cache.pop(p, None)
            if humanoid:
                ps.health = mem.r_float(humanoid + off_h_health)
                ps.max_health = mem.r_float(humanoid + off_h_max)
            if root_box is not None:
                ps.parts.append(root_box)
            snap.players.append(ps)
            count += 1
        return snap

    def reload_offsets(self, offsets: Offsets) -> None:
        self.off = offsets
        self._character_cache.clear()


def _read_viewport_pair(raw: bytes) -> tuple[float, float] | None:
    """Viewport width/height stored as two f32 (current build, live-verified
    1366.0 x 745.0 at VisualEngine::Dimensions and Camera::ViewportSize) with a
    two-u32 fallback for older layouts."""
    if len(raw) < 8:
        return None
    w, h = struct.unpack_from("<ff", raw)
    if math.isfinite(w) and math.isfinite(h) and 64.0 <= w <= 16384.0 and 64.0 <= h <= 16384.0:
        return (float(w), float(h))
    w, h = struct.unpack_from("<II", raw)
    if 64 <= w <= 16384 and 64 <= h <= 16384:
        return (float(w), float(h))
    return None


def _plausible_pos(v: tuple[float, float, float]) -> bool:
    return all(math.isfinite(x) and abs(x) < 1e7 for x in v) and any(abs(x) > 1e-4 for x in v)


def _plausible_size(v: tuple[float, float, float]) -> bool:
    return all(math.isfinite(x) and 0.05 < x < 2048.0 for x in v)


def _plausible_rot(m: list[float]) -> bool:
    if not all(math.isfinite(x) and abs(x) <= 10.0 for x in m):
        return False
    # roughly orthonormal?
    r0 = math.sqrt(m[0] ** 2 + m[3] ** 2 + m[6] ** 2)
    r1 = math.sqrt(m[1] ** 2 + m[4] ** 2 + m[7] ** 2)
    r2 = math.sqrt(m[2] ** 2 + m[5] ** 2 + m[8] ** 2)
    return 0.7 < r0 < 1.4 and 0.7 < r1 < 1.4 and 0.7 < r2 < 1.4


# ----------------------------------------------------------------------------
# Projection
# ----------------------------------------------------------------------------
# Layouts supported (cycle with F7 in the overlay):
#   0: classic rows:  outX = m0..3, outY = m4..7, w    = m8..11   (legacy)
#   1: column-major:  outX = m0,m4,m8, m12;  outY = m1,m5,m9,m13; w = m3,m7,m11,m15
#   2: like 1 but Y not flipped
#   3: row-major clip matrix: outX = m0..3, outY = m4..7, w = m12..15


def world_to_screen(
    matrix: list[float],
    x: float,
    y: float,
    z: float,
    vp_w: float,
    vp_h: float,
    mode: int = 0,
) -> tuple[float, float, bool]:
    """Returns (sx, sy, visible). visible False -> point behind camera / clipped."""
    if mode in (0, 3):
        ox = matrix[0] * x + matrix[1] * y + matrix[2] * z + matrix[3]
        oy = matrix[4] * x + matrix[5] * y + matrix[6] * z + matrix[7]
        if mode == 3:
            w = matrix[12] * x + matrix[13] * y + matrix[14] * z + matrix[15]
        else:
            w = matrix[8] * x + matrix[9] * y + matrix[10] * z + matrix[11]
    else:
        ox = matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12]
        oy = matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13]
        w = matrix[3] * x + matrix[7] * y + matrix[11] * z + matrix[15]
    if w <= 0.001:
        return (0.0, 0.0, False)
    sx = (vp_w / 2.0) * (1.0 + ox / w)
    if mode == 2:
        sy = (vp_h / 2.0) * (1.0 + oy / w)
    else:
        sy = (vp_h / 2.0) * (1.0 - oy / w)
    return (sx, sy, True)


def box_edges() -> tuple[tuple[int, int], ...]:
    """Corner ordering used by project_box()."""
    return (
        (0, 1), (1, 3), (3, 2), (2, 0),  # bottom
        (4, 5), (5, 7), (7, 6), (6, 4),  # top
        (0, 4), (1, 5), (2, 6), (3, 7),  # pillars
    )


def project_box(
    matrix: list[float],
    center: tuple[float, float, float],
    size: tuple[float, float, float],
    rot: tuple[float, ...],
    vp_w: float,
    vp_h: float,
    mode: int = 0,
) -> list[tuple[float, float]] | None:
    """Project an oriented box; returns 8 screen corners (some may be clipped
    markers at huge coords) or None if fully behind the camera."""
    hx, hy, hz = size[0] / 2.0, size[1] / 2.0, size[2] / 2.0
    cx, cy, cz = center
    r = rot
    pts: list[tuple[float, float, float]] = []
    for sx_, sy_, sz_ in (
        (-hx, -hy, -hz), (hx, -hy, -hz), (-hx, hy, -hz), (hx, hy, -hz),
        (-hx, -hy, hz), (hx, -hy, hz), (-hx, hy, hz), (hx, hy, hz),
    ):
        # world = center + R * local_corner   (R is column-major 3x3 as dumped)
        wx = cx + r[0] * sx_ + r[3] * sy_ + r[6] * sz_
        wy = cy + r[1] * sx_ + r[4] * sy_ + r[7] * sz_
        wz = cz + r[2] * sx_ + r[5] * sy_ + r[8] * sz_
        pts.append((wx, wy, wz))

    out: list[tuple[float, float]] = []
    any_vis = False
    for (wx, wy, wz) in pts:
        sx, sy, vis = world_to_screen(matrix, wx, wy, wz, vp_w, vp_h, mode)
        if vis:
            any_vis = True
        out.append((sx if vis else float("nan"), sy if vis else float("nan")))
    return out if any_vis else None
