"""Probe: dump the attach chain on the live client to find where interpretation diverges."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import (Memory, Offsets, list_processes_by_name, main_module_base)  # noqa: E402

off = Offsets()
off.merge_file(os.path.expanduser("~") + r"\Documents\mcro\New Text Document.json")

procs = list_processes_by_name(["robloxplayerbeta"])
print("procs:", procs)
pid = procs[0][0]
mem = Memory(pid)
if not mem.open():
    print("open failed:", mem.last_error)
    sys.exit(1)
base = main_module_base(pid)
print(f"pid={pid} base=0x{base:x}")

sched = mem.r64(base + off.require("TaskScheduler", "Pointer"))
print(f"sched = 0x{sched:x}")
if not sched:
    sys.exit(1)
js = mem.r64(sched + off.require("TaskScheduler", "JobStart"))
je = mem.r64(sched + off.require("TaskScheduler", "JobEnd"))
print(f"jobs [0x{js:x} .. 0x{je:x})  count={(je-js)//8 if je>js else -1}")

render_jobs = []
all_jobs = []
if js and je and je > js:
    count = min((je - js) // 8, 512)
    buf = mem.read(js, count * 8)
    for i in range(count):
        job = struct.unpack_from("<Q", buf, i * 8)[0]
        if not job:
            continue
        name = mem.r_string(job + off.require("TaskScheduler", "JobName"))
        all_jobs.append((job, name))
        if "render" in name.lower():
            render_jobs.append((job, name))
print(f"total jobs parsed: {len(all_jobs)}")
for job, name in all_jobs[:25]:
    print(f"  job 0x{job:x} name={name!r}")
print("render jobs:", [(hex(j), n) for j, n in render_jobs])

FJDM = off.require("RenderJob", "FakeDataModel")   # 0x38
RJDM = off.require("RenderJob", "RealDataModel")   # 0x1f0
FDM_REAL = off.require("FakeDataModel", "RealDataModel")  # 0x1f8

cands = []
for job, name in render_jobs[:3]:
    fake = mem.r64(job + FJDM)
    direct_real = mem.r64(job + RJDM)
    via_fake = mem.r64(fake + FDM_REAL) if fake else 0
    print(f"\njob {name!r} @0x{job:x}:")
    print(f"  fake_dm          = r64(job+0x{FJDM:x}) = 0x{fake:x}")
    print(f"  direct_real      = r64(job+0x{RJDM:x}) = 0x{direct_real:x}")
    print(f"  via_fake_real    = r64(fake+0x{FDM_REAL:x}) = 0x{via_fake:x}")
    for label, cand in (("direct_real", direct_real), ("via_fake_real", via_fake)):
        if cand:
            cands.append((label, cand))

# VisualEngine fallback
VEP = off.require("VisualEngine", "Pointer")
VE_FDM = off.require("VisualEngine", "FakeDataModel")
ve = mem.r64(base + VEP)
print(f"\nVisualEngine = r64(base+0x{VEP:x}) = 0x{ve:x}")
if ve:
    vfake = mem.r64(ve + VE_FDM)
    vreal = mem.r64(vfake + FDM_REAL) if vfake else 0
    print(f"  ve_fake = 0x{vfake:x}  ve_real = 0x{vreal:x}")
    if vreal:
        cands.append(("ve_real", vreal))


def describe(inst: int, label: str) -> None:
    if not inst:
        return
    cd = mem.r64(inst + off.require("Instance", "ClassDescriptor"))
    cname = mem.r_string(cd + off.require("Instance", "ClassName")) if cd else "<no cd>"
    nc = mem.r64(inst + off.require("Instance", "NameContainer"))
    iname = mem.r_string(nc + off.require("Instance", "Name")) if nc else "<no nc>"
    cs = off.require("Instance", "ChildrenStart")
    ce = off.require("Instance", "ChildrenEnd")
    start = mem.r64(inst + cs)
    end = mem.r64(inst + cs + ce)
    print(f"\n[{label}] inst=0x{inst:x}")
    print(f"  class_descriptor=0x{cd:x} class={cname!r}")
    print(f"  name_container=0x{nc:x} name={iname!r}")
    print(f"  children vec begin=0x{start:x} end=0x{end:x} n={(end-start)//8 if end>start else -1}")
    if end > start and (end - start) // 8 <= 64:
        buf = mem.read(start, (end - start) // 8 * 8)
        if buf:
            for i in range((end - start) // 8):
                c = struct.unpack_from("<Q", buf, i * 8)[0]
                if not c:
                    print(f"    child[{i}] = NULL")
                    continue
                ccd = mem.r64(c + off.require("Instance", "ClassDescriptor"))
                ccn = mem.r_string(ccd + off.require("Instance", "ClassName")) if ccd else "<no cd>"
                cnc = mem.r64(c + off.require("Instance", "NameContainer"))
                cin = mem.r_string(cnc + off.require("Instance", "Name")) if cnc else "<no nc>"
                print(f"    child[{i}] 0x{c:x} class={ccn!r} name={cin!r}")


for label, cand in cands:
    describe(cand, label)

mem.close()
