"""nthexternal - fullscreen transparent hitbox overlay window.

Ported from the original rbx_esp.py Overlay. All projection, prediction and
window-mapping logic is unchanged; the overlay now lives on a Toplevel of the
shared Tk root (so the control panel and overlay share one mainloop), the HUD
text is rebranded and the HUD itself can be hidden from the panel.
"""

from __future__ import annotations

import math
import os
import queue
import time
import tkinter as tk

from rbx_core import (  # noqa: E402
    FrameSnapshot,
    PlayerSnapshot,
    box_edges,
    project_box,
    world_to_screen,
)
from state import AppState  # noqa: E402  (type only)

IS_WIN = os.name == "nt"

TRANS = "#010203"          # overlay transparent/click-through color (never draw it)
BOX_COLOR = "#ff2d55"
HEAD_COLOR = "#ffd60a"
TAG_COLOR = "#7dff9e"
HUD_COLOR = "#9fd8ff"
ERR_COLOR = "#ff6b6b"
BRAND = "NTH//EXTERNAL"

RENDER_INTERVAL_MS = 16
PREDICTION_EXTRA_LEAD = 0.010
PREDICTION_MAX_LEAD = 0.120


def _chunks(s: str, n: int) -> list[str]:
    return [s[i:i + n] for i in range(0, len(s), n)] or [""]


def find_roblox_window(pid: int):
    """Largest visible top-level window of pid -> (hwnd, x, y, w, h) of client area."""
    if not IS_WIN:
        return None
    import ctypes
    from ctypes import wintypes

    u32 = ctypes.WinDLL("user32", use_last_error=True)
    hits: list[int] = []

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd: int, _lparam: int) -> bool:
        if u32.IsWindowVisible(hwnd):
            wpid = wintypes.DWORD(0)
            u32.GetWindowThreadProcessId(hwnd, ctypes.byref(wpid))
            if wpid.value == pid:
                buf = ctypes.create_unicode_buffer(256)
                u32.GetWindowTextW(hwnd, buf, 256)
                if buf.value:
                    hits.append(hwnd)
        return True

    u32.EnumWindows(WNDENUMPROC(cb), 0)

    best = None
    best_area = 0
    for hwnd in hits:
        rc = wintypes.RECT()
        if not u32.GetClientRect(hwnd, ctypes.byref(rc)):
            continue
        area = (rc.right - rc.left) * (rc.bottom - rc.top)
        if area > best_area and rc.right > 100 and rc.bottom > 100:
            best_area = area
            best = hwnd
    if not best:
        return None
    pt = wintypes.POINT(0, 0)
    u32.ClientToScreen(best, ctypes.byref(pt))
    rc = wintypes.RECT()
    u32.GetClientRect(best, ctypes.byref(rc))
    return (best, pt.x, pt.y, rc.right - rc.left, rc.bottom - rc.top)


class Overlay:
    def __init__(self, root: tk.Tk, app: AppState, snap_q: "queue.Queue[FrameSnapshot]",
                 reader, selftest: bool) -> None:
        self.app = app
        self.snap_q = snap_q
        self.reader = reader
        self.selftest = selftest

        self.root = tk.Toplevel(root)
        self.root.title("nthexternal - overlay")
        try:
            self.root.attributes("-fullscreen", True)
            self.root.attributes("-topmost", True)
            self.root.attributes("-transparentcolor", TRANS)
        except tk.TclError:
            pass  # non-Windows dev preview
        self.root.overrideredirect(True)
        self.root.configure(bg=TRANS)

        self.canvas = tk.Canvas(self.root, bg=TRANS, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.root.update_idletasks()
        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()

        self.latest: FrameSnapshot | None = None
        self.previous: FrameSnapshot | None = None
        self.edges = box_edges()
        self.fps = 0.0
        self._fps_t = time.time()
        self._fps_n = 0

    # -- drawing helpers -------------------------------------------------------
    def map_point(self, gx: float, gy: float, win,
                  vp_w: float, vp_h: float) -> tuple[int, int]:
        if win and vp_w > 1 and vp_h > 1:
            _, wx, wy, ww, wh = win
            return (int(wx + gx * ww / vp_w), int(wy + gy * wh / vp_h))
        # fallback: scale viewport across the whole screen
        if vp_w > 1 and vp_h > 1:
            return (int(gx * self.screen_w / vp_w), int(gy * self.screen_h / vp_h))
        return (int(gx), int(gy))

    def hud(self, lines: list[tuple[str, str]]) -> None:
        x, y = 12, self.screen_h - 14 - 16 * len(lines)
        for text, color in lines:
            self.canvas.create_text(x + 1, y + 1, text=text, fill="#000000",
                                    font=("Consolas", 10), anchor="w")
            self.canvas.create_text(x, y, text=text, fill=color,
                                    font=("Consolas", 10), anchor="w")
            y += 16

    def tag(self, cx: int, cy: int, text: str, color: str) -> None:
        self.canvas.create_text(cx + 1, cy + 1, text=text, fill="#000000",
                                font=("Consolas", 9), anchor="s")
        self.canvas.create_text(cx, cy, text=text, fill=color,
                                font=("Consolas", 9), anchor="s")

    def render_parts(self, snap: FrameSnapshot, ps: PlayerSnapshot):
        """Return slightly forward-predicted part positions for rendering.

        The reader samples a whole frame over several milliseconds.  Using the
        last two snapshots lets the overlay draw where a moving character is
        now instead of where it was when the read began.  Geometry and all
        game state remain unchanged; this only affects displayed positions.
        """
        parts = ps.parts
        previous = self.previous
        if previous is None or snap.stamp <= previous.stamp:
            return parts

        # The root position is sampled before the frame is fully read and
        # reaches the canvas a little later.  Add a small fixed lead so the
        # rendered box catches the character instead of following behind it.
        lead = min(max(time.time() - snap.stamp, 0.0) + PREDICTION_EXTRA_LEAD,
                   PREDICTION_MAX_LEAD)
        if lead <= 0.001:
            return parts

        old = next((p for p in previous.players if p.uid == ps.uid), None)
        if old is None or len(old.parts) != len(parts):
            return parts

        dt = snap.stamp - previous.stamp
        if dt <= 0.001 or dt > 0.25:
            return parts

        predicted = []
        for (pos, size, rot), (old_pos, _old_size, _old_rot) in zip(parts, old.parts):
            vx = (pos[0] - old_pos[0]) / dt
            vy = (pos[1] - old_pos[1]) / dt
            vz = (pos[2] - old_pos[2]) / dt
            speed = math.sqrt(vx * vx + vy * vy + vz * vz)
            if speed > 250.0:
                scale = 250.0 / speed
                vx, vy, vz = vx * scale, vy * scale, vz * scale
            predicted.append(((pos[0] + vx * lead,
                               pos[1] + vy * lead,
                               pos[2] + vz * lead), size, rot))
        return predicted

    # -- frame -----------------------------------------------------------------
    def draw(self) -> None:
        self.canvas.delete("all")
        if getattr(self.app, "paused", False):
            # Start/Stop quick action: keep the loop + fps alive, draw only a
            # faint whisper so the user is never lost.
            self.hud([(BRAND + "  (paused)", "#5a7d94"),
                      ("press Start in the panel to resume", "#5a7d94")])
            self._fps_n += 1
            now = time.time()
            if now - self._fps_t >= 1.0:
                self.fps = self._fps_n / (now - self._fps_t)
                self._fps_n = 0
                self._fps_t = now
            return
        newest = None
        try:
            while True:
                newest = self.snap_q.get_nowait()
        except queue.Empty:
            pass
        if newest is not None:
            self.previous = self.latest
            self.latest = newest

        draw_boxes, draw_names, show_hud, mode = self.app.snapshot_flags()
        snap = self.latest

        hud_lines: list[tuple[str, str]] = []
        if snap is None or snap.matrix is None:
            hud_lines.append((BRAND, HUD_COLOR))
            hud_lines.append((f"state: {self.reader.status}", ERR_COLOR))
            if self.reader.error:
                for chunk in _chunks(self.reader.error, 96):
                    hud_lines.append((chunk, ERR_COLOR))
            hud_lines.append(("waiting for a readable Roblox client...", HUD_COLOR))
            hud_lines.append(("F8 quit  F9 panel", HUD_COLOR))
        else:
            win = find_roblox_window(snap.pid) if not self.selftest else None
            vp_w, vp_h = snap.vp_w, snap.vp_h
            if (vp_w <= 1 or vp_h <= 1) and win:
                # memory viewport unreadable -> use the game window client size
                _, _, _, ww, wh = win
                vp_w, vp_h = float(ww), float(wh)
            n_drawn = 0
            m = snap.matrix
            for ps in snap.players:
                if ps.is_local or not ps.parts:
                    continue
                render_parts = self.render_parts(snap, ps)
                # player-level tag anchor: top of the highest drawn box
                tag_y = None
                tag_x = None
                if draw_boxes:
                    for idx, (pos, size, rot) in enumerate(render_parts):
                        corners = project_box(m, pos, size, rot, vp_w, vp_h, mode)
                        if corners is None:
                            continue
                        scr = [self.map_point(px, py, win, vp_w, vp_h)
                               for (px, py) in corners if not (math.isnan(px) or math.isnan(py))]
                        if len(scr) < 2:
                            continue
                        color = HEAD_COLOR if idx == ps.head_index else BOX_COLOR
                        for (a, b) in self.edges:
                            pa = corners[a]
                            pb = corners[b]
                            if not all(math.isfinite(v) for v in (*pa, *pb)):
                                continue
                            # A bad matrix or a point just beyond the clip
                            # plane should never hand Tk an invalid coordinate.
                            if max(abs(v) for v in (*pa, *pb)) > 1e6:
                                continue
                            sa = self.map_point(pa[0], pa[1], win, vp_w, vp_h)
                            sb = self.map_point(pb[0], pb[1], win, vp_w, vp_h)
                            self.canvas.create_line(sa[0], sa[1], sb[0], sb[1],
                                                    fill=color, width=2)
                        ys = [p[1] for p in scr]
                        xs = [p[0] for p in scr]
                        top = min(ys)
                        mid = (min(xs) + max(xs)) / 2
                        if tag_y is None or top < tag_y:
                            tag_y, tag_x = top, mid
                        n_drawn += 1
                if draw_names and (tag_y is not None or ps.parts):
                    # anchor at head if no boxes drawn
                    if tag_y is None and ps.head_index >= 0:
                        pos = render_parts[ps.head_index][0]
                        sx, sy, vis = world_to_screen(m, pos[0], pos[1], pos[2], vp_w, vp_h, mode)
                        if vis:
                            tag_x, tag_y = self.map_point(sx, sy, win, vp_w, vp_h)
                    if tag_x is not None and tag_y is not None:
                        hp_txt = ""
                        if ps.max_health > 0:
                            hp_txt = f" {int(ps.health)}/{int(ps.max_health)}"
                        dist_txt = ""
                        if snap.cam_pos:
                            d = math.dist(snap.cam_pos, render_parts[0][0])
                            dist_txt = f" {d:.0f}m"
                        self.tag(int(tag_x), int(tag_y) - 6,
                                 f"{ps.display}{hp_txt}{dist_txt}", TAG_COLOR)
            hud_lines.append((BRAND, HUD_COLOR))
            hud_lines.append((f"pid {snap.pid}  place {snap.place_id}  players {len(snap.players)} "
                              f"  boxes drawn {n_drawn}", HUD_COLOR))
            hud_lines.append((f"proj mode {mode}  boxes[{'x' if draw_boxes else ' '}] "
                              f"names[{'x' if draw_names else ' '}]  fps {self.fps:.0f}", HUD_COLOR))
            hud_lines.append(("F1 boxes  F2 names  F4 reload  F7 mode  F9 panel  F8 quit", HUD_COLOR))

        if show_hud:
            self.hud(hud_lines)
        else:
            # even with the HUD hidden, keep a one-line whisper so the user
            # always knows how to get the panel / quit back
            self.hud([(BRAND, "#3a3b52")])

        self._fps_n += 1
        now = time.time()
        if now - self._fps_t >= 1.0:
            self.fps = self._fps_n / (now - self._fps_t)
            self._fps_n = 0
            self._fps_t = now

    def run(self) -> None:
        self.root.after(RENDER_INTERVAL_MS, self._tick)

    def _tick(self) -> None:
        if self.app.quit:
            return
        started = time.perf_counter()
        try:
            self.draw()
        except Exception as e:
            try:
                self.reader.log(f"draw error: {type(e).__name__}: {e}")
            except Exception:
                pass
        # Schedule against the start of this tick, so draw time does not add
        # another full interval of latency when the canvas is busy.
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        delay_ms = max(1, RENDER_INTERVAL_MS - int(elapsed_ms))
        self.root.after(delay_ms, self._tick)
