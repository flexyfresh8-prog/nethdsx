"""
nthexternal - external world-state viewer + hitbox overlay (anti-cheat testing)

Rebuilt UI edition of the original rbx_hitbox_esp project.  The memory core
(rbx_core.py) is unchanged: user-mode external reads the Roblox client via
ReadProcessMemory using the offset files dropped in Documents/mcro (or next
to the executable).

Run:            nthexternal.exe            (or python nthexternal.py)
Self test:      nthexternal.exe --selftest
Diagnostics:    nthexternal.exe --diag     (also available from the panel)
Custom offsets: nthexternal.exe --offsets "C:\\path\\to\\file.json"

Control panel:  toggle menu for hitboxes / tags / HUD, projection mode,
                offsets reload, live console.  Hotkeys (global, work while
                the game has focus):

    F1  toggle hitbox boxes          (panel: TOGGLE MENU)
    F2  toggle name/health tags      (panel: TOGGLE MENU)
    F3  toggle on-screen HUD         (panel: TOGGLE MENU)
    F4  reload offset files          (panel: RELOAD OFFSETS)
    F7  cycle projection mode 0..3   (panel: PROJECTION)
    F9  show/hide the control panel
    F8  quit
"""

from __future__ import annotations

import argparse
import ctypes
import os
import queue
import sys
import threading
import time
import tkinter as tk

IS_WIN = os.name == "nt"

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import rbx_core  # noqa: E402
from rbx_core import (  # noqa: E402
    AttachError,
    FrameSnapshot,
    Game,
    Offsets,
    PlayerSnapshot,
)
from overlay import Overlay, find_roblox_window  # noqa: E402  (find_roblox_window re-exported for parity)
from panel import ControlPanel  # noqa: E402
from state import AppState  # noqa: E402

APP_NAME = "nthexternal"
APP_VERSION = "2.1"

if IS_WIN:
    from ctypes import wintypes
    u32 = ctypes.WinDLL("user32", use_last_error=True)
    try:
        SHCORE = ctypes.WinDLL("shcore", use_last_error=True)
        SHCORE.SetProcessDpiAwareness(1)  # match physical pixels
    except Exception:
        SHCORE = None
else:
    u32 = None

WM_HOTKEY = 0x0312

# offsets required by the reader; validated on load
REQUIRED = [
    ("TaskScheduler", "Pointer"),
    ("TaskScheduler", "JobStart"),
    ("TaskScheduler", "JobEnd"),
    ("TaskScheduler", "JobName"),
    ("RenderJob", "FakeDataModel"),
    ("RenderJob", "RealDataModel"),
    ("VisualEngine", "Pointer"),
    ("VisualEngine", "FakeDataModel"),
    ("VisualEngine", "ViewMatrix"),
    ("VisualEngine", "Dimensions"),
    ("FakeDataModel", "RealDataModel"),
    ("DataModel", "Workspace"),
    ("DataModel", "PlaceId"),
    ("Instance", "NameContainer"),
    ("Instance", "Name"),
    ("Instance", "ClassDescriptor"),
    ("Instance", "ClassName"),
    ("Instance", "ChildrenStart"),
    ("Instance", "ChildrenEnd"),
    ("Player", "LocalPlayer"),
    ("Player", "DisplayName"),
    ("Player", "UserId"),
    ("Player", "ModelInstance"),
    ("Humanoid", "Health"),
    ("Humanoid", "MaxHealth"),
    ("BasePart", "Primitive"),
    ("Primitive", "Position"),
    ("Primitive", "Rotation"),
    ("Primitive", "Size"),
    ("Workspace", "CurrentCamera"),
    ("Camera", "Position"),
    ("Misc", "StringLength"),
]

# ---------------------------------------------------------------------------
# frozen-executable path handling
# ---------------------------------------------------------------------------

if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))

OFFSET_NAMES = ("offsets.json", "offsets.txt",
                "New Text Document.json", "New Text Document.txt")
LOG_PATH = os.path.join(APP_DIR, f"{APP_NAME}.log")


def install_offset_resolver() -> None:
    """Make offset discovery work next to the packaged exe (and inside it)."""
    orig = rbx_core.find_offset_files

    def resolver(explicit: str | None = None) -> list[str]:
        if explicit:
            return [explicit]
        for base in (APP_DIR, getattr(sys, "_MEIPASS", None)):
            if not base:
                continue
            hits = [os.path.join(base, n) for n in OFFSET_NAMES
                    if os.path.isfile(os.path.join(base, n))]
            if hits:
                return hits
        return orig(None)  # Documents/mcro

    rbx_core.find_offset_files = resolver


# ---------------------------------------------------------------------------
# Reader thread  (ported from rbx_esp.py, status metadata added for the panel)
# ---------------------------------------------------------------------------

class Reader(threading.Thread):
    def __init__(self, app: AppState, out: queue.Queue, log_path: str,
                 offsets_arg: str | None) -> None:
        super().__init__(daemon=True)
        self.app = app
        self.out = out
        self.log_path = log_path
        self.offsets_arg = offsets_arg
        self.game: Game | None = None
        self.off: Offsets | None = None
        self.off_files: list[str] = []
        self.off_mtimes: dict[str, float] = {}
        self.status = "starting"
        self.error = ""
        self.players_seen = 0
        self.last_ok = 0.0
        self.last_pid = 0
        self.last_place = 0
        self.bytes_rate = 0.0     # UI: estimated bytes/sec actually read
        self.last_objects = 0     # UI: primitives tracked in the last frame
        self._last_frame_t = 0.0
        self.ui_q: queue.Queue = queue.Queue()  # panel console feed

    def log(self, msg: str) -> None:
        line = f"[{time.strftime('%H:%M:%S')}] {msg}"
        self.ui_q.put(line)
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass

    def load_offsets(self) -> None:
        files = rbx_core.find_offset_files(self.offsets_arg)
        if not files:
            raise AttachError(
                "no offset files found - drop your dumper .json/.txt into "
                "Documents\\mcro or next to the executable, or pass --offsets"
            )
        off = Offsets()
        for f in files:
            n = off.merge_file(f)
            self.log(f"offsets: {os.path.basename(f)} -> {n} entries")
        missing = off.missing_required(REQUIRED)
        if missing:
            self.log(f"offsets missing required fields: {', '.join(missing)}")
            raise AttachError("offset file missing required fields:\n  " + ", ".join(missing))
        self.off = off
        self.off_files = files
        self.off_mtimes = {f: os.path.getmtime(f) for f in files}
        self.log(f"offsets loaded from {[os.path.basename(f) for f in files]}")

    def offsets_changed(self) -> bool:
        try:
            for f in self.off_files:
                if os.path.getmtime(f) != self.off_mtimes.get(f):
                    return True
        except OSError:
            pass
        return False

    def run(self) -> None:
        while not self.app.quit:
            frame_ready = False
            try:
                if self.off is None:
                    self.status = "loading offsets"
                    self.load_offsets()
                if self.game is None:
                    self.status = "attaching"
                    g = Game(self.off, log=self.log)
                    g.attach()
                    self.game = g
                    self.error = ""
                    self.status = "attached"
                else:
                    if self.app.reload_requested or self.offsets_changed():
                        with self.app.lock:
                            self.app.reload_requested = False
                        self.log("reloading offsets")
                        try:
                            self.load_offsets()
                            self.game.reload_offsets(self.off)
                            self.status = "offsets reloaded"
                        except AttachError as e:
                            self.error = f"offset reload failed: {e}"
                    if not self.game.alive():
                        self.log("game handle no longer valid - reattaching")
                        self.game.mem.close()
                        self.game = None
                        continue
                    snap = self.game.read_frame()
                    if snap is not None:
                        self.players_seen = len(snap.players)
                        self.last_ok = time.time()
                        self.last_pid = snap.pid
                        self.last_place = snap.place_id
                        frame_ready = snap.matrix is not None
                        # UI instrumentation only: read-rate + tracked-object
                        # estimates for the dashboard cards.  This does not
                        # change what or how the memory core reads.
                        try:
                            now2 = time.time()
                            self.last_objects = sum(len(p.parts)
                                                    for p in snap.players)
                            est = 2048 + 112 * max(1, self.last_objects)
                            if self._last_frame_t > 0:
                                dt = max(0.0005, now2 - self._last_frame_t)
                                inst = min(5e9, est / dt)
                                self.bytes_rate = (inst if self.bytes_rate <= 0
                                                   else self.bytes_rate * 0.8
                                                   + inst * 0.2)
                            self._last_frame_t = now2
                        except Exception:
                            pass
                        try:
                            self.out.put_nowait(snap)
                        except queue.Full:
                            try:
                                self.out.get_nowait()
                                self.out.put_nowait(snap)
                            except queue.Empty:
                                pass
                        self.status = f"reading ({self.players_seen} players)"
                    else:
                        self.status = "reading (no snapshot)"
            except AttachError as e:
                self.status = "waiting for game"
                self.error = str(e).replace("\n", " | ")
                self.game = None
                time.sleep(2.0)
            except Exception as e:  # keep the thread alive no matter what
                self.status = "error"
                self.error = f"{type(e).__name__}: {e}"
                self.log(f"unexpected: {e}")
                time.sleep(1.0)
            # A successful read already takes about one frame interval.  Do
            # not add another 30 ms of sleep, or the overlay visibly trails
            # moving characters.  Keep the slower retry cadence for states
            # where no usable frame is available.
            time.sleep(0.001 if frame_ready else 0.03)


# ---------------------------------------------------------------------------
# Global hotkeys  (F1..F4, F7..F9; F3 and F9 are new UI conveniences)
# ---------------------------------------------------------------------------

class Hotkeys:
    IDS = {1: 0x70, 2: 0x71, 3: 0x72, 4: 0x73, 5: 0x76, 6: 0x77, 7: 0x78}
    #         F1      F2      F3      F4      F7      F8      F9

    def __init__(self, app: AppState, root: tk.Tk, panel: ControlPanel,
                 reader: Reader) -> None:
        self.app = app
        self.root = root
        self.panel = panel
        self.reader = reader
        self.events: queue.Queue[int] = queue.Queue()

    def start(self) -> None:
        if not IS_WIN:
            return
        threading.Thread(target=self._loop, daemon=True).start()
        # Tk callbacks are scheduled here, on the main thread. The hotkey
        # worker only places integer IDs on the queue.
        self.root.after(25, self._poll)

    def _poll(self) -> None:
        if self.app.quit:
            return
        try:
            while True:
                wp = self.events.get_nowait()
                if wp == 1:
                    self.app.toggle_boxes()
                elif wp == 2:
                    self.app.toggle_names()
                elif wp == 3:
                    self.app.toggle_hud()
                elif wp == 4:
                    self.app.request_reload()
                elif wp == 5:
                    self.app.cycle_mode()
                elif wp == 6:
                    self.app.quit = True
                elif wp == 7:
                    self.panel.toggle_visibility()
        except queue.Empty:
            pass
        self.root.after(25, self._poll)

    def _loop(self) -> None:
        from ctypes import wintypes
        for i, vk in self.IDS.items():
            if not u32.RegisterHotKey(None, i, 0, vk):
                self.reader.log(f"hotkey id {i} register failed (err {ctypes.get_last_error()})")
        msg = wintypes.MSG()
        while not self.app.quit:
            r = u32.GetMessageW(ctypes.byref(msg), None, 0, 0)
            if r <= 0:
                break
            if msg.message == WM_HOTKEY:
                self.events.put(int(msg.wParam))
        for i in self.IDS:
            u32.UnregisterHotKey(None, i)


# ---------------------------------------------------------------------------
# Diagnostics (no overlay)
# ---------------------------------------------------------------------------

def run_diag(offsets_arg: str | None, out=print) -> int:
    out("== nthexternal diagnostics ==")
    try:
        files = rbx_core.find_offset_files(offsets_arg)
        if not files:
            out("[-] no offset files found")
            return 1
        off = Offsets()
        for f in files:
            n = off.merge_file(f)
            out(f"[+] {f}: {n} entries")
        missing = off.missing_required(REQUIRED)
        if missing:
            out(f"[-] missing required: {', '.join(missing)}")
        else:
            out("[+] all required offsets present")
        g = Game(off, log=out)
        g.attach()
        out(f"[+] DataModel @ 0x{g.dm:x}  workspace @ 0x{g.workspace:x}  "
            f"VE @ 0x{g.ve:x}  place {g.place_id}")
        snap = g.read_frame()
        if snap is None:
            out("[-] read_frame returned None (game closed?)")
            return 1
        out(f"[+] matrix read: {snap.matrix is not None}")
        out(f"[+] viewport: {snap.vp_w:.0f}x{snap.vp_h:.0f}")
        out(f"[+] players: {len(snap.players)}")
        for ps in snap.players[:10]:
            out(f"    - {ps.display!r} uid={ps.uid} parts={len(ps.parts)} "
                f"hp={ps.health:.0f}/{ps.max_health:.0f} local={ps.is_local}")
        if snap.players and snap.players[1:]:
            target = next((p for p in snap.players if not p.is_local and p.parts), None)
            if target and snap.matrix:
                sx, sy, vis = rbx_core.world_to_screen(
                    snap.matrix, *target.parts[0][0], snap.vp_w, snap.vp_h, 3)
                out(f"[+] sample projection of {target.display!r}: "
                    f"({sx:.1f}, {sy:.1f}) visible={vis} (mode 3)")
        out("[+] diagnostics OK")
        return 0
    except AttachError as e:
        out(f"[-] {e}")
        return 1


# ---------------------------------------------------------------------------
# Self test (no Roblox needed): synthetic snapshot through the whole draw path
# ---------------------------------------------------------------------------

def make_selftest_snapshot() -> FrameSnapshot:
    snap = FrameSnapshot()
    snap.pid = 0
    snap.place_id = 123456789
    snap.vp_w, snap.vp_h = 1920.0, 1080.0
    # mode-3 style matrix: row-major with the perspective divisor in row 4.
    snap.matrix = [1.0, 0.0, 0.0, 0.0,
                   0.0, 1.0, 0.0, 0.0,
                   0.0, 0.0, 0.0, 0.0,
                   0.0, 0.0, -1.0, 0.0]
    snap.cam_pos = (0.0, 3.0, 0.0)

    ident = (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

    p1 = PlayerSnapshot()
    p1.name, p1.display, p1.uid = "tester1", "Tester One", 1
    p1.health, p1.max_health = 80.0, 100.0
    # torso, head, legs around (0, 3, -12)
    p1.parts = [
        ((0.0, 3.0, -12.0), (2.0, 2.0, 1.0), ident),
        ((0.0, 4.7, -12.0), (1.2, 1.2, 1.2), ident),
        ((-0.5, 1.0, -12.0), (1.0, 2.0, 1.0), ident),
        ((0.5, 1.0, -12.0), (1.0, 2.0, 1.0), ident),
    ]
    p1.head_index = 1

    p2 = PlayerSnapshot()
    p2.name, p2.display, p2.uid = "tester2", "Tester Two", 2
    p2.health, p2.max_health = 35.0, 100.0
    p2.parts = [
        ((6.0, 3.0, -16.0), (2.0, 2.0, 1.0), ident),
        ((6.0, 4.7, -16.0), (1.2, 1.2, 1.2), ident),
    ]
    p2.head_index = 1

    local = PlayerSnapshot()
    local.name, local.display, local.uid, local.is_local = "me", "Me", 0, True
    local.parts = [((0.0, 3.0, -8.0), (2.0, 2.0, 1.0), ident)]

    snap.players = [local, p1, p2]
    return snap


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

class Actions:
    """Panel -> app callbacks."""

    def __init__(self, app: AppState, root: tk.Tk, snap_q: queue.Queue,
                 offsets_arg: str | None, console) -> None:
        self.app = app
        self.root = root
        self.snap_q = snap_q
        self.offsets_arg = offsets_arg
        self.console = console
        self.version = APP_VERSION

    def on_preview(self) -> None:
        try:
            self.snap_q.put_nowait(make_selftest_snapshot())
            self.console("preview: injected synthetic players (no game needed)", "ok")
        except Exception as e:
            self.console(f"preview failed: {e}", "err")

    def on_diag(self) -> None:
        def job() -> None:
            buf: list[str] = []
            code = run_diag(self.offsets_arg, out=lambda s: buf.append(str(s)))
            for line in buf:
                self.console(line, "ok" if line.startswith("[+]") else
                             ("err" if line.startswith("[-]") else "info"))
            self.console(f"diagnostics exit code {code}", "ok" if code == 0 else "err")
        self.console("running diagnostics...", "warn")
        threading.Thread(target=job, daemon=True).start()

    def on_open_log(self) -> None:
        path = LOG_PATH
        try:
            if IS_WIN:
                os.startfile(path)  # noqa: S606
            elif sys.platform == "darwin":
                os.system(f'open "{path}"')  # noqa: S605
            else:
                os.system(f'xdg-open "{path}"')  # noqa: S605
        except Exception as e:
            self.console(f"cannot open log ({path}): {e}", "err")


def _quit_watcher(root: tk.Tk, app: AppState) -> None:
    if app.quit:
        try:
            root.destroy()
        except Exception:
            pass
        return
    root.after(100, _quit_watcher, root, app)


def main() -> int:
    ap = argparse.ArgumentParser(prog=APP_NAME)
    ap.add_argument("--offsets", default=None, help="explicit offsets file")
    ap.add_argument("--selftest", action="store_true", help="synthetic-data overlay test")
    ap.add_argument("--diag", action="store_true", help="attach diagnostics, no overlay")
    ap.add_argument("--version", action="version", version=f"{APP_NAME} v{APP_VERSION}")
    args = ap.parse_args()

    install_offset_resolver()

    if args.diag:
        return run_diag(args.offsets)

    app = AppState()
    q: queue.Queue = queue.Queue(maxsize=1)
    reader = Reader(app, q, LOG_PATH, args.offsets)

    root = tk.Tk()
    root.withdraw()

    overlay = Overlay(root, app, q, reader, selftest=bool(args.selftest))
    actions = Actions(app, root, q, args.offsets,
                      console=lambda m, lvl="info": panel.console(m, lvl))
    panel = ControlPanel(root, app, reader, overlay, actions, version=APP_VERSION)
    overlay.run()

    if args.selftest:
        reader.status = "selftest preview"
        reader.log("selftest start")
        q.put(make_selftest_snapshot())
        threading.Thread(target=lambda: (time.sleep(2.0), setattr(app, "quit", True)),
                         daemon=True).start()
        _quit_watcher(root, app)
        root.mainloop()
        print("selftest overlay OK (drew synthetic players)")
        return 0

    Hotkeys(app, root, panel, reader).start()
    reader.start()
    _quit_watcher(root, app)
    root.mainloop()
    app.quit = True
    if reader.game and reader.game.mem:
        reader.game.mem.close()
    print("bye")
    return 0


if __name__ == "__main__":
    sys.exit(main())
