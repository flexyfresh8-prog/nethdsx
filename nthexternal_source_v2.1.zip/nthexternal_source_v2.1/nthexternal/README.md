# NTHEXTERNAL v2.1 — external world-state reader + hitbox overlay

## What's new in 2.1 (UI refresh)

- **Rounded everything**: cards, pills, buttons and nav items got bigger
  corner radii, and the borderless window itself is clipped to a rounded
  rectangle (`SetWindowRgn`, works on every Windows version — Win11 also
  gets the DWM round treatment on top).
- **More animations**: page-slide transitions when switching tabs, the
  sidebar active pill glides between items, background waves drift, the
  sidebar status dot and the Reader Status pills pulse, buttons tween their
  hover state, stat values ease toward their live targets and the mascot
  section carries an animated purple dash ring.
- **Mascot square section on Overview**: a dedicated square card on the
  home tab plays the goth mascot GIF (4 frames, 250 ms) inside a black
  inset, framed by the shimmering purple ring. The window stays exactly
  800x500 — the Overview layout was rearranged (Quick Actions moved to the
  header strip, Performance widened, Reader Status became a 2x2 grid) so
  everything still fits. The gif ships inside the exe (`app/nth_mascot.gif`).
- Everything else behaves exactly as before: same hotkeys, same reader,
  same overlay.

Rebranded, rebuilt-UI edition of your `rbx_hitbox_esp` project. The memory
core (`rbx_core.py`) is byte-for-byte your original code — nothing about how
it reads the game changed. What changed:

- **New dashboard UI (800x500, sidebar tabs)**: the app opens both the
  fullscreen transparent overlay *and* a fixed 800x500 dashboard window.
  Tabs on the left: **Overview / Reader / Visuals / Settings / About**.
- **Overview tab**: stat cards with sparklines (Read Rate MB/s, Objects
  tracked, Memory MB — all live values), Reader Status (Core Engine /
  Memory Pipeline / Visual Module / Diagnostics), Performance chart with
  1m/5m/1h ranges (overlay fps history), Quick Actions (Start, Stop, Reload,
  Settings) and the NTH brand card.
- **Visuals tab**: animated switches for Hitbox boxes (F1), Name/HP/distance
  tags (F2) and the on-screen HUD (F3) — they mirror the global hotkeys,
  plus the projection mode selector (M0–M3, mirrors F7).
- **Reader tab**: live attach state (pid, place, players, fps, offsets),
  offsets card with hot-reload (F4) and the reader/diagnostics console.
- **Settings tab**: always-on-top, open log, offsets file + hotkey list.
- **Quick Actions**: Start/Stop pause/resume overlay rendering, Reload
  reloads offsets, Settings switches to the Settings tab.
- Borderless custom title bar (— □ ✕); close or F8 quits everything, F9
  hides/shows the dashboard.
- Overlay HUD is rebranded `NTH//EXTERNAL` and can be hidden with F3
  (a faint watermark stays so you never lose the quit/panel hints).

## The .exe

`nthexternal.exe` is fully self-contained: it carries its own Python 3.11
runtime (with tkinter/tcl) inside.

- **First run**: it extracts once to `%LOCALAPPDATA%\nthexternal` (about
  1–2 s), then starts. Later runs start instantly from that cache.
- **GUI mode**: double-click — overlay + control panel appear.
- **CLI mode**: running it from a terminal with any argument (e.g.
  `nthexternal.exe --diag`, `--selftest`, `--offsets "C:\path\file.json"`,
  `--version`) uses the console runtime, streams output, and returns the
  exit code — same flags as the original script.
- **Uninstall**: delete the exe and `%LOCALAPPDATA%\nthexternal`.
- It is not signed, so SmartScreen may ask for confirmation on first run
  (More info → Run anyway).

## Offset files (unchanged discovery order)

1. explicit `--offsets <path>`
2. `offsets.json` / `offsets.txt` / `New Text Document.json` / `.txt` next to
   the exe (the packaged exe also carries a copy of your dump as a fallback)
3. your dump folder `Documents\mcro` (json first, txt overrides)

Saving a dump while the tool runs hot-reloads it (mtime watch, or F4 /
RELOAD OFFSETS), exactly like the original.

## Hotkeys (global — work while the game has focus)

| Key | Action |
|-----|--------|
| F1  | toggle hitbox boxes |
| F2  | toggle name / health / distance tags |
| F3  | toggle on-screen HUD (new) |
| F4  | reload offset files |
| F7  | cycle projection mode (0/1/2/3, default 3) |
| F9  | show/hide the control panel (new) |
| F8  | quit |

## Everything else

Same failure modes, same self-calibration, same read-only user-mode design:
`OpenProcess` + `ReadProcessMemory` only, nothing injected, nothing written
to the game, no kernel components. Use it for anti-cheat testing on games
you own and servers you are allowed to test on.

Logs go to `nthexternal.log` in the app folder (`%LOCALAPPDATA%\nthexternal\runtime\app`
when packaged, or next to the script when run from source).

## Running from source

```
python nthexternal.py            # overlay + panel (needs Python 3.9+, Windows)
python nthexternal.py --selftest # synthetic overlay test, no game needed
python nthexternal.py --diag     # attach diagnostics, no overlay
python nthexternal.py test_rbx_esp.py  (run tests: python test_rbx_esp.py)
```

`rbx_core.py`, `test_rbx_esp.py` and the `probe_*.py` files are your
originals, untouched.

## Source layout (this package)

- `nthexternal.py` — entry point: reader thread, hotkeys, diagnostics, selftest
- `overlay.py`     — transparent fullscreen overlay (port of the original)
- `panel.py`       — the control panel / toggle menu UI
- `state.py`       — shared app state (original AppState + HUD/panel flags)
- `rbx_core.py`    — your original memory core, unchanged
- `assets/nthexternal.ico` — generated icon
- `scripts/launcher/` — C launcher source + miniz (payload loader)
- `scripts/build_exe.py` — rebuilds `nthexternal.exe` (zig cc + zip payload)

## Verified

- 1981 payload files verified inside the exe (zip CRC + byte-compare)
- launcher logic tested end-to-end (fresh extract / cached run / CLI mode)
- PE checked: x64 GUI subsystem, icon + version resources present
- panel + overlay rendered and screenshot-checked; offline projection/offset
  math unchanged from your 39-check test suite
