#!/usr/bin/env python3
"""Bake the mascot gif into a square 156x156 panel asset.

Center-crops the source gif to a square, resizes to exactly the panel's
inset size (so tkinter's PhotoImage can show it 1:1 with no scaling),
and saves a 4-frame looping gif. Prints the baked corner color so the
panel inset fill can match it seamlessly.
"""
from PIL import Image, ImageSequence

SRC = "/home/z/my-project/upload/12FEA296-D9F6-4EEF-BE12-3A82750E4D45.gif"
OUT = "/home/z/my-project/work/nthexternal/assets/nth_mascot.gif"
SIZE = 156  # must match panel.py MASCOT_INSET


def main() -> None:
    im = Image.open(SRC)
    w, h = im.size
    side = min(w, h)
    left, top = (w - side) // 2, (h - side) // 2
    frames = []
    for f in ImageSequence.Iterator(im):
        # source bg is transparent -> composite over pure black so the
        # baked gif is opaque and matches the panel's dark inset
        rgba = f.convert("RGBA")
        black = Image.new("RGBA", rgba.size, (0, 0, 0, 255))
        fr = Image.alpha_composite(black, rgba).convert("RGB")
        fr = fr.crop((left, top, left + side, top + side))
        fr = fr.resize((SIZE, SIZE), Image.LANCZOS)
        fr.info.pop("transparency", None)
        frames.append(fr)

    corners = {frames[0].getpixel(p)
               for p in ((0, 0), (SIZE - 1, 0), (0, SIZE - 1), (SIZE - 1, SIZE - 1))}
    print("baked corner colors:", corners)

    pal = frames[0].quantize(colors=256, method=Image.MEDIANCUT)
    out = []
    for fr in frames:
        q = fr.quantize(palette=pal, dither=Image.NONE)
        q.info.pop("transparency", None)
        out.append(q)
    out[0].save(OUT, save_all=True, append_images=out[1:],
                duration=250, loop=0, optimize=False)

    chk = Image.open(OUT)
    print("saved:", OUT, "size", chk.size, "frames", chk.n_frames,
          "animated", chk.is_animated)
    for p in ((0, 0), (SIZE - 1, SIZE - 1)):
        chk.seek(0)
        print("corner", p, "->", chk.convert("RGB").getpixel(p))


if __name__ == "__main__":
    main()
