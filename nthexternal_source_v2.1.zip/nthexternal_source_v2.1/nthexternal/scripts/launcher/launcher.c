/* NTHEXTERNAL payload launcher (Windows x64).
 *
 * File layout produced by build_exe.py:
 *   [launcher PE code][zip payload][u64 zip_len LE][8-byte magic "NXPYL01"]
 *
 * The launcher locates the appended zip payload, extracts it to
 * %LOCALAPPDATA%\nthexternal (cached between runs via a version marker)
 * and then runs the bundled python runtime on the app entry script:
 *   GUI : runtime\python\pythonw.exe runtime\app\nthexternal.py
 *   CLI : runtime\python\python.exe runtime\app\nthexternal.py <args...>
 *
 * Build (see build_exe.py):
 *   zig cc -target x86_64-windows-gnu -O2 -municode launcher.c miniz.c ...
 */

#ifdef TEST_HARNESS
#include "win_shim.h"
#else
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <shellapi.h>
#endif
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "miniz.h"

#define PAYLOAD_MAGIC "NXPYL001"
#define APP_VERSION "2.0"
#define TRAILER_BYTES 16

static void show_error(const wchar_t *title, const wchar_t *msg)
{
    MessageBoxW(NULL, msg, title, MB_ICONERROR | MB_OK | MB_TOPMOST);
    ExitProcess(1);
}

static void fail_win(const wchar_t *what)
{
    wchar_t buf[1024];
    DWORD e = GetLastError();
    wchar_t *dos = NULL;
    FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
                       FORMAT_MESSAGE_IGNORE_INSERTS,
                   NULL, e, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                   (LPWSTR)&dos, 0, NULL);
    _snwprintf(buf, 1023, L"%ls failed (error %lu)%ls%ls", what,
               (unsigned long)e, dos ? L":\n" : L"", dos ? dos : L"");
    buf[1023] = 0;
    if (dos)
        LocalFree(dos);
    show_error(L"nthexternal", buf);
}

/* ---------------------------------------------------------------- paths -- */

static void join_path(wchar_t *dst, size_t cap, const wchar_t *a, const wchar_t *b)
{
    _snwprintf(dst, cap - 1, L"%ls\\%ls", a, b);
    dst[cap - 1] = 0;
}

static BOOL file_exists(const wchar_t *path)
{
    DWORD a = GetFileAttributesW(path);
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}

/* utf8 -> utf16 (zip entry names are UTF-8; ours are plain ASCII but stay safe) */
static void utf8_to_wide(const char *src, wchar_t *dst, int cap)
{
    int n = MultiByteToWideChar(CP_UTF8, 0, src, -1, dst, cap);
    if (n <= 0)
        dst[0] = 0;
}

static void create_parents(const wchar_t *path)
{
    wchar_t tmp[MAX_PATH * 2];
    wcsncpy(tmp, path, MAX_PATH * 2 - 1);
    tmp[MAX_PATH * 2 - 1] = 0;
    for (wchar_t *p = tmp + 1; *p; p++)
    {
        if (*p == L'\\' || *p == L'/')
        {
            wchar_t c = *p;
            *p = 0;
            CreateDirectoryW(tmp, NULL); /* ERROR_ALREADY_EXISTS is fine */
            *p = c;
        }
    }
}

static void delete_tree(const wchar_t *path)
{
    size_t n = wcslen(path);
    wchar_t *buf = (wchar_t *)HeapAlloc(GetProcessHeap(), 0, (n + 3) * sizeof(wchar_t));
    if (!buf)
        return;
    memcpy(buf, path, n * sizeof(wchar_t));
    buf[n] = 0;
    buf[n + 1] = 0; /* SHFileOperation wants double-null termination */
    SHFILEOPSTRUCTW op;
    memset(&op, 0, sizeof(op));
    op.hwnd = NULL;
    op.wFunc = FO_DELETE;
    op.pFrom = buf;
    op.fFlags = FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI;
    SHFileOperationW(&op);
    HeapFree(GetProcessHeap(), 0, buf);
}

/* ------------------------------------------------------------- payload -- */

static BOOL read_payload_range(const wchar_t *exe_path, uint64_t *zip_start,
                               uint64_t *zip_len)
{
    FILE *f = _wfopen(exe_path, L"rb");
    if (!f)
        return FALSE;
    if (_fseeki64(f, 0, SEEK_END) != 0)
    {
        fclose(f);
        return FALSE;
    }
    int64_t fsize = _ftelli64(f);
    if (fsize < TRAILER_BYTES + 64)
    {
        fclose(f);
        return FALSE;
    }
    if (_fseeki64(f, fsize - TRAILER_BYTES, SEEK_SET) != 0)
    {
        fclose(f);
        return FALSE;
    }
    unsigned char tail[TRAILER_BYTES];
    if (fread(tail, 1, TRAILER_BYTES, f) != TRAILER_BYTES)
    {
        fclose(f);
        return FALSE;
    }
    if (memcmp(tail + 8, PAYLOAD_MAGIC, 8) != 0)
    {
        fclose(f);
        return FALSE;
    }
    uint64_t len = 0;
    for (int i = 0; i < 8; i++)
        len |= ((uint64_t)tail[i]) << (8 * i);
    if (len == 0 || (uint64_t)fsize < len + TRAILER_BYTES)
    {
        fclose(f);
        return FALSE;
    }
    *zip_len = len;
    *zip_start = (uint64_t)fsize - TRAILER_BYTES - len;
    fclose(f);
    return TRUE;
}

typedef struct
{
    const wchar_t *runtime_root;
    FILE *out;
    wchar_t cur_file[MAX_PATH * 2];
} extract_ctx;

static mz_uint64 extract_cb(void *opaque, mz_uint64 file_ofs, const void *buf,
                            size_t n)
{
    extract_ctx *ctx = (extract_ctx *)opaque;
    if (file_ofs == 0)
    {
        if (ctx->out)
        {
            fclose(ctx->out);
            ctx->out = NULL;
        }
        ctx->out = _wfopen(ctx->cur_file, L"wb");
        if (!ctx->out)
            return (mz_uint64)-1;
    }
    if (n && ctx->out)
    {
        if (fwrite(buf, 1, n, ctx->out) != n)
            return (mz_uint64)-1;
    }
    return n;
}

/* Build <runtime_root>\<entry_name> (entry name is utf-8 with '/' separators),
 * creating intermediate directories. */
static void prepare_target(extract_ctx *ctx, const char *entry_name)
{
    wchar_t name[MAX_PATH * 2];
    utf8_to_wide(entry_name, name, MAX_PATH * 2);

    wchar_t *p = name;
    while (*p)
    {
        if (*p == L'/')
            *p = L'\\';
        p++;
    }
    _snwprintf(ctx->cur_file, MAX_PATH * 2 - 1, L"%ls\\%ls", ctx->runtime_root, name);
    ctx->cur_file[MAX_PATH * 2 - 1] = 0;
    create_parents(ctx->cur_file);
}

static void write_version_marker(const wchar_t *runtime_root)
{
    wchar_t mp[MAX_PATH * 2];
    join_path(mp, MAX_PATH * 2, runtime_root, L".ver");
    FILE *f = _wfopen(mp, L"wb");
    if (f)
    {
        fputs(APP_VERSION "\n", f);
        fclose(f);
    }
}

static BOOL marker_matches(const wchar_t *runtime_root)
{
    wchar_t mp[MAX_PATH * 2];
    join_path(mp, MAX_PATH * 2, runtime_root, L".ver");
    FILE *f = _wfopen(mp, L"rb");
    if (!f)
        return FALSE;
    char buf[32] = {0};
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    return n > 0 && strncmp(buf, APP_VERSION, strlen(APP_VERSION)) == 0;
}

static void extract_payload(const wchar_t *exe_path, const wchar_t *runtime_root,
                            uint64_t zip_start, uint64_t zip_len)
{
    FILE *f = _wfopen(exe_path, L"rb");
    if (!f)
        fail_win(L"opening the executable");
    if (_fseeki64(f, (int64_t)zip_start, SEEK_SET) != 0)
    {
        fclose(f);
        fail_win(L"seeking to payload");
    }
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));
    if (!mz_zip_reader_init_cfile(&zip, f, zip_len, 0))
    {
        fclose(f);
        show_error(L"nthexternal",
                   L"payload corrupted: could not read the bundled archive "
                   L"(the file may be truncated or modified).");
    }
    extract_ctx ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.runtime_root = runtime_root;

    unsigned n = mz_zip_reader_get_num_files(&zip);
    for (unsigned i = 0; i < n; i++)
    {
        mz_zip_archive_file_stat st;
        if (!mz_zip_reader_file_stat(&zip, i, &st))
        {
            mz_zip_reader_end(&zip);
            fclose(f);
            fail_win(L"reading payload entry");
        }
        if (st.m_is_directory)
            continue;
        prepare_target(&ctx, st.m_filename);
        if (!mz_zip_reader_extract_to_callback(&zip, i, extract_cb, &ctx, 0))
        {
            if (ctx.out)
            {
                fclose(ctx.out);
                ctx.out = NULL;
            }
            mz_zip_reader_end(&zip);
            fclose(f);
            show_error(L"nthexternal",
                       L"extraction failed (disk full or permissions?).");
        }
    }
    if (ctx.out)
    {
        fclose(ctx.out);
        ctx.out = NULL;
    }
    mz_zip_reader_end(&zip);
    fclose(f);
    write_version_marker(runtime_root);
}

/* ---------------------------------------------------------------- main -- */

static void run_app(const wchar_t *runtime_root, const wchar_t *args,
                    int console_mode, int *exit_code)
{
    wchar_t py[MAX_PATH * 2];
    wchar_t script[MAX_PATH * 2];
    wchar_t appdir[MAX_PATH * 2];
    wchar_t cmd[32768];

    join_path(py, MAX_PATH * 2, runtime_root,
              console_mode ? L"python\\python.exe" : L"python\\pythonw.exe");
    join_path(script, MAX_PATH * 2, runtime_root, L"app\\nthexternal.py");
    join_path(appdir, MAX_PATH * 2, runtime_root, L"app");

    if (!file_exists(py) || !file_exists(script))
        show_error(L"nthexternal",
                   L"runtime incomplete: python.exe or the app entry is "
                   L"missing. Delete %LOCALAPPDATA%\\nthexternal and start "
                   L"this executable again.");

    if (console_mode)
        _snwprintf(cmd, 32767, L"\"%ls\" \"%ls\" %ls", py, script, args ? args : L"");
    else
        _snwprintf(cmd, 32767, L"\"%ls\" \"%ls\"", py, script);
    cmd[32767] = 0;

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    memset(&pi, 0, sizeof(pi));

    DWORD flags = console_mode ? 0 : (CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP);
    if (!CreateProcessW(NULL, cmd, NULL, NULL, console_mode ? TRUE : FALSE, flags,
                        NULL, appdir, &si, &pi))
    {
        wchar_t msg[1024];
        _snwprintf(msg, 1023,
                   L"could not launch the bundled runtime (error %lu).\n\n"
                   L"Try deleting %%LOCALAPPDATA%%\\nthexternal and start again.",
                   (unsigned long)GetLastError());
        msg[1023] = 0;
        show_error(L"nthexternal", msg);
    }
    CloseHandle(pi.hThread);
    if (console_mode)
    {
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hProcess);
        *exit_code = (int)code;
    }
    else
    {
        CloseHandle(pi.hProcess);
        *exit_code = 0;
    }
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmdline, int show)
{
    (void)hInst;
    (void)hPrev;
    (void)show;

    wchar_t exe[MAX_PATH * 2];
    GetModuleFileNameW(NULL, exe, MAX_PATH * 2);

    uint64_t zip_start = 0, zip_len = 0;
    if (!read_payload_range(exe, &zip_start, &zip_len))
        show_error(L"nthexternal",
                   L"this executable is missing its bundled payload "
                   L"(build error or the file was truncated).");

    /* %LOCALAPPDATA% */
    PWSTR local = NULL;
    if (FAILED(SHGetKnownFolderPath(&FOLDERID_LocalAppData, 0, NULL, &local)))
        fail_win(L"resolving %LOCALAPPDATA%");
    wchar_t root[MAX_PATH * 2];
    _snwprintf(root, MAX_PATH * 2 - 1, L"%ls\\nthexternal", local);
    root[MAX_PATH * 2 - 1] = 0;
    CoTaskMemFree(local);

    SHCreateDirectoryExW(NULL, root, NULL);

    wchar_t runtime_root[MAX_PATH * 2];
    join_path(runtime_root, MAX_PATH * 2, root, L"runtime");

    if (!marker_matches(runtime_root))
    {
        delete_tree(runtime_root);
        extract_payload(exe, runtime_root, zip_start, zip_len);
    }

    /* CLI args (after the exe name) -> console runtime + exit-code passthrough */
    const wchar_t *args = cmdline;
    while (args && *args == L' ')
        args++;
    int console_mode = (args && *args != 0);
    int exit_code = 0;
    run_app(runtime_root, args, console_mode, &exit_code);
    return exit_code;
}


#ifdef TEST_HARNESS
/* Harness: run the same wWinMain flow against the real built exe bytes. */
int main(int argc, char **argv)
{
    setlocale(LC_ALL, "");
    /* build cmdline from argv[1..] */
    static wchar_t cmd[4096];
    cmd[0] = 0;
    for (int i = 1; i < argc; i++)
    {
        wchar_t tmp[512];
        mbstowcs(tmp, argv[i], 511);
        tmp[511] = 0;
        wcsncat(cmd, tmp, 4000);
        wcsncat(cmd, L" ", 4);
    }
    int code = wWinMain(NULL, NULL, cmd, 0);
    printf("harness exit code: %d\n", code);
    return code;
}
#endif
