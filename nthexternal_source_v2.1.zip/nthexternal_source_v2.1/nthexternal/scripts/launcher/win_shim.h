/* Minimal Win32 shim so launcher.c can be logic-tested on a POSIX host.
 * TEST BUILD ONLY - never compiled into the shipped exe. */
#ifndef WIN_SHIM_H
#define WIN_SHIM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <wchar.h>
#include <locale.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef int BOOL;
typedef unsigned long DWORD;
typedef int HRESULT;
typedef wchar_t WCHAR;
typedef wchar_t *PWSTR;
typedef const wchar_t *PCWSTR;
typedef void *HANDLE;
typedef void *LPVOID;
typedef void *PVOID;
typedef void *HINSTANCE;
typedef char CHAR;
typedef const wchar_t *LPCWSTR;
typedef wchar_t *LPWSTR;
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int UINT;
typedef size_t SIZE_T;
typedef void *LPDIRECT;

#ifndef MAX_PATH
#define MAX_PATH 260
#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define S_OK ((HRESULT)0)
#define FAILED(hr) ((hr) < 0)
#define INVALID_FILE_ATTRIBUTES 0xFFFFFFFFu
#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define FO_DELETE 3
#define FOF_NOCONFIRMATION 0x10
#define FOF_SILENT 0x4
#define FOF_NOERRORUI 0x400
#define CP_UTF8 65001
#define ERROR_ALREADY_EXISTS 183
#define INFINITE 0xFFFFFFFF
#define STILL_ACTIVE 259
#define CREATE_NO_WINDOW 0x08000000
#define CREATE_NEW_PROCESS_GROUP 0x200
#define WINAPI
#define MB_ICONERROR 0x10
#define FORMAT_MESSAGE_ALLOCATE_BUFFER 0x100
#define FORMAT_MESSAGE_FROM_SYSTEM 0x1000
#define FORMAT_MESSAGE_IGNORE_INSERTS 0x200
#define LANG_NEUTRAL 0
#define SUBLANG_DEFAULT 1
#define MAKELANGID(a,b) ((a) | ((b) << 10))
#define MB_OK 0x0
#define MB_TOPMOST 0x40000

typedef struct _GUID { unsigned long a; unsigned short b, c; unsigned char d[8]; } GUID;
typedef GUID KNOWNFOLDERID;
static const KNOWNFOLDERID FOLDERID_LocalAppData =
    {0x520e4b74, 0x21a2, 0x47f2, {0x9b, 0x25, 0xfb, 0x3e, 0x7f, 0xed, 0x34, 0x9e}};

typedef struct _SHFILEOPSTRUCTW {
    void *hwnd;
    unsigned wFunc;
    const wchar_t *pFrom;
    const wchar_t *pTo;
    unsigned short fFlags;
} SHFILEOPSTRUCTW;

typedef struct _STARTUPINFOW {
    unsigned long cb;
} STARTUPINFOW;

typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
} PROCESS_INFORMATION;

#define _snwprintf swprintf
#define _ftelli64 ftello
#define _fseeki64 fseeko

static char shim_nxroot[512];

/* POSIX has no backslash path semantics: normalize for the harness so the
 * extracted tree can be verified with real filesystem checks. */
static void shim_fix(char *p)
{
    for (char *q = p; *q; q++)
        if (*q == '\\')
            *q = '/';
}

static const char *shim_root(void)
{
    const char *r = getenv("NX_TEST_ROOT");
    if (!r)
        r = "/tmp/nx_test";
    snprintf(shim_nxroot, sizeof(shim_nxroot), "%s/LocalAppData", r);
    return shim_nxroot;
}

static DWORD GetLastError_(void) { return 0; }
#define GetLastError GetLastError_

static DWORD FormatMessageW(DWORD a, void *b, DWORD err, DWORD c, void *out_, DWORD d, void *e)
{
    (void)a; (void)b; (void)c; (void)d; (void)e;
    wchar_t *buf = (wchar_t *)malloc(128 * sizeof(wchar_t));
    swprintf(buf, 127, L"win error %lu", (unsigned long)err);
    wchar_t **out = (wchar_t **)out_;
    *out = buf;
    return 0;
}
static void LocalFree(void *p) { free(p); }

/* wide fopen: convert to narrow and fopen */
static FILE *wfopen_shim(const wchar_t *path, const wchar_t *mode)
{
    char p[1024], m[16];
    wcstombs(p, path, sizeof(p) - 1);
    p[sizeof(p) - 1] = 0;
    shim_fix(p);
    wcstombs(m, mode, sizeof(m) - 1);
    m[sizeof(m) - 1] = 0;
    return fopen(p, m);
}
#define _wfopen wfopen_shim

static DWORD GetModuleFileNameW(void *h, wchar_t *out, DWORD cap)
{
    (void)h;
    const char *p = getenv("NX_TEST_EXE");
    if (!p)
        p = "/tmp/nx_build/launcher.exe";
    size_t n = strlen(p);
    mbstowcs(out, p, cap - 1);
    out[n] = 0;
    return (DWORD)n;
}

static DWORD GetFileAttributesW(const wchar_t *path)
{
    char p[1024];
    wcstombs(p, path, sizeof(p) - 1);
    p[sizeof(p) - 1] = 0;
    shim_fix(p);
    FILE *f = fopen(p, "rb");
    if (!f)
    {
        return access(p, F_OK) == 0 ? FILE_ATTRIBUTE_DIRECTORY : INVALID_FILE_ATTRIBUTES;
    }
    fclose(f);
    return 0;
}

static int MultiByteToWideChar(UINT cp, DWORD fl, const char *src, int slen,
                               wchar_t *dst, int cap)
{
    (void)cp; (void)fl;
    size_t n = (slen < 0 ? strlen(src) : (size_t)slen);
    if ((int)n + 1 > cap)
        return 0;
    mbstowcs(dst, src, (size_t)cap);
    dst[n] = 0;
    return (int)n;
}

static BOOL CreateDirectoryW(const wchar_t *path, void *sd)
{
    (void)sd;
    char p[1024];
    wcstombs(p, path, sizeof(p) - 1);
    p[sizeof(p) - 1] = 0;
    shim_fix(p);
    if (mkdir(p, 0755) == 0)
        return TRUE;
    return FALSE;
}

static UINT SHFileOperationW(SHFILEOPSTRUCTW *op)
{
    /* recursive delete of op->pFrom (wide path -> narrow) */
    char p[1024];
    wcstombs(p, op->pFrom, sizeof(p) - 1);
    p[sizeof(p) - 1] = 0;
    char cmd[1200];
    snprintf(cmd, sizeof(cmd), "rm -rf '%s'", p);
    if (system(cmd) != 0)
        return 1;
    return 0;
}

static int SHCreateDirectoryExW(void *h, const wchar_t *path, void *sd)
{
    (void)h; (void)sd;
    char p[1024];
    wcstombs(p, path, sizeof(p) - 1);
    p[sizeof(p) - 1] = 0;
    shim_fix(p);
    char cmd[1200];
    snprintf(cmd, sizeof(cmd), "mkdir -p '%s'", p);
    if (system(cmd) != 0)
        return 1;
    return 0;
}

static HRESULT SHGetKnownFolderPath(const GUID *id, DWORD fl, void *tok, PWSTR *out)
{
    (void)id; (void)fl; (void)tok;
    const char *r = shim_root();
    size_t n = strlen(r);
    wchar_t *buf = (wchar_t *)malloc((n + 2) * sizeof(wchar_t));
    mbstowcs(buf, r, n + 1);
    buf[n] = 0;
    *out = buf;
    return S_OK;
}
static void CoTaskMemFree(void *p) { free(p); }

/* file-wide globals written by the shim CreateProcessW for assertions */
static char shim_created_cmdline[4096];

static BOOL CreateProcessW(void *app, wchar_t *cmd, void *pa, void *ta,
                           BOOL inh, DWORD flags, void *env, const wchar_t *cwd,
                           STARTUPINFOW *si, PROCESS_INFORMATION *pi)
{
    (void)app; (void)pa; (void)ta; (void)inh; (void)env; (void)si;
    char c[4096];
    wcstombs(c, cmd, sizeof(c) - 1);
    c[sizeof(c) - 1] = 0;
    snprintf(shim_created_cmdline, sizeof(shim_created_cmdline), "%s", c);
    char cw[1024] = "";
    if (cwd)
        wcstombs(cw, cwd, sizeof(cw) - 1);
    FILE *f = fopen("/tmp/nx_test/created_process.txt", "a");
    if (f)
    {
        fprintf(f, "cmd=%s\ncwd=%s\nflags=0x%lx\n---\n", c, cw,
                (unsigned long)flags);
        fclose(f);
    }
    pi->hProcess = (HANDLE)(intptr_t)1;
    pi->hThread = (HANDLE)(intptr_t)1;
    pi->dwProcessId = 4242;
    return TRUE;
}

static DWORD WaitForSingleObject(HANDLE h, DWORD ms) { (void)h; (void)ms; return 0; }
static BOOL GetExitCodeProcess(HANDLE h, DWORD *code) { (void)h; *code = 0; return TRUE; }
static BOOL CloseHandle(HANDLE h) { (void)h; return TRUE; }

static void ExitProcess(unsigned code) { exit((int)code); }
static void MessageBoxW_(void *h, const wchar_t *msg, const wchar_t *title, DWORD fl)
{
    (void)h; (void)fl;
    char m[2048], t[256];
    wcstombs(m, msg, sizeof(m) - 1);
    m[sizeof(m) - 1] = 0;
    wcstombs(t, title, sizeof(t) - 1);
    fprintf(stderr, "[MessageBox] %s: %s\n", t, m);
    exit(7); /* treat any message box as fatal for the harness */
}
#define MessageBoxW MessageBoxW_

static void *GetProcessHeap_(void) { return NULL; }
#define GetProcessHeap GetProcessHeap_
static void *HeapAlloc_(void *h, DWORD fl, size_t n) { (void)h; (void)fl; return malloc(n); }
#define HeapAlloc HeapAlloc_
static BOOL HeapFree_(void *h, DWORD fl, void *p) { (void)h; (void)fl; free(p); return TRUE; }
#define HeapFree HeapFree_

#endif /* WIN_SHIM_H */
