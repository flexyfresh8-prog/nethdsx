"""Generate the NTHEXTERNAL app icon (neon N on dark rounded square) as .ico."""
from PIL import Image, ImageDraw, ImageFont, ImageFilter

S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# rounded dark tile
tile_r = 52
d.rounded_rectangle([6, 6, S - 6, S - 6], radius=tile_r, fill=(13, 13, 23, 255),
                    outline=(60, 60, 92, 255), width=2)

# gradient stroke for the N: draw the letter large, then colorize per row
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 190)
mask = Image.new("L", (S, S), 0)
md = ImageDraw.Draw(mask)
bbox = md.textbbox((0, 0), "N", font=font)
tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
md.text(((S - tw) / 2 - bbox[0], (S - th) / 2 - bbox[1] + 4), "N", font=font, fill=255)

# neon gradient (magenta -> purple -> cyan)
grad = Image.new("RGBA", (S, S), (0, 0, 0, 0))
stops = [(255, 45, 85), (180, 77, 255), (0, 224, 255)]
for y in range(S):
    t = y / (S - 1)
    seg = t * (len(stops) - 1)
    i = min(int(seg), len(stops) - 2)
    f = seg - i
    c = tuple(int(stops[i][k] + (stops[i + 1][k] - stops[i][k]) * f) for k in range(3))
    for x in range(S):
        grad.putpixel((x, y), c + (255,))
grad.putalpha(mask)

# glow: blur the masked gradient and paste under the crisp letter
glow = grad.filter(ImageFilter.GaussianBlur(10))
img.alpha_composite(glow, (0, 0))
img.alpha_composite(Image.new("RGBA", (S, S), (0, 0, 0, 0)), (0, 0))
# crisp letter on top (double-draw for stronger core)
glow2 = grad.filter(ImageFilter.GaussianBlur(2))
img.alpha_composite(glow2)
img.alpha_composite(grad)

img.save("/home/z/my-project/nthexternal/assets/nthexternal.ico",
         sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (16, 16)])
img.save("/tmp/render/icon_preview.png")
print("icon written")
