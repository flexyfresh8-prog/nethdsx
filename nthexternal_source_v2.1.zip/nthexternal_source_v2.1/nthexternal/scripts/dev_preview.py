"""Dev-only preview: render the nthexternal control panel with fake data and
screenshot every page under Xvfb. Not part of the shipped app."""
import os
import queue
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))
os.environ["NTH_DEMO"] = "1"  # design showcase values

import tkinter as tk
from PIL import ImageGrab

from state import AppState
from panel import ControlPanel

OUT_DIR = "/tmp/render/shots"


class FakeReader:
    def __init__(self):
        self.status = "reading (3 players)"
        self.error = ""
        self.players_seen = 3
        self.last_pid = 10908
        self.last_place = 8370421953
        self.off_files = [r"C:\Users\nethula\Documents\mcro\New Text Document.json"]
        self.ui_q = queue.Queue()
        self.ui_q.put("[11:22:33] offsets: New Text Document.json -> 394 entries")
        self.ui_q.put("[11:22:33] [+] attached pid=10908 RobloxPlayerBeta.exe base=0x7ff624570000")
        self.ui_q.put("[11:22:33] [dm] DataModel verified via visual engine @ 0x2ac3f012ac0")
        self.ui_q.put("[11:22:34] frame ok: 3 players, matrix read")


class FakeOverlay:
    fps = 58.0


class FakeActions:
    version = "2.1"

    def __init__(self, panel_ref):
        self.panel_ref = panel_ref

    def on_preview(self):
        self.panel_ref[0].console("preview: injected synthetic players (no game needed)", "ok")

    def on_diag(self):
        p = self.panel_ref[0]
        p.console("running diagnostics...", "warn")
        p.console("[+] C:\\Users\\nethula\\Documents\\mcro\\New Text Document.json: 394 entries", "info")
        p.console("[+] all required offsets present", "ok")
        p.console("[-] no Roblox client process found", "err")

    def on_open_log(self):
        self.panel_ref[0].console("log: C:\\...\\nthexternal.log", "info")


def shot(root, panel, path):
    root.update()
    x = panel.winfo_rootx()
    y = panel.winfo_rooty()
    w = panel.winfo_width()
    h = panel.winfo_height()
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h), xdisplay=os.environ.get("DISPLAY", ":99"))
    img.save(path)
    print("saved", path, img.size)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    root = tk.Tk()
    root.withdraw()
    app = AppState()
    ref = [None]
    actions = FakeActions(ref)
    panel = ControlPanel(root, app, FakeReader(), FakeOverlay(), actions)
    ref[0] = panel
    panel.geometry("+10+10")

    names = ["1_overview", "2_reader", "3_visuals", "4_settings", "5_about"]

    def cycle(k=0):
        if k == 0:
            shot(root, panel, f"{OUT_DIR}/page_{names[0]}.png")
        else:
            panel.show_tab(k)
            panel.after(650, lambda: shot(root, panel, f"{OUT_DIR}/page_{names[k]}.png"))
            panel.after(651, lambda: cycle(k + 1) if k + 1 < len(names) else alt_state())
            return
        if k + 1 < len(names):
            panel.after(700, lambda: cycle(k + 1))
        else:
            panel.after(700, alt_state)

    def alt_state():
        # scenario: toggles off + error state on overview
        app.set_boxes(False)
        app.set_hud(False)
        panel.reader.status = "error: attach failed"
        panel.reader.error = "OpenProcess(pid=10908) failed err=5 - access denied: the client is protected"
        panel.reader.players_seen = 0
        panel.reader.last_pid = 0
        panel.reader.last_place = 0
        panel.show_tab(0)
        panel.after(800, lambda: shot(root, panel, f"{OUT_DIR}/page_6_overview_error.png"))
        panel.after(810, root.destroy)

    panel.after(1600, cycle)
    root.mainloop()


if __name__ == "__main__":
    main()
