#!/usr/bin/env python3
"""Build nthexternal.exe: zig-cc compiled Win32 launcher + appended zip payload.

Layout: [launcher PE][zip payload][u64 zip_len LE][magic "NXPYL001"]

Payload zip layout (entries at root; launcher prepends %LOCALAPPDATA%\\nthexternal\\runtime):
    python/...      slimmed python-build-standalone 3.11 windows runtime (tkinter included)
    app/...         the nthexternal application modules + offsets file
    .ver            version marker

Also emits download/nthexternal_portable.zip (exe + README) for easy distribution.
"""
import os
import shutil
import struct
import subprocess
import sys
import zipfile

ROOT = "/home/z/my-project/work"
APP = os.path.join(ROOT, "nthexternal")
LAUNCH = os.path.join(ROOT, "nthexternal", "scripts", "launcher")
BUILD = "/tmp/nx_build"
PBS_SRC = "/tmp/pbs_win/python"
ZIG = ["python3", "-m", "ziglang"]
VERSION = "2.1"

APP_FILES = ["nthexternal.py", "state.py", "overlay.py", "panel.py",
             "rbx_core.py", "New Text Document.json", "assets/nth_mascot.gif"]


def stage_runtime():
    rt = os.path.join(BUILD, "runtime")
    py = os.path.join(rt, "python")
    if os.path.isdir(py):
        print("runtime already staged")
        return rt
    os.makedirs(rt, exist_ok=True)
    shutil.copytree(PBS_SRC, py, symlinks=False)
    return rt


def write_app(rt):
    app = os.path.join(rt, "app")
    os.makedirs(app, exist_ok=True)
    for f in APP_FILES:
        src = os.path.join(APP, f)
        dst = os.path.join(app, os.path.basename(f))
        shutil.copy2(src, dst)
    with open(os.path.join(rt, ".ver"), "w") as fh:
        fh.write(VERSION + "\n")


def compile_launcher():
    res = os.path.join(LAUNCH, "launcher.res")
    rc = os.path.join(LAUNCH, "launcher.rc")
    if os.path.exists(res):
        os.remove(res)
    # try zig rc; if unavailable, build without the icon resource
    have_res = False
    try:
        subprocess.run(ZIG + ["rc", rc, res], check=True, cwd=LAUNCH,
                       capture_output=True, text=True)
        have_res = os.path.exists(res)
        print("zig rc ->", "ok" if have_res else "missing")
    except subprocess.CalledProcessError as e:
        print("zig rc failed:", (e.stderr or e.stdout or "")[-400:])
    except FileNotFoundError:
        print("zig rc not available")

    out = os.path.join(BUILD, "launcher.exe")
    cmd = ZIG + ["cc", "-target", "x86_64-windows-gnu", "-O2", "-municode",
                 "-Wl,--subsystem,windows",
                 os.path.join(LAUNCH, "launcher.c"), os.path.join(LAUNCH, "miniz.c"),
                 "-o", out, "-lshell32", "-lole32", "-luuid"]
    if have_res:
        cmd.append(res)
    r = subprocess.run(cmd, cwd=LAUNCH, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-3000:])
        print(r.stderr[-3000:])
        raise SystemExit("zig cc failed")
    print("launcher compiled:", os.path.getsize(out), "bytes")
    return out


def build_payload(rt):
    payload = os.path.join(BUILD, "payload.zip")
    if os.path.exists(payload):
        os.remove(payload)
    count = 0
    with zipfile.ZipFile(payload, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for base, _dirs, files in os.walk(rt):
            for fn in files:
                full = os.path.join(base, fn)
                rel = os.path.relpath(full, rt).replace(os.sep, "/")
                z.write(full, rel)
                count += 1
    size = os.path.getsize(payload)
    print(f"payload: {count} files, {size/1e6:.1f} MB")
    return payload


def assemble(launcher, payload):
    final = "/home/z/my-project/download/nthexternal.exe"
    os.makedirs(os.path.dirname(final), exist_ok=True)
    with open(launcher, "rb") as lf:
        blob = lf.read()
    with open(payload, "rb") as pf:
        zdata = pf.read()
    trailer = struct.pack("<Q", len(zdata)) + b"NXPYL001"
    with open(final, "wb") as out:
        out.write(blob)
        out.write(zdata)
        out.write(trailer)
    print("nthexternal.exe:", os.path.getsize(final) / 1e6, "MB ->", final)
    return final


def main():
    os.makedirs(BUILD, exist_ok=True)
    rt = stage_runtime()
    write_app(rt)
    launcher = compile_launcher()
    payload = build_payload(rt)
    final = assemble(launcher, payload)

    # quick structural verification with python's zipfile on the appended range
    with open(final, "rb") as f:
        f.seek(-16, 2)
        tail = f.read(16)
        (zlen,) = struct.unpack("<Q", tail[:8])
        assert tail[8:] == b"NXPYL001", "trailer magic mismatch"
        f.seek(-(16 + zlen), 2)
        zbytes = f.read(zlen)
    import io
    zf = zipfile.ZipFile(io.BytesIO(zbytes))
    bad = zf.testzip()
    assert bad is None, f"payload zip corrupt: {bad}"
    names = zf.namelist()
    for must in ("app/nthexternal.py", "app/rbx_core.py", "app/panel.py",
                 "app/nth_mascot.gif", "app/New Text Document.json",
                 "python/python.exe", "python/pythonw.exe", "python/python311.dll",
                 "python/DLLs/tcl86t.dll", "python/DLLs/tk86t.dll",
                 "python/tcl/tcl8.6/init.tcl", ".ver"):
        assert must in names, f"missing payload entry: {must}"
    print("payload verified inside exe:", len(names), "entries, zip OK")
    return final


if __name__ == "__main__":
    main()
