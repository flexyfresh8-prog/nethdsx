"""Probe 4: find the class-name read protocol inside the class descriptor."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import Memory, Offsets, list_processes_by_name, main_module_base  # noqa: E402

off = Offsets()
off.merge_file(os.path.expanduser("~") + r"\Documents\mcro\New Text Document.json")

pid = list_processes_by_name(["robloxplayerbeta"])[0][0]
mem = Memory(pid)
mem.open()
base = main_module_base(pid)

fake = mem.r64(base + off.require("FakeDataModel", "Pointer"))
cand = mem.r64(fake + off.require("FakeDataModel", "RealDataModel"))
ws = mem.r64(cand + off.require("DataModel", "Workspace"))
wcd = mem.r64(ws + 0x18)
ccd = mem.r64(cand + 0x18)
print(f"cand=0x{cand:x} cand_cd=0x{ccd:x}   ws=0x{ws:x} ws_cd=0x{wcd:x}")


def cstr(addr: int, maxn: int = 48) -> str:
    d = mem.read(addr, maxn)
    if not d:
        return ""
    out = []
    for b in d:
        if b == 0:
            break
        out.append(chr(b) if 32 <= b < 127 else "?")
    return "".join(out)


def plausible_str(s: str) -> bool:
    return 3 <= len(s) <= 40 and all(32 <= ord(c) < 127 for c in s)


def scan(cd: int, label: str, expect: str) -> None:
    print(f"\n== scanning {label} cd=0x{cd:x} (expecting {expect!r})")
    hits = []
    for o in range(0, 0x80, 8):
        q = mem.r64(cd + o)
        # inline attempt
        s = mem.r_string(cd + o)
        if plausible_str(s):
            hits.append((f"r_string(cd+0x{o:02x})", s))
        if q and 0x10000 < q < 0x7fffffffffff:
            s2 = cstr(q)
            if plausible_str(s2):
                hits.append((f"cstr(*cd+0x{o:02x})", s2))
            s3 = mem.r_string(q)
            if plausible_str(s3):
                hits.append((f"r_string(*cd+0x{o:02x})", s3))
            # nested: q -> ptr -> cstr
            q2 = mem.r64(q)
            if q2 and 0x10000 < q2 < 0x7fffffffffff:
                s4 = cstr(q2)
                if plausible_str(s4):
                    hits.append((f"cstr(**cd+0x{o:02x})", s4))
                s5 = mem.r_string(q2)
                if plausible_str(s5):
                    hits.append((f"r_string(**cd+0x{o:02x})", s5))
    for how, s in hits:
        mark = "  <<<< MATCH" if s == expect else ""
        print(f"   {how} = {s!r}{mark}")


scan(wcd, "workspace", "Workspace")
scan(ccd, "datamodel", "DataModel")

# dump workspace cd fully for manual inspection
print("\n-- ws cd raw 0x80:")
d = mem.read(wcd, 0x80)
for row in range(0, len(d), 16):
    chunk = d[row:row + 16]
    hx = " ".join(f"{b:02x}" for b in chunk)
    asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
    print(f"   {wcd + row:012x}  {hx:<47}  |{asc}|")

# Players service: find it through the fixed children logic, then inspect a Player
V = mem.r64(cand + 0x70)
begin = mem.r64(V)
end = mem.r64(V + 8)
n = (end - begin) // 8 if end > begin else 0
print(f"\nchildren vector: begin=0x{begin:x} end=0x{end:x} n={n}")
players_inst = 0
if 0 < n <= 4096:
    buf = mem.read(begin, n * 8)
    for i in range(n):
        c = struct.unpack_from("<Q", buf, i * 8)[0]
        if not c:
            continue
        if mem.r_string(mem.r64(c + 0x68) + 0x0 if mem.r64(c + 0x68) else 0) == "Players":
            players_inst = c
            break
print(f"Players service = 0x{players_inst:x}")
if players_inst:
    lp = mem.r64(players_inst + off.require("Player", "LocalPlayer"))
    print(f"LocalPlayer = 0x{lp:x}")
    if lp:
        print(f"  local name = {mem.r_string(mem.r64(lp + 0x68) + 0) if mem.r64(lp + 0x68) else ''!r}")
        print(f"  uid = {mem.r_i32(lp + off.require('Player', 'UserId'))}")
        char = mem.r64(lp + off.require("Player", "ModelInstance"))
        print(f"  character = 0x{char:x}")
        if char:
            cV = mem.r64(char + 0x70)
            cb = mem.r64(cV)
            ce_ = mem.r64(cV + 8)
            cn_ = (ce_ - cb) // 8 if ce_ > cb else 0
            print(f"  character children n={cn_}")
            if 0 < cn_ <= 256:
                cbuf = mem.read(cb, cn_ * 8)
                for i in range(min(cn_, 30)):
                    c = struct.unpack_from("<Q", cbuf, i * 8)[0]
                    if not c:
                        continue
                    ncn = mem.r64(c + 0x68)
                    nm = mem.r_string(ncn) if ncn else ""
                    pcd = mem.r64(c + 0x18)
                    pcls = "?"
                    if pcd:
                        # try the offsets we are about to confirm
                        for probe_off in (0x8,):
                            qq = mem.r64(pcd + probe_off)
                            if qq:
                                s = mem.r_string(qq)
                                if plausible_str(s):
                                    pcls = s
                                else:
                                    s2 = cstr(qq)
                                    if plausible_str(s2):
                                        pcls = s2
                    prim = mem.r64(c + off.require("BasePart", "Primitive"))
                    pos = mem.r_vec3(prim + off.require("Primitive", "Position")) if prim else None
                    print(f"    [{i}] 0x{c:x} name={nm!r} cd*+8={pcls!r} prim=0x{prim:x} pos={pos}")

mem.close()
