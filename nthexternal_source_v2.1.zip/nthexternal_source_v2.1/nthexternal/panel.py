"""NTH External Reader control panel - dashboard UI (800x500, side tabs).

Pure-tkinter custom widget set (no third-party deps, so the payload packaging
stays trivial).  The panel is a borderless 800x500 window with a sidebar tab
strip (Overview / Reader / Visuals / Settings / About).  The Overview tab is a
faithful replica of the NTH dashboard design: stat cards with sparklines, a
Reader Status list, a Performance chart with 1m/5m/1h ranges, Quick Actions
and the brand card.

Live data mapping (no fake numbers in normal runs):
    READ RATE   estimated bytes/sec read by the reader thread
    OBJECTS     primitives tracked in the last frame
    MEMORY      this process working set
    Reader Status / sidebar status derived from reader + overlay state
    Performance overlay render fps history (1m / 5m / 1h windows)

Set NTH_DEMO=1 to seed the design's showcase values (used by
scripts/dev_preview.py for the screenshot only).

The panel never imports rbx_core, so it can be previewed without Windows.
"""

from __future__ import annotations

import math
import os
import queue
import random
import time
import tkinter as tk
from collections import deque
from tkinter import font as tkfont

# ---------------------------------------------------------------------------
# design system
# ---------------------------------------------------------------------------

W, H = 800, 500
SIDEBAR_W = 116
TITLEBAR_H = 34
PAGE_W = W - SIDEBAR_W          # 684
PAGE_H = H - TITLEBAR_H         # 466

BG = "#050507"        # window background
CARD = "#0d0f12"      # card fill
FIELD = "#0a0c0f"     # inset fields / console
BORDER = "#1f2329"
BORDER_HI = "#2e333a"
FG = "#f2f4f6"
DIM = "#9aa1a9"
FAINT = "#5a6068"
GREEN = "#3ddc84"
PILL_BG = "#0f2418"
PILL_BR = "#1d4a2e"
AMBER = "#f0b429"
ERR = "#ff6b6b"
WHITE_L = "#eef1f4"
ICON = "#b9bfc7"
ACCENT = "#a06bff"        # mascot purple (gif theme accents)
ACCENT_DIM = "#4a3a6e"
MASCOT_INSET = 156        # baked gif size (see scripts/make_mascot_gif.py)
GIF_MS = 250              # gif frame delay (ms)

FAMILY = "Segoe UI"
MONO = "Consolas"

NAV_ITEMS = [
    ("Overview", "home"),
    ("Reader", "target"),
    ("Visuals", "eye"),
    ("Settings", "gear"),
    ("About", "info"),
]

STATUS_ROWS = [
    ("zap", "Core Engine"),
    ("layers", "Memory Pipeline"),
    ("Visuals", "eye"),  # placeholder, replaced below
]
STATUS_ROWS = [
    ("zap", "Core Engine"),
    ("layers", "Memory Pipeline"),
    ("eye", "Visual Module"),
    ("pulse", "Diagnostics"),
]


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------

def _hex2rgb(c: str) -> tuple[int, int, int]:
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def _rgb2hex(r: int, g: int, b: int) -> str:
    return f"#{max(0, min(255, int(r))):02x}{max(0, min(255, int(g))):02x}{max(0, min(255, int(b))):02x}"


def _lerp(c1: str, c2: str, t: float) -> str:
    a, b = _hex2rgb(c1), _hex2rgb(c2)
    return _rgb2hex(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t,
                    a[2] + (b[2] - a[2]) * t)


def _grad(stops: list[str], t: float) -> str:
    t = max(0.0, min(1.0, t))
    seg = t * (len(stops) - 1)
    i = min(int(seg), len(stops) - 2)
    return _lerp(stops[i], stops[i + 1], seg - i)


def _round_pts(x1, y1, x2, y2, r):
    """Polygon points for a rounded rectangle (used with smooth=True)."""
    return (x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
            x2 - r, y2, x1 + r, y2, x1, y2, x1, y1 + r, x1, y1)


def _card(c: tk.Canvas, x1, y1, x2, y2, r=16, fill=CARD, outline=BORDER,
          tags="") -> None:
    c.create_polygon(_round_pts(x1, y1, x2, y2, r), fill=fill, outline=outline,
                     smooth=True, tags=tags)
    c.create_line(x1 + r + 2, y1 + 1.2, x2 - r - 2, y1 + 1.2, fill="#23272d",
                  smooth=True, tags=tags)


def _glow_line(c: tk.Canvas, pts, tags="", core=WHITE_L, w=2) -> None:
    flat = [v for p in pts for v in p]
    for wdt, col in ((w + 5, "#151920"), (w + 2, "#3d434b"), (w, core)):
        c.create_line(*flat, fill=col, width=wdt, smooth=True,
                      joinstyle="round", capstyle="round", tags=tags)


def _anchors_curve(anchors, n: int) -> list[float]:
    """Cosine-eased interpolation through (t, v) anchors, v in 0..1."""
    out = []
    for i in range(n):
        t = i / max(1, n - 1)
        val = anchors[-1][1]
        for j in range(len(anchors) - 1):
            t0, v0 = anchors[j]
            t1, v1 = anchors[j + 1]
            if t0 <= t <= t1:
                u = (t - t0) / max(1e-9, t1 - t0)
                u = 0.5 - 0.5 * math.cos(math.pi * u)
                val = v0 + (v1 - v0) * u
                break
        val += 0.015 * math.sin(34 * t + 1.3) + 0.010 * math.sin(61 * t)
        out.append(max(0.0, min(1.0, val)))
    return out


def _spark_pts(seed: int, x0, y0, x1, y1, n=34) -> list[tuple[float, float]]:
    """Organic-looking sparkline points inside the given box."""
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, 6.28) for _ in range(3)]
    am = [rnd.uniform(0.55, 0.9), rnd.uniform(0.25, 0.45), rnd.uniform(0.10, 0.22)]
    up = rnd.uniform(0.05, 0.22)
    pts = []
    for i in range(n):
        t = i / (n - 1)
        v = 0.52 + up * (t - 0.5) * 2
        v += 0.30 * am[0] * math.sin(6.283 * (1.1 * t) + ph[0])
        v += 0.16 * am[1] * math.sin(6.283 * (2.6 * t) + ph[1])
        v += 0.07 * am[2] * math.sin(6.283 * (5.3 * t) + ph[2])
        v = max(0.06, min(0.94, v))
        pts.append((x0 + t * (x1 - x0), y1 - v * (y1 - y0)))
    return pts


def paint_chrome_n(c: tk.Canvas, x, y, w, h, tags="") -> None:
    """Chrome-gradient N glyph (the NTH logo)."""
    s = w * 0.30
    stops = ["#fafbfc", "#d9dde1", "#a9afb5", "#7b8187", "#989ea4",
             "#c7cdd3", "#f0f3f5"]
    bands = 26
    for i in range(bands):
        y1 = y + h * i / bands
        y2 = y + h * (i + 1) / bands
        t1 = i / (bands - 1)
        col = _grad(stops, t1)
        c.create_rectangle(x, y1, x + s, y2 + 0.5, fill=col, outline="",
                           tags=tags)
        c.create_rectangle(x + w - s, y1, x + w, y2 + 0.5, fill=col,
                           outline="", tags=tags)
        lx1 = x + (w - s) * t1
        rx1 = x + s + (w - s) * t1
        t2 = (i + 1) / (bands - 1)
        lx2 = x + (w - s) * t2
        rx2 = x + s + (w - s) * t2
        c.create_polygon(lx1, y1, rx1, y1, rx2, y2, lx2, y2, fill=col,
                         outline="", tags=tags)


# ---------------------------------------------------------------------------
# vector icons
# ---------------------------------------------------------------------------

class Icons:
    @staticmethod
    def draw(c: tk.Canvas, name: str, cx, cy, s, col, tags="") -> None:
        fn = getattr(Icons, name, None)
        if fn:
            fn(c, cx, cy, s, col, tags)

    @staticmethod
    def home(c, cx, cy, s, col, tags=""):
        c.create_polygon(
            (cx - s, cy - 0.05 * s), (cx, cy - s), (cx + s, cy - 0.05 * s),
            (cx + s, cy + s), (cx - s, cy + s),
            fill=col, outline="", tags=tags)
        c.create_rectangle(cx - 0.32 * s, cy + 0.30 * s, cx + 0.32 * s,
                           cy + s, fill=CARD, outline="", tags=tags)

    @staticmethod
    def target(c, cx, cy, s, col, tags=""):
        r = s * 0.72
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=col, width=1.4,
                      tags=tags)
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            c.create_line(cx + dx * r * 0.75, cy + dy * r * 0.75,
                          cx + dx * (s + 0.8), cy + dy * (s + 0.8),
                          fill=col, width=1.4, tags=tags)
        c.create_oval(cx - 1.3, cy - 1.3, cx + 1.3, cy + 1.3, fill=col,
                      outline="", tags=tags)

    @staticmethod
    def eye(c, cx, cy, s, col, tags=""):
        c.create_arc(cx - s, cy - s * 0.95, cx + s, cy + s * 0.95,
                     start=25, extent=125, style="arc", outline=col,
                     width=1.4, tags=tags)
        c.create_arc(cx - s, cy - s * 0.95, cx + s, cy + s * 0.95,
                     start=205, extent=125, style="arc", outline=col,
                     width=1.4, tags=tags)
        r = s * 0.30
        c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="",
                      tags=tags)

    @staticmethod
    def gear(c, cx, cy, s, col, tags=""):
        r = s * 0.62
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=col, width=1.4,
                      tags=tags)
        for i in range(8):
            a = math.pi / 4 * i
            c.create_line(cx + math.cos(a) * r * 0.92,
                          cy + math.sin(a) * r * 0.92,
                          cx + math.cos(a) * (s + 0.4),
                          cy + math.sin(a) * (s + 0.4),
                          fill=col, width=1.6, tags=tags)
        r2 = s * 0.24
        c.create_oval(cx - r2, cy - r2, cx + r2, cy + r2, outline=col,
                      width=1.1, tags=tags)

    @staticmethod
    def info(c, cx, cy, s, col, tags=""):
        r = s * 0.85
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=col, width=1.4,
                      tags=tags)
        c.create_oval(cx - 0.9, cy - s * 0.52, cx + 0.9, cy - s * 0.52 + 1.8,
                      fill=col, outline="", tags=tags)
        c.create_line(cx, cy - s * 0.12, cx, cy + s * 0.5, fill=col,
                      width=1.6, tags=tags)

    @staticmethod
    def zap(c, cx, cy, s, col, tags=""):
        c.create_polygon(
            (cx + 0.18 * s, cy - s), (cx - 0.58 * s, cy + 0.18 * s),
            (cx - 0.06 * s, cy + 0.18 * s), (cx - 0.18 * s, cy + s),
            (cx + 0.58 * s, cy - 0.18 * s), (cx + 0.06 * s, cy - 0.18 * s),
            fill=col, outline="", tags=tags)

    @staticmethod
    def gauge(c, cx, cy, s, col, tags=""):
        c.create_arc(cx - s, cy - s * 0.85, cx + s, cy + s * 0.85,
                     start=-32, extent=244, style="arc", outline=col,
                     width=1.6, tags=tags)
        a = math.radians(-38)
        c.create_line(cx, cy, cx + math.cos(a) * s * 0.55,
                      cy + math.sin(a) * s * 0.55, fill=col, width=1.6,
                      tags=tags)
        c.create_oval(cx - 1.5, cy - 1.5, cx + 1.5, cy + 1.5, fill=col,
                      outline="", tags=tags)

    @staticmethod
    def cube(c, cx, cy, s, col, tags=""):
        r = s * 0.92
        vs = []
        for i in range(6):
            a = math.pi / 3 * i + math.pi / 6
            vs.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
        c.create_polygon(vs + [vs[0]], outline=col, fill="", width=1.3,
                         tags=tags)
        for idx in (1, 3, 5):
            c.create_line(cx, cy, vs[idx][0], vs[idx][1], fill=col,
                          width=1.1, tags=tags)

    @staticmethod
    def cpu(c, cx, cy, s, col, tags=""):
        k = s * 0.68
        c.create_rectangle(cx - k, cy - k, cx + k, cy + k, outline=col,
                           width=1.3, tags=tags)
        k2 = s * 0.30
        c.create_rectangle(cx - k2, cy - k2, cx + k2, cy + k2, outline=col,
                           width=1.0, tags=tags)
        for i in (-1, 0, 1):
            t = i * s * 0.40
            c.create_line(cx + t, cy - k, cx + t, cy - s, fill=col,
                          width=1.1, tags=tags)
            c.create_line(cx + t, cy + k, cx + t, cy + s, fill=col,
                          width=1.1, tags=tags)
            c.create_line(cx - k, cy + t, cx - s, cy + t, fill=col,
                          width=1.1, tags=tags)
            c.create_line(cx + k, cy + t, cx + s, cy + t, fill=col,
                          width=1.1, tags=tags)

    @staticmethod
    def pulse(c, cx, cy, s, col, tags=""):
        pts = [(cx - s, cy), (cx - s * 0.45, cy), (cx - s * 0.22, cy - s * 0.72),
               (cx + 0.08 * s, cy + s * 0.72), (cx + 0.32 * s, cy),
               (cx + s, cy)]
        c.create_line(*[v for p in pts for v in p], fill=col, width=1.5,
                      smooth=True, joinstyle="round", capstyle="round",
                      tags=tags)

    @staticmethod
    def layers(c, cx, cy, s, col, tags=""):
        top = [(cx, cy - s * 0.85), (cx + s * 0.85, cy - s * 0.30),
               (cx, cy + 0.25 * s), (cx - s * 0.85, cy - s * 0.30)]
        c.create_polygon(top, outline=col, fill="", width=1.2, tags=tags)
        for dy in (s * 0.34, s * 0.72):
            c.create_line(cx - s * 0.85, cy + dy - s * 0.30, cx,
                          cy + dy + s * 0.26, cx + s * 0.85,
                          cy + dy - s * 0.30, fill=col, width=1.2,
                          joinstyle="round", tags=tags)

    @staticmethod
    def bars(c, cx, cy, s, col, tags=""):
        for i, hh in enumerate((0.42, 0.78, 0.58)):
            x = cx - s * 0.62 + i * s * 0.62
            c.create_line(x, cy + s * 0.72, x, cy + s * 0.72 - s * hh * 1.55,
                          fill=col, width=2.4, capstyle="round", tags=tags)

    @staticmethod
    def play(c, cx, cy, s, col, tags=""):
        c.create_polygon((cx - 0.38 * s, cy - 0.58 * s),
                         (cx + 0.58 * s, cy), (cx - 0.38 * s, cy + 0.58 * s),
                         fill=col, outline="", tags=tags)

    @staticmethod
    def stop(c, cx, cy, s, col, tags=""):
        k = s * 0.46
        c.create_rectangle(cx - k, cy - k, cx + k, cy + k, fill=col,
                           outline="", tags=tags)

    @staticmethod
    def reload(c, cx, cy, s, col, tags=""):
        c.create_arc(cx - s * 0.8, cy - s * 0.8, cx + s * 0.8, cy + s * 0.8,
                     start=48, extent=285, style="arc", outline=col,
                     width=1.6, tags=tags)
        a = math.radians(48)
        ax = cx + math.cos(a) * s * 0.8
        ay = cy - math.sin(a) * s * 0.8
        c.create_polygon((ax - 3.4, ay - 1.2), (ax + 3.0, ay - 1.2),
                         (ax + 0.4, ay - 5.4), fill=col, outline="",
                         tags=tags)

    @staticmethod
    def check(c, cx, cy, s, col, tags=""):
        c.create_line(cx - s * 0.55, cy, cx - s * 0.15, cy + s * 0.42,
                      cx + s * 0.6, cy - s * 0.42, fill=col, width=1.8,
                      joinstyle="round", capstyle="round", tags=tags)


# ---------------------------------------------------------------------------
# widgets
# ---------------------------------------------------------------------------

class Switch(tk.Canvas):
    """Animated toggle switch (design: green track, white knob)."""

    ON = GREEN
    OFF = "#22262c"

    def __init__(self, master, on: bool, command, w=44, h=22, bg=CARD):
        super().__init__(master, width=w, height=h, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.w, self.h = w, h
        self._on = bool(on)
        self._t = 1.0 if on else 0.0
        self._anim_job = None
        self.command = command
        self.bind("<Button-1>", self._clicked)
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        pad = 2
        bar_h = self.h - pad * 2
        fill = _lerp(self.OFF, self.ON, self._t)
        outline = _lerp("#2c3138", _lerp(self.ON, "#ffffff", 0.30), self._t)
        self.create_polygon(
            _round_pts(pad, pad, self.w - pad, self.h - pad, bar_h // 2),
            fill=fill, outline=outline, smooth=True)
        knob_r = (bar_h - 3) / 2
        kx = pad + 1.5 + knob_r + self._t * (self.w - pad * 2 - 3 - 2 * knob_r)
        ky = self.h / 2
        self.create_oval(kx - knob_r, ky - knob_r, kx + knob_r, ky + knob_r,
                         fill="#f4f5f7", outline="")

    def _clicked(self, _e=None) -> None:
        self.set(not self._on)
        if self.command:
            self.command(self._on)

    def _animate_to(self, target: float) -> None:
        if self._anim_job:
            self.after_cancel(self._anim_job)
            self._anim_job = None

        def step() -> None:
            d = target - self._t
            if abs(d) < 0.02:
                self._t = target
                self._anim_job = None
                self._draw()
                return
            self._t += d * 0.38
            self._draw()
            self._anim_job = self.after(14, step)

        step()

    def set(self, on: bool, animate: bool = True) -> None:
        on = bool(on)
        if on == self._on:
            return
        self._on = on
        if animate:
            self._animate_to(1.0 if on else 0.0)
        else:
            self._t = 1.0 if on else 0.0
            self._draw()

    def get(self) -> bool:
        return self._on


class PillButton(tk.Canvas):
    """Rounded pill button with animated hover + optional selected state."""

    def __init__(self, master, text, command=None, w=None, h=26, size=9,
                 bold=False, bg=CARD, selected=False, mono=False):
        fam = MONO if mono else FAMILY
        self.font = tkfont.Font(family=fam, size=-size,
                                weight="bold" if bold else "normal")
        if w is None:
            w = self.font.measure(text) + 24
        super().__init__(master, width=w, height=h, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.w, self.h = w, h
        self.text = text
        self.command = command
        self.selected = selected
        self._hover = False
        self._ht = 0.0          # animated hover blend 0..1
        self._hjob = None
        self.bind("<Button-1>", self._click)
        self.bind("<Enter>", lambda _e: self._set_hover(True))
        self.bind("<Leave>", lambda _e: self._set_hover(False))
        self._draw()

    def _set_hover(self, on: bool) -> None:
        self._hover = on
        self._tween_hover(1.0 if on else 0.0)

    def _tween_hover(self, target: float) -> None:
        if self._hjob:
            try:
                self.after_cancel(self._hjob)
            except Exception:
                pass
            self._hjob = None

        def step() -> None:
            d = target - self._ht
            if abs(d) < 0.05:
                self._ht = target
                self._hjob = None
                self._draw()
                return
            self._ht += d * 0.42
            self._draw()
            self._hjob = self.after(16, step)

        step()

    def _click(self, _e=None) -> None:
        if self.command:
            self.command()

    def set_selected(self, sel: bool) -> None:
        if sel != self.selected:
            self.selected = sel
            self._draw()

    def _draw(self) -> None:
        self.delete("all")
        w, h = self.w, self.h
        t = self._ht
        if self.selected:
            fill, line, txt = "#22262c", "#3a4048", FG
        else:
            fill = _lerp("#101318", "#15181d", t)
            line = _lerp(BORDER, BORDER_HI, t)
            txt = _lerp(DIM, FG, t)
        self.create_polygon(_round_pts(1, 1, w - 1, h - 1, min(h // 2, 14)),
                            fill=fill, outline=line, smooth=True)
        self.create_text(w // 2, h // 2, text=self.text, fill=txt,
                         font=self.font)


class IconButton(tk.Canvas):
    """Quick-action button: icon above label, animated hover feedback."""

    def __init__(self, master, label, icon, command, w=62, h=42, bg=CARD):
        super().__init__(master, width=w, height=h, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.w, self.h = w, h
        self.label = label
        self.icon = icon
        self.command = command
        self._hover = False
        self._ht = 0.0          # animated hover blend 0..1
        self._hjob = None
        self.bind("<Button-1>", lambda _e: self.command() if self.command else None)
        self.bind("<Enter>", lambda _e: self._set_hover(True))
        self.bind("<Leave>", lambda _e: self._set_hover(False))
        self._draw()

    def _set_hover(self, on: bool) -> None:
        self._hover = on
        self._tween_hover(1.0 if on else 0.0)

    def _tween_hover(self, target: float) -> None:
        if self._hjob:
            try:
                self.after_cancel(self._hjob)
            except Exception:
                pass
            self._hjob = None

        def step() -> None:
            d = target - self._ht
            if abs(d) < 0.05:
                self._ht = target
                self._hjob = None
                self._draw()
                return
            self._ht += d * 0.42
            self._draw()
            self._hjob = self.after(16, step)

        step()

    def _draw(self) -> None:
        self.delete("all")
        w, h = self.w, self.h
        t = self._ht
        fill = _lerp("#12151a", "#171b21", t)
        line = _lerp("#262b31", BORDER_HI, t)
        icol = _lerp("#dfe3e8", FG, t)
        lbl = _lerp(DIM, FG, t)
        self.create_polygon(_round_pts(1, 1, w - 1, h - 1, 12), fill=fill,
                            outline=line, smooth=True)
        Icons.draw(self, self.icon, w / 2, 15 - 1.4 * t, 6.5, icol)
        self.create_text(w / 2, h - 9, text=self.label, fill=lbl,
                         font=(FAMILY, -8))


# ---------------------------------------------------------------------------
# the panel
# ---------------------------------------------------------------------------

DEMO_ANCHORS = [(0, 0.13), (0.09, 0.22), (0.20, 0.46), (0.30, 0.66),
                (0.42, 0.85), (0.50, 0.68), (0.58, 0.58), (0.66, 0.72),
                (0.74, 0.56), (0.84, 0.68), (0.93, 0.58), (1.0, 0.72)]

RANGES = [("1m", 60), ("5m", 300), ("1h", 3600)]


def _proc_mem_bytes() -> float:
    """This process working set (best effort, stdlib only)."""
    if os.name == "nt":
        try:
            import ctypes

            class _PMC(ctypes.Structure):
                _fields_ = [
                    ("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t)]

            pmc = _PMC()
            pmc.cb = ctypes.sizeof(_PMC)
            psapi = ctypes.WinDLL("psapi")
            h = ctypes.WinDLL("kernel32").GetCurrentProcess()
            if psapi.GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb):
                return float(pmc.WorkingSetSize)
        except Exception:
            pass
        return 0.0
    try:
        with open("/proc/self/status", "r", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    return float(line.split()[1]) * 1024.0
    except OSError:
        pass
    return 0.0


def _resolve_fonts() -> None:
    global FAMILY, MONO
    for f in ("Segoe UI", "Noto Sans", "Noto Sans SC", "DejaVu Sans"):
        try:
            if tkfont.Font(family=f, size=-12).actual("family").lower() == f.lower():
                FAMILY = f
                break
        except Exception:
            continue
    for m in ("Consolas", "Cascadia Mono", "DejaVu Sans Mono", "Courier New"):
        try:
            if tkfont.Font(family=m, size=-12).actual("family").lower() == m.lower():
                MONO = m
                break
        except Exception:
            continue


class ControlPanel(tk.Toplevel):
    W, H = W, H

    def __init__(self, root: tk.Tk, app, reader, overlay, actions,
                 version: str = "2.1"):
        super().__init__(root, bg=BG)
        _resolve_fonts()
        self.app = app
        self.reader = reader
        self.overlay = overlay
        self.actions = actions
        self.version = version
        self.console_q: "queue.Queue[tuple[str, str]]" = queue.Queue()
        self._drag = None
        self._zoomed = False
        self.tab = 0
        self.nav_hover = -1
        self.range_idx = 0
        self._poll_n = 0
        self._sb_state = ""
        # animation state (page slide, nav pill tween, waves, gif, tickers)
        self._anim_phase = 0.0
        self._nav_y = 104.0
        self._nav_job = None
        self._nav_paint_job = None
        self._wc_paint_job = None
        self._slide_job = None
        self._disp = {"rate": 0.0, "obj": 0.0, "mem": 0.0}
        self._gif_frames = None
        self._gif_idx = 0

        self.fps_hist: deque = deque(maxlen=1800)
        self.rate_hist: deque = deque(maxlen=600)
        self.mem_hist: deque = deque(maxlen=600)
        self.obj_hist: deque = deque(maxlen=600)

        # -- demo mode (screenshots only) ---------------------------------
        self.demo = os.environ.get("NTH_DEMO") == "1"
        self._t0 = time.time()
        if self.demo:
            self._t0 = time.time() - 767.0
            now = time.time()
            for i, v in enumerate(_anchors_curve(DEMO_ANCHORS, 110)):
                self.fps_hist.append((now - 60.0 + i * (60.0 / 109.0), v * 75.0))
            for h in (self.rate_hist, self.mem_hist, self.obj_hist):
                h.append((now - 70.0, 0.0))

        # -- window --------------------------------------------------------
        self.title("NTH External Reader")
        try:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        except Exception:
            sw, sh = 800, 500
        self._home = (max(0, (sw - W) // 2), max(0, (sh - H) // 2))
        self.geometry(f"{W}x{H}+{self._home[0]}+{self._home[1]}")
        self.resizable(False, False)
        self.overrideredirect(True)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.protocol("WM_DELETE_WINDOW", self._quit)
        self._winExtras()

        # -- shell: sidebar + main -----------------------------------------
        self.shell = tk.Frame(self, width=W, height=H, bg=BG)
        self.shell.place(x=0, y=0)
        self.shell.pack_propagate(False)

        self.sb = tk.Canvas(self.shell, width=SIDEBAR_W, height=H, bg=BG,
                            highlightthickness=0, bd=0)
        self.sb.place(x=0, y=0)
        self._paint_sidebar_base()

        main = tk.Frame(self.shell, width=PAGE_W, height=H, bg=BG)
        main.place(x=SIDEBAR_W, y=0)
        main.pack_propagate(False)

        self.tb = tk.Canvas(main, width=PAGE_W, height=TITLEBAR_H, bg=BG,
                            highlightthickness=0, bd=0)
        self.tb.place(x=0, y=0)
        self._build_titlebar()

        self.pages = tk.Frame(main, width=PAGE_W, height=PAGE_H, bg=BG)
        self.pages.place(x=0, y=TITLEBAR_H)
        self.pages.pack_propagate(False)

        self.ov = self._page()
        self.rd_pg = self._page()
        self.vs_pg = self._page()
        self.st_pg = self._page()
        self.ab_pg = self._page()
        self.frames = [pg.master for pg in
                       (self.ov, self.rd_pg, self.vs_pg, self.st_pg,
                        self.ab_pg)]
        self._build_overview()
        self._build_reader()
        self._build_visuals()
        self._build_settings()
        self._build_about()
        self.frames[0].tkraise()
        self._paint_nav()

        self.after(120, self._poll)
        self.after(120, self._anim_tick)
        self.after(80, lambda: self._slide_page(self.frames[0]))

    # ---------------------------------------------------------------- pages
    def _page(self) -> tk.Canvas:
        """A page = plain Frame (stackable via tkraise) holding the canvas."""
        holder = tk.Frame(self.pages, width=PAGE_W, height=PAGE_H, bg=BG)
        holder.place(x=0, y=0)
        holder.pack_propagate(False)
        c = tk.Canvas(holder, width=PAGE_W, height=PAGE_H, bg=BG,
                      highlightthickness=0, bd=0)
        c.place(x=0, y=0)
        return c

    # base geometry of the background waves (x, y) pairs; animated in _anim_tick
    WAVES_DEF = [
        ([(-60, 300), (160, 286), (420, 320), (740, 288)], 70, "#090a0d"),
        ([(-40, 420), (220, 400), (520, 436), (760, 404)], 60, "#08090c"),
        ([(430, 30), (620, 8), (760, 26)], 34, "#0b0c10"),
        ([(300, 120), (540, 96), (720, 118)], 2, "#121419"),
        ([(520, 440), (700, 416), (780, 432)], 2, "#101216"),
    ]

    @classmethod
    def _waves(cls, c: tk.Canvas) -> None:
        for i, (pts, w, col) in enumerate(cls.WAVES_DEF):
            flat = [v for p in pts for v in p]
            c.create_line(*flat, smooth=True, width=w, fill=col,
                          tags=f"wave{i}")

    # ------------------------------------------------------------- titlebar
    def _build_titlebar(self) -> None:
        c = self.tb
        n = 46
        for i in range(n):
            t = i / (n - 1)
            x0 = 18 + t * 184
            c.create_line(x0, 17, x0 + 184 / n + 1, 17,
                          fill=_grad(["#4a5058", "#23262c", "#0b0d10"], t))
        c.create_text(344, 17, text="N T H   \u00b7   E X T E R N A L   R E A D E R",
                      fill=FAINT, font=(FAMILY, -8))
        for w in (c,):
            w.bind("<Button-1>", self._drag_start)
            w.bind("<B1-Motion>", self._drag_move)
        self._wc_state = {"min": False, "max": False, "close": False}
        for name, cx in (("min", 600), ("max", 634), ("close", 668)):
            for seq, fn in (("<Enter>", True), ("<Leave>", False)):
                c.tag_bind(f"wc_{name}", seq,
                           lambda _e, n_=name, v=fn: self._paint_wc(n_, v))
            # hover repaint is destructive (delete+recreate of the item under
            # the cursor).  Also retrigger it from Motion/Leave, but only once
            # per state change so we never delete while Tk is still pumping
            # Enter/Leave/Motion events for the same item.
            c.tag_bind(f"wc_{name}", "<Motion>",
                       lambda _e, n_=name: self._paint_wc(n_, True, once=True))
            c.tag_bind(f"wc_{name}", "<Leave>",
                       lambda _e, n_=name: self._paint_wc(n_, False, once=True))
        c.tag_bind("wc_min", "<Button-1>", lambda _e: self._minimize())
        c.tag_bind("wc_max", "<Button-1>", lambda _e: self._toggle_zoom())
        c.tag_bind("wc_close", "<Button-1>", lambda _e: self._quit())
        self._paint_wc("min", False)
        self._paint_wc("max", False)
        self._paint_wc("close", False)

    def _paint_wc(self, name: str, hover: bool, once: bool = False) -> None:
        if once and self._wc_state.get(name) == hover:
            return  # suppress redundant destructive repaints under the cursor
        self._wc_state[name] = hover
        # Defer the (destructive) repaint out of the event dispatch that is
        # currently delivering Enter/Leave/Motion for these very items.
        if self._wc_paint_job:
            return
        try:
            self._wc_paint_job = self.after_idle(self._wc_paint_now)
        except Exception:
            self._wc_paint_now()

    def _wc_paint_now(self) -> None:
        c = self.tb
        self._wc_paint_job = None
        for name in ("min", "max", "close"):
            hover = self._wc_state[name]
            c.delete(f"wc_{name}")
            cx, cy = {"min": 600, "max": 634, "close": 668}[name], 17
            if hover:
                bgc = "#2a1315" if name == "close" else "#1a1e24"
                c.create_polygon(
                    _round_pts(cx - 14, cy - 10, cx + 14, cy + 10, 8),
                    fill=bgc, outline="", smooth=True, tags=f"wc_{name}")
            col = ERR if (name == "close" and hover) else (
                FG if hover else "#8a9098")
            if name == "min":
                c.create_line(cx - 4.5, cy, cx + 4.5, cy, fill=col,
                              width=1.4, capstyle="round", tags=f"wc_{name}")
            elif name == "max":
                c.create_rectangle(cx - 4, cy - 4, cx + 4, cy + 4,
                                   outline=col, width=1.3,
                                   tags=f"wc_{name}")
            else:
                k = 3.6
                c.create_line(cx - k, cy - k, cx + k, cy + k, fill=col,
                              width=1.4, capstyle="round", tags=f"wc_{name}")
                c.create_line(cx - k, cy + k, cx + k, cy - k, fill=col,
                              width=1.4, capstyle="round", tags=f"wc_{name}")

    # -------------------------------------------------------------- sidebar
    def _paint_sidebar_base(self) -> None:
        c = self.sb
        c.delete("base", "sbst", "sbspark")
        paint_chrome_n(c, 41, 16, 34, 30, tags="base")
        c.create_text(58, 58, text="NTH", fill=FG, font=(FAMILY, -14, "bold"),
                      tags="base")
        c.create_text(58, 71, text="EXTERNAL READER", fill=DIM,
                      font=(FAMILY, -6), tags="base")
        c.create_text(58, 82, text=f"v{self.version}", fill=FAINT,
                      font=(FAMILY, -7), tags="base")
        # status card
        c.create_polygon(_round_pts(10, 428, 106, 488, 14), fill="#0b0d10",
                         outline=BORDER, smooth=True, tags="base")
        c.create_text(20, 440, text="Status", fill=DIM, font=(FAMILY, -8),
                      anchor="w", tags="base")
        _glow_line(c, _spark_pts(7, 18, 462, 98, 482, 26), tags="sbspark",
                   core="#c9ced4", w=1)
        c.create_line(SIDEBAR_W - 0.5, 0, SIDEBAR_W - 0.5, H, fill="#14161a")
        self._paint_nav()
        self._paint_sb_status()

    def _paint_nav(self) -> None:
        c = self.sb
        c.delete("nav")
        for i, (label, icon) in enumerate(NAV_ITEMS):
            y = 104 + i * 40
            active = i == self.tab
            hov = i == self.nav_hover and not active
            py = self._nav_y if active else y
            if active or hov:
                c.create_polygon(_round_pts(10, py, 106, py + 32, 12),
                                 fill="#1a1d22" if active else "#0f1216",
                                 outline="#2e333a" if active else BORDER,
                                 smooth=True, tags=("nav", f"nav{i}"))
            ic_col = FG if active else ("#c4c9cf" if hov else "#7c828a")
            Icons.draw(c, icon, 27, py + 16, 7, ic_col, tags=("nav", f"nav{i}"))
            c.create_text(44, py + 16, text=label, anchor="w",
                          fill=FG if active else (DIM if hov else "#8a9098"),
                          font=(FAMILY, -11), tags=("nav", f"nav{i}"))
            c.tag_bind(f"nav{i}", "<Button-1>",
                       lambda _e, k=i: self.show_tab(k))
            c.tag_bind(f"nav{i}", "<Enter>",
                       lambda _e, k=i: self._nav_hover(k))
            c.tag_bind(f"nav{i}", "<Leave>",
                       lambda _e, k=i: self._nav_hover(-1))
            # _paint_nav is destructive (delete+recreate of the item under the
            # cursor).  Re-arm the hover state from Motion/Leave too, but only
            # once per change: this keeps hover visuals honest without ever
            # deleting canvas items while Tk is still dispatching
            # enter/leave/motion for them (deleting under the cursor can wedge
            # Tk's event loop / segfault).
            c.tag_bind(f"nav{i}", "<Motion>",
                       lambda _e, k=i: self._nav_hover(k, once=True))
            c.tag_bind(f"nav{i}", "<Leave>",
                       lambda _e, k=i: self._nav_hover(-1, once=True))

    def _nav_hover(self, k: int, once: bool = False) -> None:
        if once and self.nav_hover == k:
            return
        self.nav_hover = k
        # Defer the (destructive) repaint out of the event dispatch that is
        # currently delivering Enter/Leave/Motion for these very items.
        self._nav_paint_soon()

    def _nav_paint_soon(self) -> None:
        if self._nav_paint_job:
            return
        try:
            self._nav_paint_job = self.after_idle(self._nav_paint_now)
        except Exception:
            self._nav_paint_now()

    def _nav_paint_now(self) -> None:
        self._nav_paint_job = None
        self._paint_nav()

    def _paint_sb_status(self) -> None:
        c = self.sb
        c.delete("sbst")
        st = self._health()
        col, txt = {"ok": (GREEN, "Online"), "warn": (AMBER, "Waiting"),
                    "err": (ERR, "Offline")}[st]
        r = 3.0 + 0.9 * math.sin(time.time() * 2.6)
        cx, cy = 23, 456
        c.create_oval(cx - r - 2.4, cy - r - 2.4, cx + r + 2.4, cy + r + 2.4,
                      fill=_lerp(BG, col, 0.22), outline="", tags="sbst")
        c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="",
                      tags="sbst")
        c.create_text(32, 456, text=txt, fill=col, font=(FAMILY, -8),
                      anchor="w", tags="sbst")

    # -------------------------------------------------------------- helpers
    def _health(self) -> str:
        s = (self.reader.status or "").lower()
        if s.startswith("error"):
            return "err"
        if s.startswith("reading") or s in ("attached", "selftest preview"):
            return "ok"
        return "warn"

    def _uptime_secs(self) -> int:
        if self.demo:
            return 767
        return max(0, int(time.time() - self._t0))

    @staticmethod
    def _fmt_uptime(sec: int) -> str:
        h, r = divmod(sec, 3600)
        m, s = divmod(r, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _rate_val(self) -> float:
        if self.demo:
            return 45.7e6
        return float(getattr(self.reader, "bytes_rate", 0.0) or 0.0)

    def _mem_val(self) -> float:
        if self.demo:
            return 142e6
        return _proc_mem_bytes()

    def _obj_val(self) -> int:
        if self.demo:
            return 256
        v = getattr(self.reader, "last_objects", 0)
        return int(v or getattr(self.reader, "players_seen", 0) or 0)

    def _delta(self, which: str, val: float, hist) -> float | None:
        if self.demo:
            return {"rate": 12.0, "obj": 0.0, "mem": 8.0}[which]
        now = time.time()
        base = None
        for t, v in hist:
            if t >= now - 75:
                base = v
                break
        if base is None or base <= 0:
            return None
        return (val - base) / base * 100.0

    @staticmethod
    def _fmt_rate(v: float) -> tuple[str, str]:
        if v >= 1e9:
            return f"{v / 1e9:.1f}", "GB/s"
        if v >= 1e6:
            return f"{v / 1e6:.1f}", "MB/s"
        if v >= 1e3:
            return f"{v / 1e3:.1f}", "KB/s"
        return f"{v:.0f}", "B/s"

    @staticmethod
    def _fmt_mem(v: float) -> tuple[str, str]:
        if v >= 1e9:
            return f"{v / 1e9:.2f}", "GB"
        return f"{v / 1e6:.0f}", "MB"

    def _draw_delta(self, c, x_right, y, pct, tag) -> None:
        c.delete(tag)
        if pct is None:
            pct = 0.0
        col = "#cfd4da"
        txt = f"{pct:+.0f}%"
        f = tkfont.Font(family=FAMILY, size=-9)
        tw = f.measure(txt)
        c.create_text(x_right, y, anchor="e", text=txt, fill=col,
                      font=f, tags=tag)
        tx = x_right - tw - 8
        if pct < -0.05:
            c.create_polygon((tx - 3, y - 2.5), (tx + 3, y - 2.5), (tx, y + 3.5),
                             fill=col, outline="", tags=tag)
        else:
            c.create_polygon((tx - 3, y + 2.5), (tx + 3, y + 2.5), (tx, y - 3.5),
                             fill=col, outline="", tags=tag)

    # ------------------------------------------------------------- overview
    def _build_overview(self) -> None:
        c = self.ov
        self._waves(c)
        # header
        c.create_text(18, 40, text="Overview", anchor="w", fill=FG,
                      font=(FAMILY, -30, "bold"), tags="base")
        c.create_text(18, 72, text="Your system at a glance.", anchor="w",
                      fill=DIM, font=(FAMILY, -11), tags="base")
        # quick actions strip (header row)
        qa = [("Start", "play", self._qa_start), ("Stop", "stop", self._qa_stop),
              ("Reload", "reload", self._qa_reload),
              ("Settings", "gear", self._qa_settings)]
        for i, (lbl, icon, cmd) in enumerate(qa):
            b = IconButton(self.ov, lbl, icon, cmd, w=62, h=42, bg=BG)
            b.place(x=184 + i * 66, y=22)
        # uptime pill
        c.create_polygon(_round_pts(470, 32, 670, 64, 16), fill="#0b0d10",
                         outline=BORDER, smooth=True, tags="base")
        Icons.draw(c, "zap", 490, 48, 6, "#dfe3e8", tags="base")
        c.create_text(504, 48, text="Uptime:", anchor="w", fill=DIM,
                      font=(FAMILY, -10), tags="base")
        c.create_text(556, 48, text="00:12:47", anchor="w", fill=FG,
                      font=(FAMILY, -10), tags="up_t")
        _glow_line(c, _spark_pts(3, 614, 40, 664, 58, 26), tags="base",
                   core="#c9ced4", w=1)
        # stat cards
        self._stat_card(c, 0, 18, 227, "READ RATE", "gauge")
        self._stat_card(c, 1, 239, 448, "OBJECTS", "cube")
        self._stat_card(c, 2, 460, 670, "MEMORY", "cpu")
        # reader status card (2x2 status grid)
        _card(c, 18, 176, 482, 302, r=18)
        c.create_oval(30, 188, 38, 196, fill=FG, outline="", tags="base")
        c.create_text(46, 192, text="Reader Status", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(456, 192, text="All systems operational.", anchor="e",
                      fill=DIM, font=(FAMILY, -9), tags="st_hdr")
        Icons.draw(c, "check", 466, 192, 5, GREEN, tags="st_chk")
        # performance card (bottom-left, wide chart)
        _card(c, 18, 314, 482, 458, r=18)
        Icons.draw(c, "bars", 34, 330, 6, ICON, tags="base")
        c.create_text(48, 330, text="Performance", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        self.rng_btns = []
        for i, (lbl, _s) in enumerate(RANGES):
            b = PillButton(self.ov, lbl, command=lambda k=i: self._set_range(k),
                           w=26, h=20, size=8, selected=(i == 0))
            b.place(x=396 + i * 30, y=330, anchor="center")
            self.rng_btns.append(b)
        # mascot square section (right column)
        _card(c, 494, 176, 670, 352, r=18)
        c.create_polygon(_round_pts(504, 186, 660, 342, 12), fill="#000000",
                         outline="#1c1f24", smooth=True, tags="base")
        self._gif_frames = self._load_gif()
        self._gif_idx = 0
        if self._gif_frames:
            c.create_image(504, 186, anchor="nw",
                           image=self._gif_frames[0], tags="gifimg")
            self.after(GIF_MS, self._gif_tick)
        else:
            self._paint_gif_placeholder(c)
        c.create_polygon(_round_pts(502, 184, 662, 344, 13), fill="",
                         outline=ACCENT, width=1.2, dash=(5, 4), dashoffset=0,
                         smooth=True, tags="gifring")
        # brand card (right bottom)
        _card(c, 494, 364, 670, 458, r=16)
        paint_chrome_n(c, 508, 376, 26, 30, tags="base")
        c.create_text(542, 391, text="NTH", anchor="w", fill=FG,
                      font=(FAMILY, -13, "bold"), tags="base")
        c.create_text(508, 420, text="Built for performance.", anchor="w",
                      fill=DIM, font=(FAMILY, -8), tags="base")
        c.create_text(508, 432, text="Designed for you.", anchor="w",
                      fill=DIM, font=(FAMILY, -8), tags="base")
        c.create_text(658, 447, text=f"NTH \u00b7 v{self.version}", anchor="e",
                      fill=FAINT, font=(FAMILY, -8), tags="base")

    def _stat_card(self, c, idx, x1, x2, label, icon) -> None:
        _card(c, x1, 84, x2, 164, r=16)
        Icons.draw(c, icon, x1 + 24, 100, 7, ICON, tags="base")
        c.create_text(x1 + 40, 100, text=label, anchor="w", fill=DIM,
                      font=(FAMILY, -9), tags="base")
        c.create_text(x1 + 16, 130, text="0", anchor="w", fill=FG,
                      font=(FAMILY, -24, "bold"), tags=f"stat_v{idx}")
        c.create_text(x1 + 60, 134, text="", anchor="w", fill=DIM,
                      font=(FAMILY, -10), tags=f"stat_u{idx}")
        self._draw_delta(c, x2 - 14, 100, 0.0, f"stat_d{idx}")
        _glow_line(c, _spark_pts(idx * 11 + 5, x2 - 120, 130, x2 - 14, 154),
                   tags="base", core="#dfe4ea", w=1)

    def _set_range(self, k: int) -> None:
        self.range_idx = k
        for i, b in enumerate(self.rng_btns):
            b.set_selected(i == k)

    def _qa_start(self) -> None:
        self.app.set_paused(False)
        self.console("overlay: resumed", "ok")

    def _qa_stop(self) -> None:
        self.app.set_paused(True)
        self.console("overlay: paused - press Start to resume", "warn")

    def _qa_reload(self) -> None:
        self.app.request_reload()
        self.console("offsets: reload requested (F4)", "info")

    def _qa_settings(self) -> None:
        self.show_tab(3)

    def _row_states(self) -> list[tuple[str, str]]:
        s = (self.reader.status or "").lower()
        err = bool(self.reader.error)
        files = getattr(self.reader, "off_files", None)
        paused = getattr(self.app, "paused", False)
        fps = float(getattr(self.overlay, "fps", 0.0) or 0.0)
        if s.startswith("reading") or s in ("attached", "selftest preview"):
            core, core_t = "ok", "Running smoothly"
        elif s.startswith("error"):
            core, core_t = "err", "Issue detected"
        else:
            core, core_t = "warn", "Initializing"
        if files:
            pipe, pipe_t = "ok", "Active"
        else:
            pipe, pipe_t = "warn", "Waiting for offsets"
        if paused:
            vis, vis_t = "warn", "Paused"
        elif fps >= 5.0:
            vis, vis_t = "ok", "Ready"
        else:
            vis, vis_t = "warn", "Idle"
        if err:
            diag, diag_t = "err", "Issues detected"
        else:
            diag, diag_t = "ok", "No issues detected"
        return [(core, core_t), (pipe, pipe_t), (vis, vis_t), (diag, diag_t)]

    def _paint_rows(self) -> None:
        c = self.ov
        c.delete("rows", "st_hdr", "st_chk")
        states = self._row_states()
        pill = {"ok": ("Healthy", PILL_BG, PILL_BR, GREEN),
                "warn": ("Standby", "#241c09", "#4a3a12", AMBER),
                "err": ("Error", "#26110f", "#4a201d", ERR)}
        t = time.time()
        for i, (state, sub) in enumerate(states):
            bx = 34 + (i % 2) * 218
            y = 232 + (i // 2) * 40
            Icons.draw(c, STATUS_ROWS[i][0], bx + 8, y, 6.5, "#aeb4bb",
                       tags="rows")
            c.create_text(bx + 26, y - 5, text=STATUS_ROWS[i][1], anchor="w",
                          fill="#dde1e6", font=(FAMILY, -10), tags="rows")
            c.create_text(bx + 26, y + 12, text=sub, anchor="w", fill=DIM,
                          font=(FAMILY, -8), tags="rows")
            fill, br, dot, txt = (pill[state][1], pill[state][2],
                                  pill[state][3], pill[state][0])
            c.create_polygon(_round_pts(bx + 148, y - 11, bx + 208, y + 11, 11),
                             fill=fill, outline=br, smooth=True, tags="rows")
            r = 2.4 + 0.9 * math.sin(t * 2.6 + i * 1.1)
            c.create_oval(bx + 158 - r, y - r, bx + 158 + r, y + r,
                          fill=dot, outline="", tags="rows")
            c.create_text(bx + 170, y, text=txt, anchor="w", fill=dot,
                          font=(FAMILY, -8), tags="rows")
        bad = any(s != "ok" for s, _ in states)
        if not bad:
            c.create_text(456, 192, text="All systems operational.",
                          anchor="e", fill=DIM, font=(FAMILY, -9),
                          tags="st_hdr")
            Icons.draw(c, "check", 466, 192, 5, GREEN, tags="st_chk")
        else:
            c.create_text(456, 192, text="Attention required.", anchor="e",
                          fill=AMBER, font=(FAMILY, -9), tags="st_hdr")
            Icons.draw(c, "check", 466, 192, 5, AMBER, tags="st_chk")

    def _paint_chart(self) -> None:
        c = self.ov
        c.delete("chart", "chart_lbl")
        x0, x1, y0, y1 = 46, 460, 348, 444
        win = RANGES[self.range_idx][1]
        now = time.time()
        pts = [(t, v) for (t, v) in self.fps_hist if t >= now - win]
        if self.demo and len(pts) < 10:
            pts = list(self.fps_hist)
        if len(pts) < 2:
            c.create_text((x0 + x1) / 2, (y0 + y1) / 2,
                          text="collecting samples\u2026", fill=FAINT,
                          font=(FAMILY, -9), tags="chart")
            return
        maxv = max(75.0, math.ceil(max(v for _t, v in pts) / 25.0) * 25.0)
        ys = []
        for i in range(4):
            v = maxv * (3 - i) / 3
            yy = y1 - (v / maxv) * (y1 - y0)
            ys.append((v, yy))
            c.create_text(x0 - 8, yy, anchor="e", text=f"{v:.0f}", fill=FAINT,
                          font=(FAMILY, -8), tags="chart_lbl")
            c.create_line(x0, yy, x1, yy, fill="#181c21", tags="chart")
        t0 = now - win
        xs = [x0 + (t - t0) / max(win, 1e-6) * (x1 - x0) for t, _v in pts]
        curve = [(x, y1 - (v / maxv) * (y1 - y0)) for x, (_t, v) in zip(xs, pts)]
        curve = [(x0 if x < x0 else (x1 if x > x1 else x), y) for x, y in curve]
        area = curve + [(curve[-1][0], y1), (curve[0][0], y1)]
        c.create_polygon(*[v for p in area for v in p], fill="#0f1216",
                         outline="", tags="chart", smooth=True)
        _glow_line(c, curve, tags="chart", core=WHITE_L, w=2)
        ex, ey = curve[-1]
        c.create_oval(ex - 5.5, ey - 5.5, ex + 5.5, ey + 5.5, outline="#33383f",
                      fill="", tags="chart")
        c.create_oval(ex - 2.6, ey - 2.6, ex + 2.6, ey + 2.6, fill=WHITE_L,
                      outline="", tags="chart")

    def _paint_overview_dyn(self) -> None:
        c = self.ov
        c.itemconfig("up_t", text=self._fmt_uptime(self._uptime_secs()))
        # stat cards (displayed values ease toward their live targets)
        cards = (
            (self._rate_val(), self.rate_hist, "rate", self._fmt_rate),
            (self._obj_val(), self.obj_hist, "obj",
             lambda v: (f"{int(round(v))}", "Tracked")),
            (self._mem_val(), self.mem_hist, "mem", self._fmt_mem))
        for idx, (val, hist, key, fmt) in enumerate(cards):
            cur = self._disp[key]
            if self.demo:
                cur = val
            else:
                cur += (val - cur) * 0.45
                if abs(val - cur) < max(1.0, abs(val) * 0.001):
                    cur = val
            self._disp[key] = cur
            vs, unit = fmt(cur)
            c.itemconfig(f"stat_v{idx}", text=vs)
            c.itemconfig(f"stat_u{idx}", text=(" " + unit) if unit != "Tracked" else " Tracked")
            self._draw_delta(c, {0: 227, 1: 448, 2: 670}[idx] - 14, 100,
                             self._delta(key, val, hist), f"stat_d{idx}")
        self._paint_rows()
        self._paint_chart()

    # --------------------------------------------------------------- reader
    @staticmethod
    def _basename(path: str) -> str:
        return path.replace("\\", "/").rsplit("/", 1)[-1]

    def _build_reader(self) -> None:
        c = self.rd_pg
        self._waves(c)
        c.create_text(18, 40, text="Reader", anchor="w", fill=FG,
                      font=(FAMILY, -30, "bold"), tags="base")
        c.create_text(18, 72, text="Attach state, offsets and console.",
                      anchor="w", fill=DIM, font=(FAMILY, -11), tags="base")
        # status card
        _card(c, 18, 92, 410, 262, r=18)
        c.create_oval(30, 104, 38, 112, fill=FG, outline="", tags="base")
        c.create_text(46, 108, text="Reader Status", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        rows = [("STATE", "rd_state", "PLACE", "rd_place"),
                ("PROCESS", "rd_pid", "PLAYERS", "rd_players"),
                ("RENDER", "rd_fps", "OFFSETS", "rd_off")]
        for i, (l1, v1, l2, v2) in enumerate(rows):
            y = 142 + i * 26
            c.create_text(34, y, text=l1, anchor="w", fill=FAINT,
                          font=(MONO, -8), tags="base")
            c.create_text(96, y, text="-", anchor="w", fill=FG,
                          font=(MONO, -9, "bold"), tags=v1)
            c.create_text(224, y, text=l2, anchor="w", fill=FAINT,
                          font=(MONO, -8), tags="base")
            c.create_text(292, y, text="-", anchor="w", fill=FG,
                          font=(MONO, -9, "bold"), tags=v2)
        c.create_text(34, 228, text="", anchor="nw", fill=ERR,
                      font=(MONO, -8), width=356, tags="rd_err")
        # offsets card
        _card(c, 422, 92, 670, 262, r=18)
        Icons.draw(c, "layers", 440, 108, 6.5, ICON, tags="base")
        c.create_text(454, 108, text="Offsets", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(440, 134, text="scanning\u2026", anchor="nw", fill=DIM,
                      font=(MONO, -8), width=212, tags="rd_files")
        b = PillButton(self.rd_pg, "RELOAD OFFSETS", command=self._qa_reload,
                       w=132, h=30, size=9, bold=True)
        b.place(x=546, y=196, anchor="center")
        c.create_text(440, 226, text="watches file mtime \u00b7 F4", anchor="w",
                      fill=FAINT, font=(FAMILY, -8), tags="base")
        # console card
        _card(c, 18, 274, 670, 430, r=18)
        c.create_oval(30, 286, 36, 292, fill=FG, outline="", tags="base")
        c.create_text(44, 289, text="Console", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        clr = PillButton(self.rd_pg, "CLEAR", command=self._console_clear,
                         w=56, h=22, size=8)
        clr.place(x=630, y=290, anchor="center")
        self.txt = tk.Text(c, bg=FIELD, fg=DIM, bd=0, highlightthickness=1,
                           highlightbackground=BORDER, font=(MONO, -8),
                           state="disabled", wrap="word", insertbackground=FG,
                           padx=8, pady=6, selectbackground="#1c2530")
        c.create_window(34, 308, window=self.txt, anchor="nw", width=620,
                        height=110)
        for tag, col in (("info", DIM), ("ok", GREEN), ("err", ERR),
                         ("warn", AMBER), ("dim", FAINT)):
            self.txt.tag_configure(tag, foreground=col)
        # actions
        acts = [("PREVIEW", self.actions.on_preview, 58, 80),
                ("DIAGNOSTICS", self.actions.on_diag, 160, 104),
                ("OPEN LOG", self.actions.on_open_log, 262, 80)]
        for txt, cmd, cx, wd in acts:
            pb = PillButton(self.rd_pg, txt, command=cmd, w=wd, h=24, size=9)
            pb.place(x=cx, y=450, anchor="center")
        self.console("panel ready - NTH External Reader", "ok")

    def _paint_reader_dyn(self) -> None:
        c = self.rd_pg
        s = self.reader.status or "starting"
        col = {"ok": GREEN, "warn": AMBER, "err": ERR}[self._health()]
        c.itemconfig("rd_state", text=s[:24], fill=col)
        c.itemconfig("rd_pid", text=str(self.reader.last_pid or "-"))
        c.itemconfig("rd_place", text=str(self.reader.last_place or "-"))
        c.itemconfig("rd_players", text=str(self.reader.players_seen))
        fps = float(getattr(self.overlay, "fps", 0.0) or 0.0)
        c.itemconfig("rd_fps", text=f"{fps:.0f} fps")
        files = getattr(self.reader, "off_files", None)
        if files:
            c.itemconfig("rd_off", text="loaded", fill=GREEN)
            names_str = " + ".join(self._basename(f) for f in files[-2:])
        else:
            c.itemconfig("rd_off", text="missing", fill=AMBER)
            names_str = ("no offset files yet - drop your dumper .json/.txt "
                         "into Documents\\mcro or next to nthexternal.exe")
        c.itemconfig("rd_files", text=names_str,
                     fill=DIM if files else AMBER)
        st_files = self.st_pg
        if files:
            st_files.itemconfig("st_files", text=names_str, fill=DIM)
        else:
            st_files.itemconfig("st_files", text=names_str, fill=AMBER)
        err = (self.reader.error or "")[:220]
        c.itemconfig("rd_err", text=err)

    # -------------------------------------------------------------- visuals
    def _build_visuals(self) -> None:
        c = self.vs_pg
        self._waves(c)
        c.create_text(18, 40, text="Visuals", anchor="w", fill=FG,
                      font=(FAMILY, -30, "bold"), tags="base")
        c.create_text(18, 72, text="Overlay rendering options.", anchor="w",
                      fill=DIM, font=(FAMILY, -11), tags="base")
        _card(c, 18, 92, 670, 262, r=18)
        Icons.draw(c, "eye", 40, 112, 6.5, ICON, tags="base")
        c.create_text(54, 112, text="Toggle Menu", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(656, 112, text="mirrors hotkeys", anchor="e", fill=FAINT,
                      font=(FAMILY, -9), tags="base")
        rows = [("Hitbox boxes", "F1", self.app.draw_boxes, self.app.set_boxes),
                ("Name / HP / distance tags", "F2", self.app.draw_names,
                 self.app.set_names),
                ("On-screen HUD", "F3", self.app.show_hud, self.app.set_hud)]
        self.sw_boxes = self.sw_names = self.sw_hud = None
        for i, (name, key, init, cmd) in enumerate(rows):
            y = 148 + i * 42
            c.create_text(40, y, text=name, anchor="w", fill="#dde1e6",
                          font=(FAMILY, -11), tags="base")
            c.create_polygon(_round_pts(556, y - 11, 602, y + 11, 10),
                             fill="#101318", outline=BORDER, smooth=True,
                             tags="base")
            c.create_text(579, y, text=key, fill=DIM, font=(MONO, -8),
                          tags="base")
            sw = Switch(c, init, cmd, bg=CARD)
            c.create_window(634, y, window=sw)
            setattr(self, ("sw_boxes", "sw_names", "sw_hud")[i], sw)
        # projection
        _card(c, 18, 274, 670, 396, r=18)
        Icons.draw(c, "target", 40, 294, 6.5, ICON, tags="base")
        c.create_text(54, 294, text="Projection mode", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(656, 294, text="F7", anchor="e", fill=DIM,
                      font=(MONO, -8), tags="base")
        self.seg_btns = []
        for i in range(4):
            pb = PillButton(self.vs_pg, f"M{i}",
                            command=lambda m=i: self.app.set_mode(m),
                            w=56, h=28, size=10, bold=True)
            pb.place(x=68 + i * 64, y=336, anchor="center")
            self.seg_btns.append(pb)
        c.create_text(40, 372, text="M3 (row-major, perspective in row 4) is "
                      "the default layout.", anchor="w", fill=FAINT,
                      font=(FAMILY, -8), tags="base")
        _card(c, 18, 408, 670, 458, r=16)
        c.create_text(352, 433, text="F1 boxes  \u00b7  F2 tags  \u00b7  F3 HUD  "
                      "\u00b7  F4 reload  \u00b7  F7 mode  \u00b7  F9 panel  "
                      "\u00b7  F8 quit", fill=DIM, font=(MONO, -8),
                      tags="base")

    # ------------------------------------------------------------- settings
    def _build_settings(self) -> None:
        c = self.st_pg
        self._waves(c)
        c.create_text(18, 40, text="Settings", anchor="w", fill=FG,
                      font=(FAMILY, -30, "bold"), tags="base")
        c.create_text(18, 72, text="Preferences and offsets.", anchor="w",
                      fill=DIM, font=(FAMILY, -11), tags="base")
        _card(c, 18, 92, 670, 224, r=18)
        Icons.draw(c, "gear", 40, 112, 6.5, ICON, tags="base")
        c.create_text(54, 112, text="Preferences", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(40, 150, text="Always on top", anchor="w", fill="#dde1e6",
                      font=(FAMILY, -11), tags="base")
        sw = Switch(c, True, self._set_topmost, bg=CARD)
        c.create_window(634, 150, window=sw)
        c.create_text(40, 192, text="Open log file", anchor="w", fill="#dde1e6",
                      font=(FAMILY, -11), tags="base")
        pb = PillButton(self.st_pg, "OPEN", command=self.actions.on_open_log,
                        w=64, h=24, size=9)
        pb.place(x=634, y=192, anchor="center")
        # offsets
        _card(c, 18, 236, 670, 352, r=18)
        Icons.draw(c, "layers", 40, 256, 6.5, ICON, tags="base")
        c.create_text(54, 256, text="Offsets", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        c.create_text(40, 284, text="scanning\u2026", anchor="nw", fill=DIM,
                      font=(MONO, -8), width=580, tags="st_files")
        rb = PillButton(self.st_pg, "RELOAD OFFSETS", command=self._qa_reload,
                        w=132, h=28, size=9, bold=True)
        rb.place(x=106, y=322, anchor="center")
        c.create_text(656, 322, text="watches file mtime", anchor="e",
                      fill=FAINT, font=(FAMILY, -8), tags="base")
        # hotkeys
        _card(c, 18, 364, 670, 458, r=18)
        Icons.draw(c, "zap", 40, 384, 6, ICON, tags="base")
        c.create_text(54, 384, text="Hotkeys", anchor="w", fill=FG,
                      font=(FAMILY, -12, "bold"), tags="base")
        col1 = ["F1  toggle hitbox boxes", "F2  toggle name / HP tags",
                "F3  toggle on-screen HUD", "F4  reload offset files"]
        col2 = ["F7  cycle projection mode", "F9  show / hide the panel",
                "F8  quit"]
        for i, line in enumerate(col1):
            c.create_text(40, 406 + i * 14, text=line, anchor="w", fill=DIM,
                          font=(MONO, -8), tags="base")
        for i, line in enumerate(col2):
            c.create_text(360, 406 + i * 14, text=line, anchor="w", fill=DIM,
                          font=(MONO, -8), tags="base")

    def _set_topmost(self, on: bool) -> None:
        try:
            self.attributes("-topmost", bool(on))
        except tk.TclError:
            pass

    # ---------------------------------------------------------------- about
    def _build_about(self) -> None:
        c = self.ab_pg
        self._waves(c)
        c.create_text(18, 40, text="About", anchor="w", fill=FG,
                      font=(FAMILY, -30, "bold"), tags="base")
        c.create_text(18, 72, text="NTH External Reader", anchor="w", fill=DIM,
                      font=(FAMILY, -11), tags="base")
        _card(c, 18, 92, 670, 272, r=18)
        paint_chrome_n(c, 48, 122, 58, 62, tags="base")
        c.create_text(132, 124, text="NTH", anchor="w", fill=FG,
                      font=(FAMILY, -22, "bold"), tags="base")
        c.create_text(132, 150, text="E X T E R N A L   R E A D E R",
                      anchor="w", fill=DIM, font=(FAMILY, -9), tags="base")
        c.create_text(132, 170, text=f"v{self.version}", anchor="w", fill=FAINT,
                      font=(FAMILY, -10), tags="base")
        c.create_text(48, 208, anchor="nw", fill=DIM, font=(FAMILY, -9),
                      width=580, justify="left", tags="base",
                      text="External world-state reader with a hitbox "
                           "overlay, built for anti-cheat testing. Read-only "
                           "user-mode: OpenProcess + ReadProcessMemory only - "
                           "nothing is injected and nothing is written to the "
                           "game.")
        _card(c, 18, 284, 670, 364, r=18)
        c.create_text(54, 304, text="Fair use", anchor="w", fill=FG,
                      font=(FAMILY, -11, "bold"), tags="base")
        c.create_text(40, 324, anchor="nw", fill=DIM, font=(FAMILY, -9),
                      width=580, justify="left", tags="base",
                      text="Test only on games you own and servers you are "
                           "permitted to test. The tool ships without kernel "
                           "components and never writes to the game process.")
        _card(c, 18, 376, 670, 458, r=18)
        paint_chrome_n(c, 340, 388, 24, 26, tags="base")
        c.create_text(352, 430, text="Built for performance. Designed for you.",
                      fill=FG, font=(FAMILY, -13, "bold"), tags="base")
        c.create_text(352, 447, text=f"\u2014 NTH \u00b7 v{self.version}", fill=FAINT,
                      font=(FAMILY, -8), tags="base")

    # ------------------------------------------------------------ nav / tabs
    def show_tab(self, k: int) -> None:
        self.tab = k
        self._nav_paint_soon()  # repaint outside the click-event dispatch
        self.frames[k].tkraise()
        self._slide_page(self.frames[k])
        self._tween_nav()

    # ------------------------------------------------------- ui animations
    def _slide_page(self, holder: tk.Frame) -> None:
        """Ease the freshly raised page in (short horizontal slide)."""
        if self._slide_job:
            try:
                self.after_cancel(self._slide_job)
            except Exception:
                pass
            self._slide_job = None
        steps = 9
        state = {"i": 0}

        def step() -> None:
            i = state["i"]
            t = i / (steps - 1)
            e = 1.0 - (1.0 - t) ** 3
            off = int(round(22.0 * (1.0 - e)))
            holder.place(x=off, y=0)
            if i < steps - 1:
                state["i"] = i + 1
                self._slide_job = self.after(16, step)
            else:
                holder.place(x=0, y=0)
                self._slide_job = None

        step()

    def _tween_nav(self) -> None:
        """Slide the sidebar active pill to the current tab."""
        target = 104.0 + self.tab * 40.0
        if self._nav_job:
            try:
                self.after_cancel(self._nav_job)
            except Exception:
                pass
            self._nav_job = None

        def step() -> None:
            d = target - self._nav_y
            if abs(d) < 0.8:
                self._nav_y = target
                self._paint_nav()
                self._nav_job = None
                return
            self._nav_y += d * 0.34
            self._paint_nav()
            self._nav_job = self.after(16, step)

        step()

    def _load_gif(self):
        """Load the baked mascot gif (list of frames) or None if missing."""
        here = os.path.dirname(os.path.abspath(__file__))
        for p in (os.path.join(here, "nth_mascot.gif"),
                  os.path.join(here, "assets", "nth_mascot.gif"),
                  os.path.join(here, os.pardir, "assets", "nth_mascot.gif")):
            if not os.path.exists(p):
                continue
            frames = []
            try:
                i = 0
                while True:
                    try:
                        frames.append(tk.PhotoImage(file=p,
                                                    format=f"gif -index {i}"))
                    except tk.TclError:
                        break
                    i += 1
            except Exception:
                frames = []
            if frames:
                return frames
        return None

    def _gif_tick(self) -> None:
        if self._gif_frames:
            self._gif_idx = (self._gif_idx + 1) % len(self._gif_frames)
            try:
                self.ov.itemconfig("gifimg",
                                   image=self._gif_frames[self._gif_idx])
            except Exception:
                pass
        self.after(GIF_MS, self._gif_tick)

    def _paint_gif_placeholder(self, c: tk.Canvas) -> None:
        """Fallback if the mascot asset is missing: purple star emblem."""
        cx, cy = 582, 258
        for r_in, r_out, col in ((10, 26, ACCENT), (6, 15, ACCENT_DIM)):
            pts = []
            for i in range(8):
                a = math.pi / 4 * i - math.pi / 2 + 0.35
                r = r_out if i % 2 == 0 else r_in
                pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
            c.create_polygon(pts, fill=col, outline="", tags="base")
        c.create_text(cx, cy + 46, text="mascot asset missing", fill=FAINT,
                      font=(FAMILY, -8), tags="base")

    def _anim_tick(self) -> None:
        """Ambient idle animation: wave drift, status pulse, ring shimmer."""
        self._anim_phase = (self._anim_phase + 0.16) % 997.0
        ph = self._anim_phase
        pages = (self.ov, self.rd_pg, self.vs_pg, self.st_pg, self.ab_pg)
        c = pages[self.tab]
        for i, (pts, _w, _col) in enumerate(self.WAVES_DEF):
            items = c.find_withtag(f"wave{i}")
            if not items:
                continue
            dx = 12.0 * math.sin(ph * 0.8 + i * 1.4)
            dy = 3.0 * math.sin(ph * 0.55 + i * 0.9)
            flat = []
            for (x, y) in pts:
                flat += (x + dx, y + dy)
            try:
                c.coords(items[0], *flat)
            except Exception:
                pass
        self._paint_sb_status()
        try:
            self.ov.itemconfig("gifring", dashoffset=int(-ph * 26.0) % 9)
        except Exception:
            pass
        self.after(120, self._anim_tick)

    # ---------------------------------------------------------- window mgmt
    def _winExtras(self) -> None:
        """Best-effort Windows polish: toolwindow style, DWM rounded corners
        plus a rounded window region (clips corners on every Windows build)."""
        self._rgn_hwnd = None
        if os.name != "nt":
            return
        try:
            import ctypes
            u32 = ctypes.WinDLL("user32")
            hwnd = u32.GetParent(self.winfo_id()) or self.winfo_id()
            GWL_EXSTYLE = -20
            style = u32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            u32.SetWindowLongW(hwnd, GWL_EXSTYLE, style | 0x00000040)
            self._rgn_hwnd = hwnd
            try:
                dwm = ctypes.WinDLL("dwmapi")
                pref = ctypes.c_int(2)  # DWMWCP_ROUND
                dwm.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), 33,
                                          ctypes.byref(pref),
                                          ctypes.sizeof(pref))
            except Exception:
                pass
            self._apply_round_region(W, H)
        except Exception:
            pass

    def _apply_round_region(self, w: int, h: int) -> None:
        """Clip the borderless window to a rounded rectangle (all Windows)."""
        if os.name != "nt" or not getattr(self, "_rgn_hwnd", None):
            return
        try:
            import ctypes
            u32 = ctypes.WinDLL("user32")
            g32 = ctypes.WinDLL("gdi32")
            r = 18
            hrgn = g32.CreateRoundRectRgn(0, 0, int(w) + 1, int(h) + 1, r, r)
            u32.SetWindowRgn(self._rgn_hwnd, hrgn, True)
        except Exception:
            pass

    def _drag_start(self, e) -> None:
        self._drag = (e.x, e.y)

    def _drag_move(self, e) -> None:
        if self._drag and not self._zoomed:
            x = self.winfo_x() - self._drag[0] + e.x
            y = self.winfo_y() - self._drag[1] + e.y
            self.geometry(f"+{x}+{y}")

    def _minimize(self) -> None:
        self.app.panel_visible = False
        self.withdraw()

    def show_panel(self) -> None:
        self.app.panel_visible = True
        self.deiconify()
        self.lift()
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass

    def toggle_visibility(self) -> None:
        if self.state() == "withdrawn":
            self.show_panel()
        else:
            self._minimize()

    def _toggle_zoom(self) -> None:
        if not self._zoomed:
            try:
                sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            except Exception:
                sw, sh = 800, 500
            self._zoomed = True
            self.geometry(f"{sw}x{sh}+0+0")
            self.shell.place(relx=0.5, rely=0.5, anchor="center")
            self._apply_round_region(sw, sh)
        else:
            self._zoomed = False
            self.geometry(f"{W}x{H}+{self._home[0]}+{self._home[1]}")
            self.shell.place(x=0, y=0)
            self._apply_round_region(W, H)

    def _quit(self) -> None:
        self.app.quit = True

    # ------------------------------------------------------------------ poll
    def console(self, msg: str, level: str = "info") -> None:
        self.console_q.put((level, msg))

    def _console_clear(self) -> None:
        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.config(state="disabled")

    def _append(self, line: str, level: str) -> None:
        self.txt.config(state="normal")
        self.txt.insert("end", line.rstrip() + "\n", level)
        if int(self.txt.index("end-1c").split(".")[0]) > 300:
            self.txt.delete("1.0", "150.0")
        self.txt.see("end")
        self.txt.config(state="disabled")

    def _poll(self) -> None:
        self._poll_n += 1
        try:
            if self.app.quit:
                return
            boxes, names, hud, mode = self.app.snapshot_flags()
            self.sw_boxes.set(boxes)
            self.sw_names.set(names)
            self.sw_hud.set(hud)
            for i, b in enumerate(self.seg_btns):
                b.set_selected(i == mode)
            self._paint_reader_dyn()
            self._paint_overview_dyn()
            if self._poll_n % 8 == 0:
                now = time.time()
                self.rate_hist.append((now, self._rate_val()))
                self.mem_hist.append((now, self._mem_val()))
                self.obj_hist.append((now, float(self._obj_val())))
                fps = float(getattr(self.overlay, "fps", 0.0) or 0.0)
                self.fps_hist.append((now, fps))
            st = self._health()
            if st != self._sb_state:
                self._sb_state = st
                self._paint_sb_status()
            try:
                while True:
                    line = self.reader.ui_q.get_nowait()
                    self._append(line, "info")
            except queue.Empty:
                pass
            try:
                while True:
                    level, line = self.console_q.get_nowait()
                    self._append(line, level)
            except queue.Empty:
                pass
        except Exception as e:  # never let the poll loop die
            try:
                self.console(f"panel: {type(e).__name__}: {e}", "err")
            except Exception:
                pass
        self.after(250, self._poll)
