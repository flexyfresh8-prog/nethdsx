"""Probe 2: raw byte dumps around the DataModel candidate to pin down field layouts."""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import Memory, Offsets, list_processes_by_name, main_module_base  # noqa: E402

off = Offsets()
off.merge_file(os.path.expanduser("~") + r"\Documents\mcro\New Text Document.json")

pid = list_processes_by_name(["robloxplayerbeta"])[0][0]
mem = Memory(pid)
mem.open()
base = main_module_base(pid)


def hexdump(label: str, addr: int, size: int = 0x60) -> None:
    print(f"\n-- {label} @ 0x{addr:x}")
    data = mem.read(addr, size)
    if not data:
        print("   <unreadable>")
        return
    for row in range(0, len(data), 16):
        chunk = data[row:row + 16]
        hx = " ".join(f"{b:02x}" for b in chunk)
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print(f"   {addr + row:012x}  {hx:<47}  |{asc}|")
        if row == 0:
            q0, q1 = struct.unpack_from("<QQ", chunk)
            print(f"                        qword[0]=0x{q0:x}  qword[1]=0x{q1:x}")


# 1) the promising candidate
INST = 0x22A4DB220C0
hexdump("candidate instance (ve_real)", INST, 0x90)

# 2) its class descriptor (static memory)
CD = mem.r64(INST + 0x18)
hexdump("class descriptor", CD, 0x40)

# 3) its name container
NC = mem.r64(INST + 0x68)
hexdump("name container", NC, 0x30)

# 4) fake data model areas
VEP = off.require("VisualEngine", "Pointer")
ve = mem.r64(base + VEP)
vfake = mem.r64(ve + off.require("VisualEngine", "FakeDataModel"))
hexdump("ve_fake (suspected FAKE DataModel)", vfake, 0x40)
hexdump("ve_fake + 0x1f8 (suspected REAL DataModel)", vfake + 0x1F8, 0x40)

# 5) global FakeDataModel::Pointer chain
FDP = off.get("FakeDataModel", "Pointer")
if FDP:
    gfake = mem.r64(base + FDP)
    print(f"\nglobal FakeDataModel::Pointer (base+0x{FDP:x}) = 0x{gfake:x}")
    if gfake:
        greal = mem.r64(gfake + off.require("FakeDataModel", "RealDataModel"))
        print(f"  real = 0x{greal:x}")
        hexdump("global-fake -> real", greal, 0x40)

# 6) read the candidate's class descriptor as multiple string interpretations
if CD:
    print("\n-- class descriptor string attempts:")
    for o in (0x0, 0x8, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38, 0x40, 0x48, 0x50, 0x58):
        s = mem.r_string(CD + o)
        if s and all(32 <= ord(c) < 127 for c in s):
            print(f"   r_string(cd+0x{o:02x}) = {s!r}")
    print("   direct ASCII at cd+0x00..0x40 printed above")

# 7) name container interpretations
if NC:
    print("\n-- name container string attempts:")
    for o in (0x0, 0x8, 0x10, 0x18):
        s = mem.r_string(NC + o)
        print(f"   r_string(nc+0x{o:02x}) = {s!r}")
    inner = mem.r64(NC)
    print(f"   *(nc+0) = 0x{inner:x}")
    if inner:
        for o in (0x0, 0x8, 0x10):
            s = mem.r_string(inner + o)
            print(f"   r_string(*nc+0x{o:02x}) = {s!r}")

# 8) children vector under alternate orderings for the candidate
CS = off.require("Instance", "ChildrenStart")   # 0x70
CE = off.require("Instance", "ChildrenEnd")     # 0x8
b = mem.r64(INST + CS)
e = mem.r64(INST + CS + CE)
print(f"\nchildren: *(inst+0x70)=0x{b:x}  *(inst+0x78)=0x{e:x}  (n={(e - b) // 8 if e >= b else -(b - e) // 8})")
# maybe the dump means: vector base pointer at inst+0x70, begin/end INSIDE it
vb = mem.r64(INST + CS)
if vb:
    b2 = mem.r64(vb)
    e2 = mem.r64(vb + 8)
    print(f"alt: vecobj=*(inst+0x70)=0x{vb:x} -> begin=0x{b2:x} end=0x{e2:x} n={(e2 - b2) // 8 if e2 >= b2 else '?'}")

mem.close()
