"""Probe: why did process enumeration come back empty while tasklist sees Roblox?"""
import ctypes
import os
import sys
from ctypes import wintypes

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

k32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

print("== path 1: CreateToolhelp32Snapshot ==")
snap = k32.CreateToolhelp32Snapshot(0x2, 0)
snap_val = ctypes.cast(snap, ctypes.c_void_p).value if snap else None
print("handle =", snap_val, "err =", ctypes.get_last_error())
INVALID = ctypes.c_void_p(-1).value
print("is INVALID_HANDLE_VALUE:", snap_val == INVALID)

if snap_val and snap_val != INVALID:
    class PE32(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD), ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD),
            ("szExeFile", ctypes.c_wchar * 260),
        ]
    pe = PE32()
    pe.dwSize = ctypes.sizeof(PE32)
    n = 0
    hits = []
    if k32.Process32FirstW(snap, ctypes.byref(pe)):
        while True:
            n += 1
            if "roblox" in (pe.szExeFile or "").lower():
                hits.append((pe.th32ProcessID, pe.szExeFile))
            if not k32.Process32NextW(snap, ctypes.byref(pe)):
                break
        print(f"enumerated {n} processes, roblox hits: {hits}")
    else:
        print("Process32FirstW failed, err =", ctypes.get_last_error())
    k32.CloseHandle(snap)

print("\n== path 2: EnumProcesses (psapi) ==")
K32EnumProcesses = k32.K32EnumProcesses
arr = (wintypes.DWORD * 4096)()
needed = wintypes.DWORD(0)
ok = K32EnumProcesses(arr, ctypes.sizeof(arr), ctypes.byref(needed))
print("ok:", bool(ok), "err:", ctypes.get_last_error(), "bytes:", needed.value)
count = needed.value // 4
print("pids:", count)
for i in range(min(count, 4096)):
    pid = arr[i]
    if not pid:
        continue
    h = k32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION
    if not h:
        continue
    try:
        buf = ctypes.create_unicode_buffer(260)
        ln = psapi.GetModuleBaseNameW(h, None, buf, 260)
        if ln and "roblox" in buf.value.lower():
            print(f"  ROBLOX pid={pid} name={buf.value}")
    finally:
        k32.CloseHandle(h)

print("\n== path 3: direct open of 14744 ==")
for rights, label in (
    (0x0010, "PROCESS_VM_READ"),
    (0x1000, "QUERY_LIMITED"),
    (0x0010 | 0x1000, "VM_READ|QUERY_LIMITED"),
    (0x0400 | 0x0010, "QUERY_INFORMATION|VM_READ"),
):
    h = k32.OpenProcess(rights, False, 14744)
    print(f"  {label}: handle={h} err={ctypes.get_last_error()}")
    if h:
        k32.CloseHandle(h)

print("\n== path 4: elevation ==")
try:
    is_admin = bool(ctypes.windll.shell32.IsUserAnAdmin())
except Exception:
    is_admin = None
print("elevated:", is_admin)
