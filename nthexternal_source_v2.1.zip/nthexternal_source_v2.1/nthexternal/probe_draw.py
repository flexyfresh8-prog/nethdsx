"""Probe: live end-to-end draw-path check.

1. players + part counts (remote vs local)
2. raw children dump of one remote character (find where the parts went)
3. force the local player through the draw gates: project every part with all
   3 modes and map onto the Roblox window client rect -> would boxes land on
   screen?
"""
import math
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rbx_core import (Game, Offsets, project_box, world_to_screen)  # noqa: E402
from rbx_esp import find_roblox_window  # noqa: E402

off = Offsets()
off.merge_file(os.path.expanduser("~") + r"\Documents\mcro\New Text Document.json")

g = Game(off, log=lambda m: None)
g.attach()
print(f"attached pid={g.pid} place={g.place_id}")

snap = g.read_frame()
if snap is None or snap.matrix is None:
    print("no frame/matrix")
    sys.exit(1)

print(f"viewport {snap.vp_w:.0f}x{snap.vp_h:.0f}  matrix ok")
win = find_roblox_window(g.pid)
print(f"roblox window: {win}")

for ps in snap.players:
    print(f"  {ps.display!r} uid={ps.uid} parts={len(ps.parts)} "
          f"hp={ps.health:.0f}/{ps.max_health:.0f} local={ps.is_local}")

# ---- remote characters with 0 parts: dump every child ----
mem = g.mem
off_char = off.require("Player", "ModelInstance")
BP = off.require("BasePart", "Primitive")
P_POS = off.require("Primitive", "Position")
P_SIZE = off.require("Primitive", "Size")
remote_zero = [ps for ps in snap.players if not ps.is_local and not ps.parts]
if remote_zero:
    # map display back to the Player instance by re-walking children
    target_insts = []
    local = mem.r64(g.players_inst + off.require("Player", "LocalPlayer"))
    for p in g.children(g.players_inst):
        if not p or p == local:
            continue
        try:
            if g.class_name(p) != "Player":
                continue
        except Exception:
            continue
        target_insts.append(p)
    for idx, ps in enumerate(remote_zero):
        if idx >= len(target_insts):
            break
        inst = target_insts[idx]
        char = mem.r64(inst + off_char)
        print(f"\n== remote char of {ps.display!r}: 0x{char:x}")
        if not char:
            print("   no ModelInstance")
            continue
        classes = {}
        for c in g.children(char, cap=256):
            if not c:
                continue
            cn = g.class_name(c)
            classes[cn] = classes.get(cn, 0) + 1
        print(f"   child classes: {classes}")
        prim = mem.r64(char + 0x0)  # sanity: vector header readable
        # check ModelChildren like 'Left Leg' via name
        for c in g.children(char, cap=256):
            if not c:
                continue
            cn = g.class_name(c)
            nm = g.instance_name(c)
            if cn in ("Part", "MeshPart", "UnionOperation", "WedgePart", "Seat", "VehicleSeat") or (
                cn not in ("Humanoid", "Script", "LocalScript", "Shirt", "Pants",
                           "Accessory", "BodyColors", "Sound", "ShirtGraphic")
            ):
                prim = mem.r64(c + BP) if c else 0
                print(f"   RAW {nm!r} {cn!r} prim=0x{prim:x}")

# ---- force local player through the draw gates ----
me = next((ps for ps in snap.players if ps.parts), None)
if me:
    print(f"\n== draw-gate simulation for {me.display!r} (forced non-local)")
for mode in range(4):
        n_vis = 0
        in_win = 0
        for (pos, size, rot) in me.parts:
            corners = project_box(snap.matrix, pos, size, rot, snap.vp_w, snap.vp_h, mode)
            if corners is None:
                continue
            n_vis += 1
            for (px, py) in corners:
                if math.isnan(px) or math.isnan(py):
                    continue
                if win:
                    _, wx, wy, ww, wh = win
                    sx = wx + px * ww / snap.vp_w
                    sy = wy + py * wh / snap.vp_h
                else:
                    sx = px
                    sy = py
                if 0 <= sx <= (win[3] + win[1] if win else snap.vp_w) and \
                   0 <= sy <= (win[4] + win[2] if win else snap.vp_h):
                    in_win += 1
        print(f"   mode {mode}: boxes visible {n_vis}/{len(me.parts)}, "
              f"corners inside window {in_win}")

mem.close()
